package com.itmdaproject.bumpr;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RetryPolicy;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AccidentAIActivity extends AppCompatActivity {

    private static final String BASE_URL =
            "http://10.0.2.2/bumpr/";

    private static final String DETAILS_URL =
            BASE_URL + "get_accident_details.php";

    private static final String GET_ANALYSES_URL =
            BASE_URL + "get_accident_ai_analysis.php";

    private static final String ANALYSE_URL =
            BASE_URL + "analyze_accident_evidence.php";

    private static final String UPDATE_ANALYSIS_URL =
            BASE_URL + "update_accident_ai_analysis.php";

    private TextView txtAIAccidentId;
    private TextView txtAIStatus;
    private TextView txtAIAnalysis;

    private Spinner spinnerAIEvidence;
    private ImageView imgAIEvidencePreview;
    private EditText edtReviewedAnalysis;
    private ProgressBar progressAI;

    private Button btnAnalyseEvidence;
    private Button btnSaveReviewedAnalysis;
    private Button btnBackFromAI;

    private RequestQueue requestQueue;

    private int accidentId;
    private int userId;

    private final ArrayList<JSONObject> evidenceList =
            new ArrayList<>();

    private JSONArray savedAnalyses = new JSONArray();

    private int currentAnalysisId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_accident_ai);

        txtAIAccidentId = findViewById(R.id.txtAIAccidentId);
        txtAIStatus = findViewById(R.id.txtAIStatus);
        txtAIAnalysis = findViewById(R.id.txtAIAnalysis);

        spinnerAIEvidence =
                findViewById(R.id.spinnerAIEvidence);

        imgAIEvidencePreview =
                findViewById(R.id.imgAIEvidencePreview);

        edtReviewedAnalysis =
                findViewById(R.id.edtReviewedAnalysis);

        progressAI = findViewById(R.id.progressAI);


        btnAnalyseEvidence =
                findViewById(R.id.btnAnalyseEvidence);

        btnSaveReviewedAnalysis =
                findViewById(R.id.btnSaveReviewedAnalysis);

        btnBackFromAI =
                findViewById(R.id.btnBackFromAI);

        btnAnalyseEvidence.setEnabled(false);
        btnSaveReviewedAnalysis.setEnabled(false);

        spinnerAIEvidence.setEnabled(false);

        btnAnalyseEvidence.setOnClickListener(v ->
                analyseSelectedEvidence()
        );

        btnSaveReviewedAnalysis.setOnClickListener(v ->
                saveReviewedAnalysis()
        );

        btnBackFromAI.setOnClickListener(v -> finish());

        requestQueue = Volley.newRequestQueue(this);

        accidentId = getIntent().getIntExtra(
                "accident_id", -1
        );

        userId = getSharedPreferences(
                "BumprPrefs",
                MODE_PRIVATE
        ).getInt("userId", -1);

        btnAnalyseEvidence.setEnabled(false);
        btnSaveReviewedAnalysis.setEnabled(false);

        btnBackFromAI.setOnClickListener(v -> finish());

        if (accidentId <= 0 || userId <= 0) {
            txtAIStatus.setText(
                    "Unable to identify the accident or user."
            );
            return;
        }

        txtAIAccidentId.setText(
                "Accident #" + accidentId
        );

        loadAccidentEvidence();
    }

    private void loadAccidentEvidence() {

        progressAI.setVisibility(View.VISIBLE);
        txtAIStatus.setText("Loading evidence photographs...");

        StringRequest request = new StringRequest(
                Request.Method.POST,
                DETAILS_URL,

                response -> {
                    try {
                        JSONObject json =
                                new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            showError(json.optString(
                                    "message",
                                    "Unable to load accident evidence."
                            ));
                            progressAI.setVisibility(View.GONE);
                            return;
                        }

                        JSONObject accident =
                                json.getJSONObject("accident");

                        JSONArray evidence =
                                accident.optJSONArray("evidence");

                        evidenceList.clear();

                        if (evidence != null) {
                            for (int i = 0;
                                 i < evidence.length();
                                 i++) {

                                evidenceList.add(
                                        evidence.getJSONObject(i)
                                );
                            }
                        }

                        setupEvidenceSpinner();

                        loadSavedAnalyses();

                    } catch (Exception e) {
                        progressAI.setVisibility(View.GONE);
                        showError("Unable to read evidence data.");
                    }
                },

                error -> {
                    progressAI.setVisibility(View.GONE);
                    showError("Unable to connect to the server.");
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                return params;
            }
        };

        requestQueue.add(request);
    }

    private void setupEvidenceSpinner() {

        btnAnalyseEvidence.setEnabled(!evidenceList.isEmpty());

        ArrayList<String> labels = new ArrayList<>();

        if (evidenceList.isEmpty()) {
            labels.add("No evidence photographs available");
        } else {
            for (JSONObject evidence : evidenceList) {

                String category = evidence.optString(
                        "category",
                        "Accident Evidence"
                );

                int evidenceId = evidence.optInt(
                        "evidence_id", -1
                );

                labels.add(
                        category + " (Evidence #" + evidenceId + ")"
                );
            }
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        labels
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerAIEvidence.setAdapter(adapter);

        spinnerAIEvidence.setOnItemSelectedListener(
                new android.widget.AdapterView
                        .OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        if (evidenceList.isEmpty()) {
                            imgAIEvidencePreview.setImageDrawable(null);
                            txtAIAnalysis.setText(
                                    "No evidence photographs available."
                            );
                            return;
                        }

                        displaySelectedEvidence(position);
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                }
        );
    }


    private void displaySelectedEvidence(int position) {

        if (position < 0 ||
                position >= evidenceList.size()) {
            return;
        }

        JSONObject evidence = evidenceList.get(position);

        int evidenceId = evidence.optInt(
                "evidence_id", -1
        );

        String imagePath = evidence.optString(
                "image_path", ""
        );

        imgAIEvidencePreview.setImageDrawable(null);

        if (imagePath.isEmpty()
                || imagePath.startsWith("/")
                || imagePath.contains("..")
                || imagePath.contains("\\")
                || imagePath.contains(":")) {

            showError("Invalid evidence image path.");
            return;
        }

        String imageUrl = BASE_URL + imagePath;

        ImageRequest imageRequest = new ImageRequest(
                imageUrl,

                bitmap -> {
                    if (spinnerAIEvidence.getSelectedItemPosition()
                            == position) {
                        imgAIEvidencePreview.setImageBitmap(bitmap);
                    }
                },

                1000,
                1000,
                ImageView.ScaleType.FIT_CENTER,
                Bitmap.Config.RGB_565,

                error -> showError(
                        "Unable to load evidence photograph."
                )
        );

        requestQueue.add(imageRequest);

        // Display any saved AI analysis for this photograph
        displaySavedAnalysis(evidenceId);
    }

    private void loadSavedAnalyses() {

        txtAIStatus.setText("Loading saved AI analyses...");

        StringRequest request = new StringRequest(
                Request.Method.POST,
                GET_ANALYSES_URL,

                response -> {
                    progressAI.setVisibility(View.GONE);

                    try {
                        JSONObject json =
                                new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            showError(json.optString(
                                    "message",
                                    "Unable to retrieve AI analyses."
                            ));
                            return;
                        }

                        savedAnalyses = json.optJSONArray(
                                "analyses"
                        );

                        if (savedAnalyses == null) {
                            savedAnalyses = new JSONArray();
                        }

                        txtAIStatus.setText(
                                "Evidence loaded successfully."
                        );

                        if (!evidenceList.isEmpty()) {
                            JSONObject selected =
                                    evidenceList.get(
                                            spinnerAIEvidence
                                                    .getSelectedItemPosition()
                                    );

                            displaySavedAnalysis(
                                    selected.optInt(
                                            "evidence_id", -1
                                    )
                            );
                        }

                    } catch (Exception e) {
                        showError("Unable to read AI analysis data.");
                    }
                },

                error -> {
                    progressAI.setVisibility(View.GONE);
                    showError("Unable to retrieve saved analyses.");
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                return params;
            }
        };

        requestQueue.add(request);
    }


    private void displaySavedAnalysis(int evidenceId) {

        currentAnalysisId = -1;

        btnSaveReviewedAnalysis.setEnabled(false);

        txtAIAnalysis.setText(
                "No AI analysis available for this photograph."
        );

        edtReviewedAnalysis.setText("");

        for (int i = 0; i < savedAnalyses.length(); i++) {

            JSONObject analysis =
                    savedAnalyses.optJSONObject(i);

            if (analysis == null) {
                continue;
            }

            if (analysis.optInt("evidence_id", -1)
                    == evidenceId) {

                currentAnalysisId =
                        analysis.optInt("analysis_id", -1);

                btnSaveReviewedAnalysis.setEnabled(currentAnalysisId > 0);

                String originalAnalysis =
                        analysis.optString("analysis", "");

                txtAIAnalysis.setText(originalAnalysis);

                String reviewedAnalysis = "";

                if (!analysis.isNull("reviewed_analysis")) {
                    reviewedAnalysis =
                            analysis.optString(
                                    "reviewed_analysis", ""
                            );
                }

                if (!reviewedAnalysis.trim().isEmpty()) {
                    edtReviewedAnalysis.setText(
                            reviewedAnalysis
                    );
                } else {
                    edtReviewedAnalysis.setText(
                            originalAnalysis
                    );
                }

                return;
            }
        }
    }

    private void analyseSelectedEvidence() {

        int selectedPosition =
                spinnerAIEvidence.getSelectedItemPosition();

        if (selectedPosition < 0 ||
                selectedPosition >= evidenceList.size()) {

            Toast.makeText(
                    this,
                    "Please select an evidence photograph.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        JSONObject selectedEvidence =
                evidenceList.get(selectedPosition);

        int evidenceId =
                selectedEvidence.optInt("evidence_id", -1);

        if (evidenceId <= 0) {

            showError("Invalid evidence photograph.");
            return;
        }

        // Disable actions while the AI is processing
        btnAnalyseEvidence.setEnabled(false);
        btnSaveReviewedAnalysis.setEnabled(false);

        progressAI.setVisibility(View.VISIBLE);

        txtAIStatus.setText(
                "Gemma is analysing the selected photograph..."
        );

        StringRequest request = new StringRequest(
                Request.Method.POST,
                ANALYSE_URL,

                response -> {

                    progressAI.setVisibility(View.GONE);

                    try {

                        JSONObject json =
                                new JSONObject(response);

                        if (!json.optBoolean("success", false)) {

                            showError(json.optString(
                                    "message",
                                    "AI analysis failed."
                            ));

                            btnAnalyseEvidence.setEnabled(true);
                            return;
                        }

                        String analysisText =
                                json.optString("analysis", "");

                        int analysisId =
                                json.optInt("analysis_id", -1);

                        if (analysisText.trim().isEmpty()
                                || analysisId <= 0) {

                            showError(
                                    "The server returned an invalid AI analysis."
                            );

                            btnAnalyseEvidence.setEnabled(true);
                            return;
                        }

                        currentAnalysisId = analysisId;

                        btnSaveReviewedAnalysis.setEnabled(true);

                        // Display the generated observations
                        txtAIAnalysis.setText(analysisText);

                        // Pre-fill the review field
                        edtReviewedAnalysis.setText(analysisText);

                        txtAIStatus.setText(
                                "AI analysis generated successfully. "
                                        + "Please review the observations."
                        );

                        Toast.makeText(
                                AccidentAIActivity.this,
                                "AI analysis completed successfully.",
                                Toast.LENGTH_LONG
                        ).show();

                        // Refresh saved analyses from the database
                        loadSavedAnalyses();

                    } catch (Exception e) {

                        showError(
                                "Unable to read the AI analysis response."
                        );
                    }

                    btnAnalyseEvidence.setEnabled(true);
                },

                error -> {

                    progressAI.setVisibility(View.GONE);

                    btnAnalyseEvidence.setEnabled(true);

                    String message =
                            "Unable to complete AI analysis.";

                    if (error.networkResponse != null) {
                        message += " Server error: "
                                + error.networkResponse.statusCode;
                    } else {
                        message += " Check the server and Ollama connection.";
                    }

                    showError(message);
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params =
                        new HashMap<>();

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                params.put(
                        "evidence_id",
                        String.valueOf(evidenceId)
                );

                return params;
            }
        };

        // Allow longer AI processing time
        RetryPolicy retryPolicy =
                new DefaultRetryPolicy(
                        300000,
                        0,
                        1.0f
                );

        request.setRetryPolicy(retryPolicy);

        requestQueue.add(request);
    }



    private void saveReviewedAnalysis() {

        if (currentAnalysisId <= 0) {
            showError("No AI analysis selected for review.");
            return;
        }

        String reviewedText = edtReviewedAnalysis
                .getText()
                .toString()
                .trim();

        if (reviewedText.isEmpty()) {
            edtReviewedAnalysis.setError(
                    "Please enter a reviewed analysis."
            );
            edtReviewedAnalysis.requestFocus();
            return;
        }

        if (reviewedText.getBytes(
                java.nio.charset.StandardCharsets.UTF_8
        ).length > 60000) {
            edtReviewedAnalysis.setError(
                    "Reviewed analysis is too long."
            );
            return;
        }

        final int analysisIdToSave = currentAnalysisId;

        btnSaveReviewedAnalysis.setEnabled(false);
        btnAnalyseEvidence.setEnabled(false);
        spinnerAIEvidence.setEnabled(false);

        progressAI.setVisibility(View.VISIBLE);
        txtAIStatus.setText("Saving reviewed analysis...");

        StringRequest request = new StringRequest(
                Request.Method.POST,
                UPDATE_ANALYSIS_URL,

                response -> {

                    progressAI.setVisibility(View.GONE);
                    btnAnalyseEvidence.setEnabled(!evidenceList.isEmpty());
                    spinnerAIEvidence.setEnabled(true);
                    btnSaveReviewedAnalysis.setEnabled(
                            currentAnalysisId > 0
                    );

                    try {
                        JSONObject json = new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            showError(json.optString(
                                    "message",
                                    "Unable to save reviewed analysis."
                            ));
                            return;
                        }

                        txtAIStatus.setText(
                                "Reviewed analysis saved successfully."
                        );

                        Toast.makeText(
                                AccidentAIActivity.this,
                                "Reviewed analysis saved.",
                                Toast.LENGTH_LONG
                        ).show();

                        // Refresh analyses from the database
                        loadSavedAnalyses();

                    } catch (Exception e) {
                        showError(
                                "Unable to read the save response."
                        );
                    }
                },

                error -> {

                    progressAI.setVisibility(View.GONE);
                    btnAnalyseEvidence.setEnabled(!evidenceList.isEmpty());
                    spinnerAIEvidence.setEnabled(true);
                    btnSaveReviewedAnalysis.setEnabled(
                            currentAnalysisId > 0
                    );

                    showError(
                            "Unable to save reviewed analysis. "
                                    + "Check the server connection."
                    );
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put(
                        "analysis_id",
                        String.valueOf(analysisIdToSave)
                );

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                params.put(
                        "reviewed_analysis",
                        reviewedText
                );

                return params;
            }
        };

        request.setRetryPolicy(
                new DefaultRetryPolicy(
                        30000,
                        0,
                        1.0f
                )
        );

        requestQueue.add(request);
    }

    private void showError(String message) {
        txtAIStatus.setText(message);

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }
}