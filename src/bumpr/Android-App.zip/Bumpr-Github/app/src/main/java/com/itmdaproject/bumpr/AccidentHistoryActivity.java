package com.itmdaproject.bumpr;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccidentHistoryActivity extends AppCompatActivity {

    private static final String HISTORY_URL =
            "http://10.0.2.2/bumpr/get_user_accidents.php";

    private LinearLayout layoutAccidentHistory;
    private ProgressBar progressHistory;
    private TextView tvEmptyHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accident_history);

        layoutAccidentHistory =
                findViewById(R.id.layoutAccidentHistory);

        progressHistory =
                findViewById(R.id.progressHistory);

        tvEmptyHistory =
                findViewById(R.id.tvEmptyHistory);

        loadAccidentHistory();
    }

    private void loadAccidentHistory() {

        SharedPreferences preferences =
                getSharedPreferences("BumprPrefs", MODE_PRIVATE);

        int userId = preferences.getInt("userId", -1);

        if (userId <= 0) {
            Toast.makeText(
                    this,
                    "Please log in to view your accident reports.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        progressHistory.setVisibility(View.VISIBLE);
        tvEmptyHistory.setVisibility(View.GONE);
        layoutAccidentHistory.removeAllViews();

        StringRequest request = new StringRequest(
                Request.Method.POST,
                HISTORY_URL,

                response -> {
                    progressHistory.setVisibility(View.GONE);

                    try {
                        JSONObject json = new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            tvEmptyHistory.setText(
                                    json.optString(
                                            "message",
                                            "Unable to retrieve accident reports."
                                    )
                            );
                            tvEmptyHistory.setVisibility(View.VISIBLE);
                            return;
                        }

                        JSONArray accidents =
                                json.getJSONArray("accidents");

                        if (accidents.length() == 0) {
                            tvEmptyHistory.setText(
                                    "You have not documented any accidents yet."
                            );
                            tvEmptyHistory.setVisibility(View.VISIBLE);
                            return;
                        }

                        for (int i = 0; i < accidents.length(); i++) {
                            JSONObject accident =
                                    accidents.getJSONObject(i);

                            addAccidentCard(accident);
                        }

                    } catch (Exception e) {
                        tvEmptyHistory.setText(
                                "Unable to read accident history."
                        );
                        tvEmptyHistory.setVisibility(View.VISIBLE);
                    }
                },

                error -> {
                    progressHistory.setVisibility(View.GONE);
                    tvEmptyHistory.setText(
                            "Unable to connect to the server."
                    );
                    tvEmptyHistory.setVisibility(View.VISIBLE);
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void addAccidentCard(JSONObject accident) {

        int accidentId = accident.optInt("accident_id");
        String accidentType =
                accident.optString("accident_type");
        String description =
                accident.optString("description");
        String accidentDate =
                accident.optString("accident_datetime");
        int evidenceCount =
                accident.optInt("evidence_count");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);

        int padding = dpToPx(16);
        card.setPadding(padding, padding, padding, padding);

        android.graphics.drawable.GradientDrawable background =
                new android.graphics.drawable.GradientDrawable();

        background.setColor(android.graphics.Color.WHITE);
        background.setCornerRadius(dpToPx(12));
        background.setStroke(
                dpToPx(1),
                android.graphics.Color.rgb(225, 230, 238)
        );

        card.setBackground(background);

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.bottomMargin = dpToPx(12);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(accidentType);
        title.setTextSize(17);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(
                android.graphics.Color.rgb(21, 34, 56)
        );

        TextView details = new TextView(this);
        details.setText(
                "Accident #" + accidentId
                        + "\nDate: " + accidentDate
                        + "\nDescription: " + description
                        + "\nPhotographs: " + evidenceCount
        );

        details.setTextSize(14);
        details.setTextColor(
                android.graphics.Color.rgb(102, 112, 133)
        );

        LinearLayout.LayoutParams detailsParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        detailsParams.topMargin = dpToPx(8);
        details.setLayoutParams(detailsParams);

        card.addView(title);
        card.addView(details);

        layoutAccidentHistory.addView(card);
    }

    private int dpToPx(int dp) {
        return Math.round(
                dp * getResources().getDisplayMetrics().density
        );
    }
}