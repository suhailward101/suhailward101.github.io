package com.itmdaproject.bumpr;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class AccidentPartiesActivity
        extends AppCompatActivity {

    private static final String SAVE_URL =
            "http://10.0.2.2/bumpr/save_accident_party.php";

    private static final String GET_URL =
            "http://10.0.2.2/bumpr/get_accident_parties.php";

    private int accidentId;
    private int userId;

    private Spinner spinnerType;
    private LinearLayout formContainer;
    private TextView txtSavedRecords;
    private Button btnSave;

    private RequestQueue requestQueue;

    private final Map<String, EditText> fields =
            new LinkedHashMap<>();

    private final Map<String, CheckBox> checks =
            new LinkedHashMap<>();

    private final String[] types = {
            "Other Vehicle",
            "Other Driver",
            "Witness",
            "Pedestrian"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accident_parties);

        accidentId = getIntent().getIntExtra(
                "accident_id", -1
        );

        userId = getSharedPreferences(
                "BumprPrefs", MODE_PRIVATE
        ).getInt("userId", -1);

        if (accidentId <= 0 || userId <= 0) {
            Toast.makeText(
                    this,
                    "Invalid accident or login session.",
                    Toast.LENGTH_LONG
            ).show();
            finish();
            return;
        }

        requestQueue = Volley.newRequestQueue(this);

        spinnerType = findViewById(R.id.spinnerPartyType);
        formContainer = findViewById(R.id.partyFormContainer);
        txtSavedRecords = findViewById(R.id.txtSavedRecords);
        btnSave = findViewById(R.id.btnSaveParty);

        TextView txtHeading =
                findViewById(R.id.txtPartyHeading);

        txtHeading.setText(
                "Additional Information - Accident #" + accidentId
        );

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        types
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerType.setAdapter(adapter);

        spinnerType.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        buildForm(position);
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                    }
                }
        );

        btnSave.setOnClickListener(v -> saveRecord());

        findViewById(R.id.btnBackParty)
                .setOnClickListener(v -> finish());

        loadRecords();
    }

    private void buildForm(int position) {

        formContainer.removeAllViews();
        fields.clear();
        checks.clear();

        if (position == 0) {
            addField("registration", "Registration *");
            addField("make", "Make *");
            addField("model", "Model *");
            addField("colour", "Colour *");
            addField("insuranceName", "Insurance company");
            addField("policyNumber", "Policy number");
            addField("ownerName", "Owner name");
            addField("ownerPhone", "Owner phone");
        }

        if (position == 1) {
            addField(
                    "otherVehicleID",
                    "Vehicle ID (from saved vehicles) *"
            );
            addField("fullName", "Driver full name *");
            addField("idNumber", "ID number");
            addField("phone", "Phone number *");
            addField("email", "Email address");
            addField("licenceNumber", "Licence number");
            addField("address", "Address");
        }

        if (position == 2) {
            addField("fullName", "Witness full name *");
            addField("phone", "Phone number *");
            addField("address", "Address *");
            addField("statement", "Witness statement *");
        }

        if (position == 3) {
            addField("fullName", "Pedestrian full name");
            addField("phone", "Phone number");
            addField("address", "Address");
            addCheck("wasInjured", "Pedestrian injured");
            addField(
                    "injuryDescription",
                    "Injury description"
            );
            addCheck(
                    "emergencyServicesCalled",
                    "Emergency services called"
            );
            addField("additionalNotes", "Additional notes");
        }
    }

    private void addField(String key, String hint) {

        EditText input = new EditText(this);

        input.setHint(hint);
        input.setTextSize(15);

        input.setSingleLine(
                !key.equals("statement")
                        && !key.equals("additionalNotes")
                        && !key.equals("injuryDescription")
        );

        input.setPadding(12, 20, 12, 20);

        if (key.equals("otherVehicleID")) {
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
        } else if (
                key.equals("phone")
                        || key.equals("ownerPhone")
        ) {
            input.setInputType(
                    InputType.TYPE_CLASS_PHONE
            );
        } else if (key.equals("email")) {
            input.setInputType(
                    InputType.TYPE_CLASS_TEXT
                            | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            );
        }

        formContainer.addView(input);
        fields.put(key, input);
    }

    private void addCheck(String key, String label) {

        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(label);

        formContainer.addView(checkBox);
        checks.put(key, checkBox);
    }

    private String getType() {

        switch (spinnerType.getSelectedItemPosition()) {
            case 0:
                return "vehicle";
            case 1:
                return "driver";
            case 2:
                return "witness";
            default:
                return "pedestrian";
        }
    }

    private boolean validate() {

        String type = getType();
        String[] required;

        switch (type) {

            case "vehicle":
                required = new String[]{
                        "registration",
                        "make",
                        "model",
                        "colour"
                };
                break;

            case "driver":
                required = new String[]{
                        "otherVehicleID",
                        "fullName",
                        "phone"
                };
                break;

            case "witness":
                required = new String[]{
                        "fullName",
                        "phone",
                        "address",
                        "statement"
                };
                break;

            default:
                required = new String[]{};
        }

        for (String key : required) {

            EditText field = fields.get(key);

            if (field == null
                    || field.getText().toString()
                    .trim().isEmpty()) {

                if (field != null) {
                    field.setError("Required");
                    field.requestFocus();
                }

                return false;
            }
        }

        return true;
    }

    private void saveRecord() {

        if (!validate()) {
            return;
        }

        try {

            JSONObject data = new JSONObject();

            data.put("accident_id", accidentId);
            data.put("user_id", userId);
            data.put("type", getType());

            for (Map.Entry<String, EditText> entry
                    : fields.entrySet()) {

                data.put(
                        entry.getKey(),
                        entry.getValue()
                                .getText()
                                .toString()
                                .trim()
                );
            }

            for (Map.Entry<String, CheckBox> entry
                    : checks.entrySet()) {

                data.put(
                        entry.getKey(),
                        entry.getValue().isChecked()
                );
            }

            btnSave.setEnabled(false);

            JsonObjectRequest request =
                    new JsonObjectRequest(
                            Request.Method.POST,
                            SAVE_URL,
                            data,

                            response -> {

                                btnSave.setEnabled(true);

                                if (response.optBoolean("success")) {

                                    Toast.makeText(
                                            this,
                                            "Information saved successfully.",
                                            Toast.LENGTH_SHORT
                                    ).show();

                                    buildForm(
                                            spinnerType.getSelectedItemPosition()
                                    );

                                    loadRecords();

                                } else {

                                    Toast.makeText(
                                            this,
                                            response.optString(
                                                    "message",
                                                    "Unable to save information."
                                            ),
                                            Toast.LENGTH_LONG
                                    ).show();
                                }
                            },

                            error -> {

                                btnSave.setEnabled(true);

                                Toast.makeText(
                                        this,
                                        "Unable to save information: "
                                                + error.toString(),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                    );

            requestQueue.add(request);

        } catch (Exception e) {

            btnSave.setEnabled(true);

            Toast.makeText(
                    this,
                    e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void loadRecords() {

        StringRequest request = new StringRequest(
                Request.Method.POST,
                GET_URL,

                response -> {

                    try {

                        JSONObject data =
                                new JSONObject(response);

                        if (!data.optBoolean("success")) {

                            txtSavedRecords.setText(
                                    data.optString(
                                            "message",
                                            "Unable to load information."
                                    )
                            );

                            return;
                        }

                        StringBuilder summary =
                                new StringBuilder();

                        appendRecords(
                                summary,
                                "OTHER VEHICLES",
                                data.optJSONArray("vehicles"),
                                "otherVehicleID",
                                "registration",
                                "make",
                                "model"
                        );

                        appendRecords(
                                summary,
                                "OTHER DRIVERS",
                                data.optJSONArray("drivers"),
                                "otherDriverID",
                                "fullName",
                                "phone",
                                "otherVehicleID"
                        );

                        appendRecords(
                                summary,
                                "WITNESSES",
                                data.optJSONArray("witnesses"),
                                "witnessID",
                                "fullName",
                                "phone",
                                "statement"
                        );

                        appendRecords(
                                summary,
                                "PEDESTRIANS",
                                data.optJSONArray("pedestrians"),
                                "pedestrianID",
                                "fullName",
                                "phone",
                                "injuryDescription"
                        );

                        txtSavedRecords.setText(
                                summary.length() == 0
                                        ? "No additional information recorded."
                                        : summary.toString()
                        );

                    } catch (Exception e) {

                        txtSavedRecords.setText(
                                "Unable to display saved information."
                        );
                    }
                },

                error -> txtSavedRecords.setText(
                        "Unable to retrieve saved information."
                )
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params =
                        new LinkedHashMap<>();

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                return params;
            }
        };

        requestQueue.add(request);
    }

    private void appendRecords(
            StringBuilder builder,
            String heading,
            JSONArray records,
            String idKey,
            String firstKey,
            String secondKey,
            String thirdKey
    ) {

        if (records == null || records.length() == 0) {
            return;
        }

        builder.append("\n")
                .append(heading)
                .append("\n");

        for (int i = 0; i < records.length(); i++) {

            JSONObject record =
                    records.optJSONObject(i);

            if (record == null) {
                continue;
            }

            builder.append("ID: ")
                    .append(record.optString(idKey))
                    .append("\n");

            builder.append(firstKey)
                    .append(": ")
                    .append(record.optString(firstKey))
                    .append("\n");

            builder.append(secondKey)
                    .append(": ")
                    .append(record.optString(secondKey))
                    .append("\n");

            builder.append(thirdKey)
                    .append(": ")
                    .append(record.optString(thirdKey))
                    .append("\n\n");
        }
    }
}