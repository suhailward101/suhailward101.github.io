package com.itmdaproject.bumpr;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Set;

import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class AccidentPdfGenerator {

    private static final int PAGE_WIDTH = 595;
    private static final int PAGE_HEIGHT = 842;

    private static final int MARGIN = 45;
    private static final int CONTENT_WIDTH =
            PAGE_WIDTH - (MARGIN * 2);

    private static final int BOTTOM_LIMIT = PAGE_HEIGHT - 65;

    private static final String SERVER_URL =
            "http://10.0.2.2/bumpr/";

    private static final Paint paint = new Paint(
            Paint.ANTI_ALIAS_FLAG
    );

    private static PdfDocument document;
    private static PdfDocument.Page page;
    private static Canvas canvas;

    private static int pageNumber;
    private static float yPosition;
    private static int currentAccidentId;

    private static class EvidenceItem {
        String category;
        Bitmap bitmap;
        String error;

        EvidenceItem(String category, Bitmap bitmap, String error) {
            this.category = category;
            this.bitmap = bitmap;
            this.error = error;
        }
    }

    public static File generate(
            Context context,
            JSONObject accident
    ) throws Exception {

        int accidentId = accident.getInt("accident_id");

        JSONObject additionalInformation =
                fetchAdditionalInformation(context, accidentId);

        JSONArray reviewedAIAnalyses =
                fetchReviewedAIAnalyses(context, accidentId);

        JSONArray evidenceArray =
                accident.optJSONArray("evidence");

        List<EvidenceItem> evidenceItems =
                downloadEvidence(evidenceArray);

        document = new PdfDocument();
        pageNumber = 0;
        currentAccidentId = accidentId;

        File pdfFile = null;

        try {
            startNewPage();

            drawTitle("BUMPR");
            drawSubtitle("ACCIDENT DOCUMENTATION REPORT");

            drawDivider();

            drawSectionHeading("Accident Information");

            drawField(
                    "Accident Reference",
                    "#" + accidentId
            );

            drawField(
                    "Accident Type",
                    accident.optString(
                            "accident_type",
                            "Not specified"
                    )
            );

            drawField(
                    "Date and Time",
                    accident.optString(
                            "accident_datetime",
                            "Not specified"
                    )
            );

            drawField(
                    "Injuries Reported",
                    accident.optBoolean(
                            "injuries_reported",
                            false
                    ) ? "Yes" : "No"
            );

            drawField(
                    "Witnesses Present",
                    accident.optBoolean(
                            "has_witnesses",
                            false
                    ) ? "Yes" : "No"
            );

            drawField(
                    "Latitude",
                    accident.isNull("latitude")
                            ? "Not recorded"
                            : accident.optString("latitude")
            );

            drawField(
                    "Longitude",
                    accident.isNull("longitude")
                            ? "Not recorded"
                            : accident.optString("longitude")
            );

            drawSectionHeading("Accident Description");

            drawWrappedText(
                    accident.optString(
                            "description",
                            "No description provided."
                    ),
                    12,
                    19
            );

            yPosition += 20;

            drawSectionHeading("Photographic Evidence");

            if (evidenceItems.isEmpty()) {
                drawWrappedText(
                        "No photographic evidence was attached "
                                + "to this accident.",
                        12,
                        19
                );
            } else {

                drawField(
                        "Evidence Records",
                        String.valueOf(evidenceItems.size())
                );

                for (int i = 0; i < evidenceItems.size(); i++) {

                    EvidenceItem item = evidenceItems.get(i);

                    drawEvidence(
                            i + 1,
                            item
                    );
                }
            }

            yPosition += 15;

            drawAdditionalInformation(additionalInformation);

            yPosition += 20;

            drawReviewedAIAnalyses(
                    reviewedAIAnalyses,
                    evidenceArray
            );

            finishCurrentPage();

            File reportsDirectory = new File(
                    context.getFilesDir(),
                    "reports"
            );

            if (!reportsDirectory.exists()
                    && !reportsDirectory.mkdirs()) {
                throw new IOException(
                        "Unable to create reports directory."
                );
            }

            pdfFile = new File(
                    reportsDirectory,
                    "Bumpr_Accident_" + accidentId + ".pdf"
            );

            File temporaryFile = new File(
                    reportsDirectory,
                    "Bumpr_Accident_" + accidentId + ".tmp"
            );

            try (FileOutputStream output =
                         new FileOutputStream(temporaryFile)) {
                document.writeTo(output);
            }

            if (pdfFile.exists() && !pdfFile.delete()) {
                throw new IOException(
                        "Unable to replace existing PDF."
                );
            }

            if (!temporaryFile.renameTo(pdfFile)) {
                throw new IOException(
                        "Unable to save generated PDF."
                );
            }

            return pdfFile;

        } finally {

            if (document != null) {
                document.close();
                document = null;
            }

            for (EvidenceItem item : evidenceItems) {
                if (item.bitmap != null
                        && !item.bitmap.isRecycled()) {
                    item.bitmap.recycle();
                }
            }

            page = null;
            canvas = null;
        }
    }

    private static List<EvidenceItem> downloadEvidence(
            JSONArray evidenceArray
    ) {

        List<EvidenceItem> items = new ArrayList<>();

        if (evidenceArray == null) {
            return items;
        }

        for (int i = 0; i < evidenceArray.length(); i++) {

            JSONObject evidence =
                    evidenceArray.optJSONObject(i);

            if (evidence == null) {
                continue;
            }

            String category = evidence.optString(
                    "category",
                    "Uncategorised"
            );

            String imagePath = evidence.optString(
                    "image_path",
                    ""
            );

            Bitmap bitmap = null;
            String error = null;

            try {

                if (imagePath.isEmpty()) {
                    throw new IOException(
                            "Missing image path"
                    );
                }

                URL url = new URL(
                        SERVER_URL + imagePath
                );

                HttpURLConnection connection =
                        (HttpURLConnection) url.openConnection();

                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);

                try {

                    if (connection.getResponseCode() != 200) {
                        throw new IOException(
                                "HTTP " + connection.getResponseCode()
                        );
                    }

                    try (InputStream input =
                                 connection.getInputStream()) {

                        BitmapFactory.Options options =
                                new BitmapFactory.Options();

                        options.inSampleSize = 2;

                        bitmap = BitmapFactory.decodeStream(
                                input,
                                null,
                                options
                        );

                        if (bitmap == null) {
                            throw new IOException(
                                    "Unable to decode photograph"
                            );
                        }
                    }

                } finally {
                    connection.disconnect();
                }

            } catch (Exception e) {
                error = e.getMessage();
            }

            items.add(
                    new EvidenceItem(
                            category,
                            bitmap,
                            error
                    )
            );
        }

        return items;
    }

    private static void startNewPage() {

        if (page != null) {
            finishCurrentPage();
        }

        pageNumber++;

        PdfDocument.PageInfo pageInfo =
                new PdfDocument.PageInfo.Builder(
                        PAGE_WIDTH,
                        PAGE_HEIGHT,
                        pageNumber
                ).create();

        page = document.startPage(pageInfo);
        canvas = page.getCanvas();

        canvas.drawColor(Color.WHITE);

        yPosition = MARGIN;

        if (pageNumber > 1) {
            drawSmallHeader();
        }
    }

    private static void finishCurrentPage() {

        if (page == null) {
            return;
        }

        paint.setColor(Color.GRAY);
        paint.setTextSize(10);
        paint.setTypeface(Typeface.DEFAULT);

        canvas.drawText(
                "Bumpr | Accident #" + currentAccidentId,
                MARGIN,
                PAGE_HEIGHT - 30,
                paint
        );

        String pageText = "Page " + pageNumber;

        canvas.drawText(
                pageText,
                PAGE_WIDTH - MARGIN
                        - paint.measureText(pageText),
                PAGE_HEIGHT - 30,
                paint
        );

        document.finishPage(page);
        page = null;
        canvas = null;
    }

    private static void drawSmallHeader() {

        paint.setColor(Color.rgb(23, 35, 60));
        paint.setTextSize(13);
        paint.setTypeface(Typeface.create(
                Typeface.DEFAULT,
                Typeface.BOLD
        ));

        canvas.drawText(
                "BUMPR ACCIDENT REPORT",
                MARGIN,
                yPosition,
                paint
        );

        yPosition += 25;
        drawDivider();
    }

    private static void drawTitle(String text) {

        paint.setColor(Color.rgb(23, 35, 60));
        paint.setTextSize(28);
        paint.setTypeface(Typeface.create(
                Typeface.DEFAULT,
                Typeface.BOLD
        ));

        canvas.drawText(
                text,
                MARGIN,
                yPosition + 20,
                paint
        );

        yPosition += 38;
    }

    private static void drawSubtitle(String text) {

        paint.setColor(Color.DKGRAY);
        paint.setTextSize(13);
        paint.setTypeface(Typeface.DEFAULT);

        canvas.drawText(
                text,
                MARGIN,
                yPosition,
                paint
        );

        yPosition += 22;
    }

    private static void drawDivider() {

        paint.setColor(Color.LTGRAY);
        paint.setStrokeWidth(1);

        canvas.drawLine(
                MARGIN,
                yPosition,
                PAGE_WIDTH - MARGIN,
                yPosition,
                paint
        );

        yPosition += 20;
    }

    private static void drawSectionHeading(String text) {

        ensureSpace(45);

        paint.setColor(Color.rgb(23, 35, 60));
        paint.setTextSize(15);
        paint.setTypeface(Typeface.create(
                Typeface.DEFAULT,
                Typeface.BOLD
        ));

        canvas.drawText(
                text,
                MARGIN,
                yPosition,
                paint
        );

        yPosition += 25;
    }

    private static void drawField(
            String label,
            String value
    ) {

        paint.setTextSize(11);
        paint.setTypeface(Typeface.DEFAULT);

        drawWrappedText(
                label + ": " + value,
                11,
                17
        );

        yPosition += 5;
    }

    private static void drawWrappedText(
            String text,
            int textSize,
            int lineHeight
    ) {

        paint.setColor(Color.BLACK);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.DEFAULT);

        String[] paragraphs = text.split(
                "\\n",
                -1
        );

        for (String paragraph : paragraphs) {

            String[] words = paragraph.split("\\s+");
            StringBuilder line = new StringBuilder();

            for (String word : words) {

                String candidate =
                        line.length() == 0
                                ? word
                                : line + " " + word;

                if (paint.measureText(candidate)
                        > CONTENT_WIDTH
                        && line.length() > 0) {

                    drawTextLine(
                            line.toString(),
                            lineHeight
                    );

                    line = new StringBuilder(word);

                } else {

                    line = new StringBuilder(candidate);
                }
            }

            if (line.length() > 0) {
                drawTextLine(
                        line.toString(),
                        lineHeight
                );
            }
        }
    }

    private static void drawTextLine(
            String text,
            int lineHeight
    ) {

        ensureSpace(lineHeight + 5);

        paint.setColor(Color.BLACK);

        canvas.drawText(
                text,
                MARGIN,
                yPosition,
                paint
        );

        yPosition += lineHeight;
    }

    private static void ensureSpace(float requiredSpace) {

        if (yPosition + requiredSpace > BOTTOM_LIMIT) {
            startNewPage();
        }
    }

    private static void drawEvidence(
            int evidenceNumber,
            EvidenceItem item
    ) {

        if (item.bitmap == null) {

            ensureSpace(80);

            drawSectionHeading(
                    "Evidence " + evidenceNumber
            );

            drawWrappedText(
                    "Category: " + item.category,
                    11,
                    17
            );

            drawWrappedText(
                    "Photograph unavailable: "
                            + item.error,
                    11,
                    17
            );

            yPosition += 15;
            return;
        }

        Bitmap bitmap = item.bitmap;

        float availableWidth = CONTENT_WIDTH;
        float maxImageHeight = 420;

        float scale = Math.min(
                availableWidth / bitmap.getWidth(),
                maxImageHeight / bitmap.getHeight()
        );

        float imageWidth =
                bitmap.getWidth() * scale;

        float imageHeight =
                bitmap.getHeight() * scale;

        ensureSpace(imageHeight + 95);

        drawSectionHeading(
                "Evidence " + evidenceNumber
        );

        drawWrappedText(
                "Category: " + item.category,
                11,
                17
        );

        yPosition += 10;

        Rect destination = new Rect(
                MARGIN,
                Math.round(yPosition),
                MARGIN + Math.round(imageWidth),
                Math.round(yPosition + imageHeight)
        );

        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);

        canvas.drawBitmap(
                bitmap,
                null,
                destination,
                paint
        );

        yPosition += imageHeight + 25;
    }

    private static JSONObject fetchAdditionalInformation(
            Context context,
            int accidentId
    ) throws Exception {

        int userId = context.getSharedPreferences(
                "BumprPrefs",
                Context.MODE_PRIVATE
        ).getInt("userId", -1);

        if (userId <= 0) {
            throw new IOException("No logged-in user.");
        }

        URL url = new URL(
                "http://10.0.2.2/bumpr/get_accident_parties.php"
        );

        HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(15000);

        connection.setRequestProperty(
                "Content-Type",
                "application/x-www-form-urlencoded; charset=UTF-8"
        );

        String body = "accident_id=" + accidentId
                + "&user_id=" + userId;

        try {
            try (OutputStream output =
                         connection.getOutputStream()) {

                output.write(
                        body.getBytes(StandardCharsets.UTF_8)
                );
            }

            int status = connection.getResponseCode();

            if (status != 200) {
                throw new IOException(
                        "Additional information request failed: "
                                + status
                );
            }

            ByteArrayOutputStream buffer =
                    new ByteArrayOutputStream();

            try (InputStream input =
                         connection.getInputStream()) {

                byte[] bytes = new byte[4096];
                int count;

                while ((count = input.read(bytes)) != -1) {
                    buffer.write(bytes, 0, count);
                }
            }

            JSONObject result = new JSONObject(
                    buffer.toString("UTF-8")
            );

            if (!result.optBoolean("success")) {
                throw new IOException(
                        result.optString(
                                "message",
                                "Unable to retrieve additional information."
                        )
                );
            }

            return result;

        } finally {
            connection.disconnect();
        }
    }


    private static void drawAdditionalRecords(
            String heading,
            JSONArray records,
            String[][] fields
    ) {

        drawSectionHeading(heading);

        if (records == null || records.length() == 0) {

            drawWrappedText(
                    "No records provided.",
                    11,
                    17
            );

            yPosition += 12;
            return;
        }

        for (int i = 0; i < records.length(); i++) {

            JSONObject record = records.optJSONObject(i);

            if (record == null) {
                continue;
            }

            ensureSpace(40);

            drawWrappedText(
                    "Record " + (i + 1),
                    12,
                    19
            );

            for (String[] field : fields) {

                String value = record.optString(
                        field[0],
                        ""
                );

                if (value.isEmpty()
                        || value.equalsIgnoreCase("null")) {
                    continue;
                }

                drawField(field[1], value);
            }

            yPosition += 12;
        }
    }

    private static void drawAdditionalInformation(
            JSONObject data
    ) {

        drawAdditionalRecords(
                "Other Vehicles",
                data.optJSONArray("vehicles"),
                new String[][]{
                        {"registration", "Registration"},
                        {"make", "Make"},
                        {"model", "Model"},
                        {"colour", "Colour"},
                        {"insuranceName", "Insurance"},
                        {"policyNumber", "Policy Number"},
                        {"ownerName", "Owner"},
                        {"ownerPhone", "Owner Phone"}
                }
        );

        drawAdditionalRecords(
                "Other Drivers",
                data.optJSONArray("drivers"),
                new String[][]{
                        {"otherVehicleID", "Vehicle ID"},
                        {"fullName", "Full Name"},
                        {"idNumber", "ID Number"},
                        {"phone", "Phone"},
                        {"email", "Email"},
                        {"licenceNumber", "Licence Number"},
                        {"address", "Address"}
                }
        );

        drawAdditionalRecords(
                "Witness Information",
                data.optJSONArray("witnesses"),
                new String[][]{
                        {"fullName", "Full Name"},
                        {"phone", "Phone"},
                        {"address", "Address"},
                        {"statement", "Statement"}
                }
        );

        drawAdditionalRecords(
                "Pedestrian Information",
                data.optJSONArray("pedestrians"),
                new String[][]{
                        {"fullName", "Full Name"},
                        {"phone", "Phone"},
                        {"address", "Address"},
                        {"wasInjured", "Injured (1 = Yes)"},
                        {"injuryDescription", "Injury Description"},
                        {"emergencyServicesCalled",
                                "Emergency Services Called (1 = Yes)"},
                        {"additionalNotes", "Additional Notes"}
                }
        );
    }

    private static JSONArray fetchReviewedAIAnalyses(
            Context context,
            int accidentId
    ) throws Exception {

        int userId = context.getSharedPreferences(
                "BumprPrefs",
                Context.MODE_PRIVATE
        ).getInt("userId", -1);

        if (userId <= 0) {
            throw new IOException("No logged-in user.");
        }

        URL url = new URL(
                SERVER_URL + "get_accident_ai_analysis.php"
        );

        HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(15000);

        connection.setRequestProperty(
                "Content-Type",
                "application/x-www-form-urlencoded; charset=UTF-8"
        );

        String body =
                "accident_id=" + accidentId
                        + "&user_id=" + userId;

        try {

            try (OutputStream output =
                         connection.getOutputStream()) {

                output.write(
                        body.getBytes(StandardCharsets.UTF_8)
                );
            }

            int status = connection.getResponseCode();

            if (status != HttpURLConnection.HTTP_OK) {
                throw new IOException(
                        "AI analysis request failed: HTTP " + status
                );
            }

            ByteArrayOutputStream buffer =
                    new ByteArrayOutputStream();

            try (InputStream input =
                         connection.getInputStream()) {

                byte[] bytes = new byte[4096];
                int count;

                while ((count = input.read(bytes)) != -1) {
                    buffer.write(bytes, 0, count);
                }
            }

            JSONObject result = new JSONObject(
                    buffer.toString("UTF-8")
            );

            if (!result.optBoolean("success", false)) {
                throw new IOException(
                        result.optString(
                                "message",
                                "Unable to retrieve AI analyses."
                        )
                );
            }

            JSONArray analyses =
                    result.optJSONArray("analyses");

            return analyses == null
                    ? new JSONArray()
                    : analyses;

        } finally {
            connection.disconnect();
        }
    }

    private static void drawReviewedAIAnalyses(
            JSONArray analyses,
            JSONArray evidenceArray
    ) {

        drawSectionHeading(
                "AI-Assisted Evidence Observations"
        );

        drawWrappedText(
                "The following observations were generated "
                        + "with AI assistance and subsequently "
                        + "reviewed by the user. They describe "
                        + "visible photographic evidence only.",
                11,
                17
        );

        yPosition += 15;

        if (analyses == null || analyses.length() == 0) {

            drawWrappedText(
                    "No reviewed AI observations are available.",
                    11,
                    17
            );

            return;
        }

        Set<Integer> includedEvidenceIds = new HashSet<>();

        int includedCount = 0;

        // The endpoint returns newest analyses first.
        // Select the latest REVIEWED analysis for each photo.
        for (int i = 0; i < analyses.length(); i++) {

            JSONObject analysis = analyses.optJSONObject(i);

            if (analysis == null) {
                continue;
            }

            if (!"Reviewed".equalsIgnoreCase(
                    analysis.optString("status", "")
            )) {
                continue;
            }

            int evidenceId =
                    analysis.optInt("evidence_id", -1);

            if (evidenceId <= 0
                    || includedEvidenceIds.contains(evidenceId)) {
                continue;
            }

            // Only include evidence associated with this report.
            int evidenceNumber = -1;
            String category = "Accident Evidence";

            if (evidenceArray != null) {

                for (int j = 0; j < evidenceArray.length(); j++) {

                    JSONObject evidence =
                            evidenceArray.optJSONObject(j);

                    if (evidence == null) {
                        continue;
                    }

                    if (evidence.optInt("evidence_id", -1)
                            == evidenceId) {

                        evidenceNumber = j + 1;

                        category = evidence.optString(
                                "category",
                                "Accident Evidence"
                        );

                        break;
                    }
                }
            }

            if (evidenceNumber < 0) {
                continue;
            }

            String reviewedText = "";

            if (!analysis.isNull("reviewed_analysis")) {
                reviewedText = analysis.optString(
                        "reviewed_analysis", ""
                ).trim();
            }

            if (reviewedText.isEmpty()) {
                continue;
            }

            includedEvidenceIds.add(evidenceId);
            includedCount++;

            ensureSpace(100);

            drawSectionHeading(
                    "Evidence " + evidenceNumber
                            + " - Reviewed AI Observations"
            );

            drawField("Evidence Category", category);

            drawField(
                    "AI Model",
                    analysis.optString("model", "Not specified")
            );

            drawField(
                    "Review Status",
                    "Reviewed"
            );

            drawWrappedText(
                    reviewedText,
                    11,
                    17
            );

            yPosition += 18;
        }

        if (includedCount == 0) {

            drawWrappedText(
                    "No reviewed AI observations are available.",
                    11,
                    17
            );
        }

        yPosition += 12;

        drawWrappedText(
                "Note: These observations are descriptive only. "
                        + "They do not establish accident cause, "
                        + "fault, liability, speed or injury severity.",
                10,
                16
        );
    }
}
