package com.itmdaproject.bumpr;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class AccidentTypeActivity extends AppCompatActivity {

    public static final String EXTRA_ACCIDENT_TYPE = "EXTRA_ACCIDENT_TYPE";

    public static final String TYPE_SINGLE = "SINGLE_VEHICLE";
    public static final String TYPE_MULTIPLE = "MULTIPLE_VEHICLES";
    public static final String TYPE_PEDESTRIAN = "PEDESTRIAN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_accident_type);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        MaterialCardView cardSingleVehicle =
                findViewById(R.id.cardSingleVehicle);

        MaterialCardView cardMultipleVehicles =
                findViewById(R.id.cardMultipleVehicles);

        MaterialCardView cardPedestrian =
                findViewById(R.id.cardPedestrian);

        cardSingleVehicle.setOnClickListener(v ->
                selectAccidentType(TYPE_SINGLE)
        );

        cardMultipleVehicles.setOnClickListener(v ->
                selectAccidentType(TYPE_MULTIPLE)
        );

        cardPedestrian.setOnClickListener(v ->
                selectAccidentType(TYPE_PEDESTRIAN)
        );
    }

    private void selectAccidentType(String type) {

        boolean injuriesReported = getIntent()
                .getBooleanExtra("INJURIES_REPORTED", false);

        Intent intent = new Intent(
                AccidentTypeActivity.this,
                GuidedAccidentActivity.class
        );

        intent.putExtra(
                EXTRA_ACCIDENT_TYPE,
                type
        );

        intent.putExtra(
                "INJURIES_REPORTED",
                injuriesReported
        );

        startActivity(intent);
    }
}
