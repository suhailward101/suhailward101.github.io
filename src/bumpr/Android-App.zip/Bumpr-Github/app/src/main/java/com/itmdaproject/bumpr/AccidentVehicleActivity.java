package com.itmdaproject.bumpr;

import android.os.Bundle;
import android.content.Intent;
import android.widget.*;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccidentVehicleActivity
        extends AppCompatActivity {

    private static final String BASE_URL =
            "http://10.0.2.2/bumpr/";

    private int accidentId;
    private int userId;
    private int selectedVehicleId = -1;

    private LinearLayout vehicleContainer;
    private Button btnContinue;
    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        accidentId = getIntent()
                .getIntExtra("accident_id", -1);

        userId = getSharedPreferences(
                "BumprPrefs", MODE_PRIVATE
        ).getInt("userId", -1);

        if (accidentId <= 0 || userId <= 0) {
            Toast.makeText(this,
                    "Invalid accident or session",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        queue = Volley.newRequestQueue(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView heading = new TextView(this);
        heading.setText("Select Accident Vehicle");
        heading.setTextSize(22);
        root.addView(heading);

        ScrollView scrollView = new ScrollView(this);

        vehicleContainer = new LinearLayout(this);
        vehicleContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        scrollView.addView(vehicleContainer);

        root.addView(scrollView,
                new LinearLayout.LayoutParams(
                        -1, 0, 1
                ));

        btnContinue = new Button(this);
        btnContinue.setText("Save and Continue");
        root.addView(btnContinue);

        setContentView(root);

        btnContinue.setOnClickListener(
                v -> saveSelectedVehicle()
        );

        loadVehicles();
    }

    private void loadVehicles() {

        StringRequest request = new StringRequest(
                Request.Method.POST,
                BASE_URL + "get_user_vehicles.php",

                response -> {
                    try {
                        JSONObject json =
                                new JSONObject(response);

                        if (!json.optBoolean("success")) {
                            showMessage(json.optString(
                                    "message",
                                    "Unable to load vehicles"
                            ));
                            return;
                        }

                        JSONArray vehicles =
                                json.optJSONArray("vehicles");

                        vehicleContainer.removeAllViews();

                        if (vehicles == null ||
                                vehicles.length() == 0) {
                            showMessage(
                                    "No registered vehicles found"
                            );
                            return;
                        }

                        RadioGroup group =
                                new RadioGroup(this);

                        for (int i = 0;
                             i < vehicles.length(); i++) {

                            JSONObject vehicle =
                                    vehicles.getJSONObject(i);

                            int id = vehicle.getInt(
                                    "vehicleID"
                            );

                            String label =
                                    vehicle.optString(
                                            "registrationNumber"
                                    ) + " - " +
                                            vehicle.optString(
                                                    "vehicleMake"
                                            ) + " " +
                                            vehicle.optString(
                                                    "vehicleModel"
                                            );


                            RadioButton radio = new RadioButton(this);

                            radio.setId(View.generateViewId());
                            radio.setText(label);
                            radio.setTag(id);

                            group.addView(radio);
                        }

                        group.setOnCheckedChangeListener(
                                (radioGroup, checkedId) -> {

                                    RadioButton selected =
                                            radioGroup.findViewById(
                                                    checkedId
                                            );

                                    if (selected != null) {
                                        selectedVehicleId =
                                                (int) selected.getTag();
                                    }
                                }
                        );

                        vehicleContainer.addView(group);

                    } catch (Exception e) {
                        showMessage(
                                "Invalid vehicle response"
                        );
                    }
                },

                error -> showMessage(
                        "Unable to load vehicles: " + error
                )
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params =
                        new HashMap<>();

                params.put("user_id",
                        String.valueOf(userId));

                return params;
            }
        };

        queue.add(request);
    }

    private void saveSelectedVehicle() {

        if (selectedVehicleId <= 0) {
            showMessage("Please select a vehicle");
            return;
        }

        btnContinue.setEnabled(false);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                BASE_URL + "update_accident_vehicle.php",

                response -> {
                    btnContinue.setEnabled(true);

                    try {
                        JSONObject json =
                                new JSONObject(response);

                        if (json.optBoolean("success")) {

                            Intent intent = new Intent(
                                    this,
                                    AccidentVehicleActivity.class
                            );

                            intent.putExtra(
                                    "accident_id", accidentId
                            );

                            startActivity(intent);
                            finish();

                        } else {
                            showMessage(json.optString(
                                    "message",
                                    "Unable to save vehicle"
                            ));
                        }

                    } catch (Exception e) {
                        showMessage("Invalid server response");
                    }
                },

                error -> {
                    btnContinue.setEnabled(true);
                    showMessage("Network error: " + error);
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params =
                        new HashMap<>();

                params.put("accident_id",
                        String.valueOf(accidentId));

                params.put("vehicle_id",
                        String.valueOf(selectedVehicleId));

                params.put("user_id",
                        String.valueOf(userId));

                return params;
            }
        };

        queue.add(request);
    }

    private void showMessage(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }
}
