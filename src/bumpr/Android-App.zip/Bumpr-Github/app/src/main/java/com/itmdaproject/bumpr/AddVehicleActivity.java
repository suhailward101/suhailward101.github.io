
package com.itmdaproject.bumpr;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class AddVehicleActivity extends AppCompatActivity {

    private EditText etRegistration;
    private EditText etMake;
    private EditText etModel;
    private EditText etYear;
    private EditText etColour;
    private EditText etInsurance;

    private Button btnSaveVehicle;
    private RequestQueue requestQueue;

    private static final String ADD_VEHICLE_URL =
            "http://10.0.2.2/bumpr/add_vehicle.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        etRegistration = findViewById(R.id.etRegistration);
        etMake = findViewById(R.id.etMake);
        etModel = findViewById(R.id.etModel);
        etYear = findViewById(R.id.etYear);
        etColour = findViewById(R.id.etColour);
        etInsurance = findViewById(R.id.etInsurance);

        btnSaveVehicle = findViewById(R.id.btnSaveVehicle);

        requestQueue = Volley.newRequestQueue(this);

        findViewById(R.id.btnBackAddVehicle)
                .setOnClickListener(v -> finish());

        btnSaveVehicle.setOnClickListener(v -> saveVehicle());
    }

    private void saveVehicle() {

        String registration =
                etRegistration.getText().toString().trim();

        String make =
                etMake.getText().toString().trim();

        String model =
                etModel.getText().toString().trim();

        String year =
                etYear.getText().toString().trim();

        String colour =
                etColour.getText().toString().trim();

        String insurance =
                etInsurance.getText().toString().trim();

        if (registration.isEmpty()) {
            etRegistration.setError("Enter registration number");
            etRegistration.requestFocus();
            return;
        }

        if (make.isEmpty()) {
            etMake.setError("Enter vehicle make");
            etMake.requestFocus();
            return;
        }

        if (model.isEmpty()) {
            etModel.setError("Enter vehicle model");
            etModel.requestFocus();
            return;
        }

        if (year.isEmpty()) {
            etYear.setError("Enter vehicle year");
            etYear.requestFocus();
            return;
        }

        int vehicleYear;

        try {
            vehicleYear = Integer.parseInt(year);
        } catch (NumberFormatException e) {
            etYear.setError("Enter a valid year");
            etYear.requestFocus();
            return;
        }

        int currentYear = Calendar.getInstance()
                .get(Calendar.YEAR);

        if (vehicleYear < 1886 || vehicleYear > currentYear + 1) {
            etYear.setError("Enter a valid vehicle year");
            etYear.requestFocus();
            return;
        }

        if (colour.isEmpty()) {
            etColour.setError("Enter vehicle colour");
            etColour.requestFocus();
            return;
        }

        Map<String, String> params = new HashMap<>();

        params.put("registrationNumber", registration);
        params.put("vehicleMake", make);
        params.put("vehicleModel", model);
        params.put("vehicleYear", year);
        params.put("vehicleColour", colour);
        params.put("insurancePolicyNumber", insurance);

        btnSaveVehicle.setEnabled(false);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                ADD_VEHICLE_URL,

                response -> {

                    btnSaveVehicle.setEnabled(true);

                    if (response.trim().equalsIgnoreCase("success")) {

                        Toast.makeText(
                                AddVehicleActivity.this,
                                "Vehicle saved successfully",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();

                    } else {

                        Toast.makeText(
                                AddVehicleActivity.this,
                                "Failed to save vehicle: " + response,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {

                    btnSaveVehicle.setEnabled(true);

                    Toast.makeText(
                            AddVehicleActivity.this,
                            "Network error: " + error,
                            Toast.LENGTH_LONG
                    ).show();
                }

        ) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };

        requestQueue.add(request);
    }
}