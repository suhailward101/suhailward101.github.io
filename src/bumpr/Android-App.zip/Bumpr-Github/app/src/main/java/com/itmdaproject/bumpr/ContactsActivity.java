package com.itmdaproject.bumpr;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ContactsActivity extends AppCompatActivity {

    private EditText etContactName;
    private EditText etPhoneNumber;
    private EditText etRelationship;

    private LinearLayout layoutContactList;
    private TextView txtEmptyContacts;

    private RequestQueue requestQueue;

    private String selectedContactID = null;

    private static final String BASE_URL =
            "http://10.0.2.2/bumpr/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        etContactName = findViewById(R.id.etContactName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etRelationship = findViewById(R.id.etRelationship);

        layoutContactList = findViewById(R.id.layoutContactList);
        txtEmptyContacts = findViewById(R.id.txtEmptyContacts);

        Button btnAddContact = findViewById(R.id.btnAddContact);
        Button btnUpdateContact = findViewById(R.id.btnUpdateContact);
        Button btnDeleteContact = findViewById(R.id.btnDeleteContact);

        requestQueue = Volley.newRequestQueue(this);

        findViewById(R.id.btnBackContacts)
                .setOnClickListener(v -> finish());

        btnAddContact.setOnClickListener(v -> saveContact());

        btnUpdateContact.setOnClickListener(v -> updateContact());

        btnDeleteContact.setOnClickListener(v -> deleteContact());

        loadContacts();
    }

    private void loadContacts() {

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                BASE_URL + "get_contacts.php",
                null,
                this::displayContacts,
                error -> showMessage(
                        "Failed to load contacts: " + error
                )
        );

        requestQueue.add(request);
    }

    private void displayContacts(JSONArray contacts) {

        layoutContactList.removeAllViews();

        boolean hasContacts = contacts.length() > 0;

        txtEmptyContacts.setVisibility(
                hasContacts ? View.GONE : View.VISIBLE
        );

        layoutContactList.setVisibility(
                hasContacts ? View.VISIBLE : View.GONE
        );

        for (int i = 0; i < contacts.length(); i++) {

            JSONObject contact = contacts.optJSONObject(i);

            if (contact == null) {
                continue;
            }

            String id = contact.optString("contactID", "");
            String name = contact.optString("contactName", "");
            String phone = contact.optString("phoneNumber", "");
            String relationship = contact.optString("relationship", "");

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(16), dp(14), dp(16), dp(14));
            item.setBackgroundResource(
                    R.drawable.grey_input_background
            );

            LinearLayout.LayoutParams itemParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            itemParams.setMargins(0, dp(8), 0, 0);

            TextView nameText = new TextView(this);
            nameText.setText(name);
            nameText.setTextSize(16);
            nameText.setTextColor(Color.rgb(30, 41, 59));
            nameText.setTypeface(
                    null,
                    android.graphics.Typeface.BOLD
            );

            TextView detailsText = new TextView(this);
            detailsText.setText(
                    relationship + " • " + phone
            );
            detailsText.setTextSize(14);
            detailsText.setTextColor(Color.rgb(100, 116, 139));

            item.addView(nameText);
            item.addView(detailsText);

            item.setOnClickListener(v -> {

                selectedContactID = id;

                etContactName.setText(name);
                etPhoneNumber.setText(phone);
                etRelationship.setText(relationship);

                showMessage("Selected: " + name);
            });

            layoutContactList.addView(item, itemParams);
        }
    }

    private boolean validateFields() {

        String name = etContactName.getText().toString().trim();
        String phone = etPhoneNumber.getText().toString().trim();
        String relationship =
                etRelationship.getText().toString().trim();

        if (name.isEmpty()) {
            etContactName.setError("Enter a contact name");
            return false;
        }

        if (phone.isEmpty()) {
            etPhoneNumber.setError("Enter a phone number");
            return false;
        }

        if (!phone.matches("[+0-9 ()-]{7,20}")) {
            etPhoneNumber.setError("Enter a valid phone number");
            return false;
        }

        if (relationship.isEmpty()) {
            etRelationship.setError("Enter a relationship");
            return false;
        }

        return true;
    }

    private Map<String, String> getContactParams() {

        Map<String, String> params = new HashMap<>();

        params.put(
                "contactName",
                etContactName.getText().toString().trim()
        );

        params.put(
                "phoneNumber",
                etPhoneNumber.getText().toString().trim()
        );

        params.put(
                "relationship",
                etRelationship.getText().toString().trim()
        );

        return params;
    }

    private void saveContact() {

        if (!validateFields()) {
            return;
        }

        sendContactRequest(
                "add_contact.php",
                getContactParams()
        );
    }

    private void updateContact() {

        if (selectedContactID == null) {
            showMessage("Select a contact to update");
            return;
        }

        if (!validateFields()) {
            return;
        }

        Map<String, String> params = getContactParams();
        params.put("contactID", selectedContactID);

        sendContactRequest(
                "update_contact.php",
                params
        );
    }

    private void deleteContact() {

        if (selectedContactID == null) {
            showMessage("Select a contact to delete");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Contact")
                .setMessage(
                        "Are you sure you want to delete this contact?"
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {

                    Map<String, String> params = new HashMap<>();
                    params.put("contactID", selectedContactID);

                    sendContactRequest(
                            "delete_contact.php",
                            params
                    );
                })
                .show();
    }

    private void sendContactRequest(
            String endpoint,
            Map<String, String> params
    ) {

        StringRequest request = new StringRequest(
                Request.Method.POST,
                BASE_URL + endpoint,

                response -> {

                    String result = response.trim();

                    if (result.equalsIgnoreCase("success")) {

                        showMessage("Contact saved successfully");

                        clearFields();
                        loadContacts();

                    } else {
                        showMessage("Operation failed: " + result);
                    }
                },

                error -> showMessage(
                        "Network error: " + error
                )
        ) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };

        requestQueue.add(request);
    }

    private void clearFields() {

        selectedContactID = null;

        etContactName.setText("");
        etPhoneNumber.setText("");
        etRelationship.setText("");
    }

    private void showMessage(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }

    private int dp(int value) {

        return (int) (
                value * getResources()
                        .getDisplayMetrics()
                        .density + 0.5f
        );
    }
}
