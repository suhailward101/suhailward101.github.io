package com.itmdaproject.bumpr;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class FileVaultActivity extends AppCompatActivity {

    private LinearLayout layoutDocumentList;
    private LinearLayout layoutEmptyDocuments;

    private RequestQueue requestQueue;

    private static final String DOCUMENTS_URL =
            "http://10.0.2.2/bumpr/get_documents.php";

    private static final String VIEW_DOCUMENT_URL =
            "http://10.0.2.2/bumpr/view_document.php?documentID=";

    private static final String UPDATE_DOCUMENT_URL =
            "http://10.0.2.2/bumpr/update_document.php";

    private static final String DELETE_DOCUMENT_URL =
            "http://10.0.2.2/bumpr/delete_document.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_file_vault);

        layoutDocumentList = findViewById(R.id.layoutDocumentList);
        layoutEmptyDocuments = findViewById(R.id.layoutEmptyDocuments);

        requestQueue = Volley.newRequestQueue(this);

        findViewById(R.id.btnBackFileVault)
                .setOnClickListener(v -> finish());

        findViewById(R.id.btnUploadDocument)
                .setOnClickListener(v -> {

                    Intent intent = new Intent(
                            FileVaultActivity.this,
                            UploadDocumentActivity.class
                    );

                    startActivity(intent);
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDocuments();
    }

    private void loadDocuments() {

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                DOCUMENTS_URL,
                null,

                this::displayDocuments,

                error -> {

                    Log.e(
                            "FileVaultDebug",
                            "Document loading failed",
                            error
                    );

                    Toast.makeText(
                            FileVaultActivity.this,
                            "Failed to load documents",
                            Toast.LENGTH_LONG
                    ).show();
                }
        );

        requestQueue.add(request);
    }

    private void displayDocuments(JSONArray documents) {

        layoutDocumentList.removeAllViews();

        if (documents.length() == 0) {

            layoutEmptyDocuments.setVisibility(View.VISIBLE);
            layoutDocumentList.setVisibility(View.GONE);
            return;
        }

        layoutEmptyDocuments.setVisibility(View.GONE);
        layoutDocumentList.setVisibility(View.VISIBLE);

        for (int i = 0; i < documents.length(); i++) {

            JSONObject document = documents.optJSONObject(i);

            if (document == null) {
                continue;
            }

            String documentID = document.optString("documentID", "");
            String documentName = document.optString(
                    "documentName", "Unnamed Document"
            );
            String documentType = document.optString(
                    "documentType", ""
            );
            String documentPath = document.optString(
                    "documentPath", ""
            );

            LinearLayout documentItem = new LinearLayout(this);
            documentItem.setOrientation(LinearLayout.VERTICAL);
            documentItem.setPadding(
                    dp(16), dp(14), dp(16), dp(14)
            );
            documentItem.setBackgroundResource(
                    R.drawable.grey_input_background
            );

            LinearLayout.LayoutParams itemParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            itemParams.setMargins(0, dp(10), 0, 0);

            TextView nameText = new TextView(this);
            nameText.setText(documentName);
            nameText.setTextSize(16);
            nameText.setTextColor(Color.rgb(30, 41, 59));
            nameText.setTypeface(null, Typeface.BOLD);

            TextView typeText = new TextView(this);
            typeText.setText(documentType);
            typeText.setTextSize(13);
            typeText.setTextColor(Color.rgb(100, 116, 139));

            LinearLayout.LayoutParams typeParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );
            typeParams.setMargins(0, dp(5), 0, 0);

            documentItem.addView(nameText);
            documentItem.addView(typeText, typeParams);

            // Tap document information to open the uploaded file.
            LinearLayout documentInfo = new LinearLayout(this);
            documentInfo.setOrientation(LinearLayout.VERTICAL);

            documentItem.removeView(nameText);
            documentItem.removeView(typeText);

            documentInfo.addView(nameText);
            documentInfo.addView(typeText, typeParams);

            documentInfo.setOnClickListener(v ->
                    openDocument(documentID, documentPath)
            );

            documentItem.addView(documentInfo);

            // Edit button.
            Button btnEdit = new Button(this);
            btnEdit.setText("EDIT DOCUMENT");
            btnEdit.setTextSize(13);
            btnEdit.setAllCaps(false);

            LinearLayout.LayoutParams buttonParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(48)
                    );

            buttonParams.setMargins(0, dp(12), 0, 0);

            documentItem.addView(btnEdit, buttonParams);

            btnEdit.setOnClickListener(v ->
                    showEditDialog(
                            documentID,
                            documentName,
                            documentType
                    )
            );

            Button btnDelete = new Button(this);
            btnDelete.setText("DELETE DOCUMENT");
            btnDelete.setTextSize(13);
            btnDelete.setAllCaps(false);

            LinearLayout.LayoutParams deleteParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(48)
                    );

            deleteParams.setMargins(0, dp(6), 0, 0);

            documentItem.addView(btnDelete, deleteParams);

            btnDelete.setOnClickListener(v ->
                    showDeleteConfirmation(
                            documentID,
                            documentName
                    )
            );


            layoutDocumentList.addView(documentItem, itemParams);
        }
    }

    private void openDocument(String documentID, String documentPath) {

        if (documentPath.isEmpty()
                || documentPath.equalsIgnoreCase("null")) {

            Toast.makeText(
                    this,
                    "No uploaded file is available for this document",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        if (documentID.isEmpty()
                || documentID.equalsIgnoreCase("null")) {

            Toast.makeText(
                    this,
                    "Invalid document ID",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        String fileUrl =
                VIEW_DOCUMENT_URL + Uri.encode(documentID);

        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(fileUrl)
        );

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(
                    this,
                    "No application is available to open this document",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void showEditDialog(
            String documentID,
            String currentName,
            String currentType
    ) {

        LinearLayout dialogLayout = new LinearLayout(this);
        dialogLayout.setOrientation(LinearLayout.VERTICAL);
        dialogLayout.setPadding(
                dp(24), dp(12), dp(24), dp(4)
        );

        EditText etName = new EditText(this);
        etName.setHint("Document Name");
        etName.setSingleLine(true);
        etName.setText(currentName);

        EditText etType = new EditText(this);
        etType.setHint("Document Type");
        etType.setSingleLine(true);
        etType.setText(currentType);

        dialogLayout.addView(etName);
        dialogLayout.addView(etType);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Document")
                .setView(dialogLayout)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", null)
                .create();

        dialog.setOnShowListener(v -> {

            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(button -> {

                        String newName = etName.getText()
                                .toString().trim();

                        String newType = etType.getText()
                                .toString().trim();

                        if (newName.isEmpty()) {
                            etName.setError("Enter a document name");
                            return;
                        }

                        if (newType.isEmpty()) {
                            etType.setError("Enter a document type");
                            return;
                        }

                        updateDocument(
                                documentID,
                                newName,
                                newType,
                                dialog
                        );
                    });
        });

        dialog.show();
    }


    private void showDeleteConfirmation(
            String documentID,
            String documentName
    ) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Document")
                .setMessage(
                        "Are you sure you want to delete \""
                                + documentName
                                + "\"?\n\nThis action cannot be undone."
                )
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE", (dialog, which) -> {
                    deleteDocument(documentID);
                })
                .show();
    }

    private void deleteDocument(String documentID) {

        StringRequest request = new StringRequest(
                Request.Method.POST,
                DELETE_DOCUMENT_URL,

                response -> {

                    if (response.trim().equalsIgnoreCase("success")) {

                        Toast.makeText(
                                this,
                                "Document deleted successfully",
                                Toast.LENGTH_SHORT
                        ).show();

                        loadDocuments();

                    } else {

                        Toast.makeText(
                                this,
                                "Failed to delete document",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {

                    Log.e(
                            "FileVaultDebug",
                            "Document deletion failed",
                            error
                    );

                    Toast.makeText(
                            this,
                            "Failed to delete document",
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("documentID", documentID);

                return params;
            }
        };

        requestQueue.add(request);
    }


    private void updateDocument(
            String documentID,
            String documentName,
            String documentType,
            AlertDialog dialog
    ) {

        StringRequest request = new StringRequest(
                Request.Method.POST,
                UPDATE_DOCUMENT_URL,

                response -> {

                    if (response.trim().equalsIgnoreCase("success")) {

                        Toast.makeText(
                                this,
                                "Document updated successfully",
                                Toast.LENGTH_SHORT
                        ).show();

                        dialog.dismiss();
                        loadDocuments();

                    } else {

                        Toast.makeText(
                                this,
                                "Failed to update document",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {

                    Log.e(
                            "FileVaultDebug",
                            "Document update failed",
                            error
                    );

                    Toast.makeText(
                            this,
                            "Failed to update document",
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("documentID", documentID);
                params.put("documentName", documentName);
                params.put("documentType", documentType);

                return params;
            }
        };

        requestQueue.add(request);
    }

    private int dp(int value) {
        return (int) (
                value * getResources()
                        .getDisplayMetrics()
                        .density + 0.5f
        );
    }
}