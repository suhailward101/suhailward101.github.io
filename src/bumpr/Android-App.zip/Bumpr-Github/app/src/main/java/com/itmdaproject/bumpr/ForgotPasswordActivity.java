package com.itmdaproject.bumpr;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;

public class ForgotPasswordActivity extends AppCompatActivity {

    private static final String FORGOT_PASSWORD_URL =
            "http://10.0.2.2/bumpr_api/forgot_password.php";

    private TextInputEditText etEmail;
    private TextInputLayout tilEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_forgot_password);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        etEmail = findViewById(R.id.etEmail);
        tilEmail = findViewById(R.id.tilEmail);

        // Back button
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        // Reset password button
        findViewById(R.id.btnResetPassword).setOnClickListener(
                v -> resetPassword()
        );
    }

    private void resetPassword() {

        String email = etEmail.getText()
                .toString()
                .trim();

        // Validate email
        if (email.isEmpty()) {

            tilEmail.setError("Email is required");
            return;

        }

        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            tilEmail.setError(
                    "Enter a valid email address"
            );

            return;
        }

        tilEmail.setError(null);

        // Create JSON request
        JSONObject requestData = new JSONObject();

        try {

            requestData.put("email", email);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Something went wrong.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Send request to PHP
        JsonObjectRequest request =
                new JsonObjectRequest(
                        Request.Method.POST,
                        FORGOT_PASSWORD_URL,
                        requestData,

                        response -> {

                            try {

                                boolean success =
                                        response.getBoolean("success");

                                String message =
                                        response.getString("message");

                                Toast.makeText(
                                        this,
                                        message,
                                        Toast.LENGTH_LONG
                                ).show();

                            } catch (Exception e) {

                                Toast.makeText(
                                        this,
                                        "Invalid server response.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        },

                        error -> {

                            Log.e("ForgotPassword", "Volley error", error);

                            if (error.networkResponse != null) {

                                Log.e(
                                        "ForgotPassword",
                                        "Status code: " + error.networkResponse.statusCode
                                );

                                if (error.networkResponse.data != null) {

                                    String responseBody =
                                            new String(error.networkResponse.data);

                                    Log.e(
                                            "ForgotPassword",
                                            "Server response: " + responseBody
                                    );
                                }
                            }

                            Toast.makeText(
                                    this,
                                    "Password reset request failed. Check Logcat.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );

        // Add request to Volley queue
        Volley.newRequestQueue(this)
                .add(request);
    }
}