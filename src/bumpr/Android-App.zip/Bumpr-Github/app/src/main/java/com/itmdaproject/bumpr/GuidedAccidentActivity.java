package com.itmdaproject.bumpr;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.provider.MediaStore;
import android.app.AlertDialog;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import android.net.Uri;
import android.content.ClipData;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import android.content.SharedPreferences;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;

import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class GuidedAccidentActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    private static final String SAVE_ACCIDENT_URL =
            "http://10.0.2.2/bumpr/save_accident.php";

    private static final String UPLOAD_EVIDENCE_URL =
            "http://10.0.2.2/bumpr/upload_accident_evidence.php";
    private final Map<String, String> evidencePhotos = new HashMap<>();

    private String currentImageTarget = "";
    private File pendingCameraFile = null;
    private Uri pendingCameraUri = null;

    private ActivityResultLauncher<String> galleryLauncher;
    private ActivityResultLauncher<Intent> cameraLauncher;

    private Button accidentContinueButton;

    private Double currentLatitude = null;
    private Double currentLongitude = null;

    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guided_accident);

        // Initialize Launchers for Gallery and Camera
        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        saveGalleryPhoto(uri);
                    }
                }
        );

        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == RESULT_OK
                            && pendingCameraFile != null
                            && pendingCameraFile.exists()
                            && pendingCameraFile.length() > 0) {

                        evidencePhotos.put(
                                currentImageTarget,
                                pendingCameraFile.getAbsolutePath()
                        );

                        Toast.makeText(
                                this,
                                "Photograph saved successfully.",
                                Toast.LENGTH_SHORT
                        ).show();

                    } else {

                        if (pendingCameraFile != null) {
                            pendingCameraFile.delete();
                        }

                        Toast.makeText(
                                this,
                                "Photograph was not captured.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                    pendingCameraFile = null;
                    pendingCameraUri = null;
                }
        );

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        String rawType = getIntent().getStringExtra(AccidentTypeActivity.EXTRA_ACCIDENT_TYPE);
        final String accidentType = rawType != null ? rawType : AccidentTypeActivity.TYPE_SINGLE;

        TextView tvAccidentTypeHeader = findViewById(R.id.tvAccidentTypeHeader);
        TextView tvDetailQuestion = findViewById(R.id.tvDetailQuestion);
        Spinner spinnerCollisionType = findViewById(R.id.spinnerCollisionType);
        TextInputLayout tilAccidentDescription = findViewById(R.id.tilAccidentDescription);
        LinearLayout layoutEvidenceButtons = findViewById(R.id.layoutEvidenceButtons);

        setupEvidencePrompts(accidentType, layoutEvidenceButtons);

        if (AccidentTypeActivity.TYPE_MULTIPLE.equals(accidentType)) {
            tvAccidentTypeHeader.setText("Two or More Vehicles Accident");
            tvDetailQuestion.setText("Describe what happened:");
            spinnerCollisionType.setVisibility(View.GONE);
            tilAccidentDescription.setVisibility(View.VISIBLE);
        } else if (AccidentTypeActivity.TYPE_PEDESTRIAN.equals(accidentType)) {
            tvAccidentTypeHeader.setText("Pedestrian Accident");
            tvDetailQuestion.setText("Describe the situation / impact:");
            spinnerCollisionType.setVisibility(View.GONE);
            tilAccidentDescription.setVisibility(View.VISIBLE);
        } else {
            // Default: Single Vehicle
            tvAccidentTypeHeader.setText("Single Vehicle Accident");
            tvDetailQuestion.setText("What did the vehicle collide with?");
            spinnerCollisionType.setVisibility(View.VISIBLE);
            tilAccidentDescription.setVisibility(View.GONE);

            String[] items = new String[]{"Wall", "Pole", "Tree", "Other"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
            spinnerCollisionType.setAdapter(adapter);
        }

        MaterialButton btnCaptureLocation = findViewById(R.id.btnCaptureLocation);
        TextView tvLocationData = findViewById(R.id.tvLocationData);
        btnCaptureLocation.setOnClickListener(v -> {
            fetchDeviceLocation(tvLocationData);
        });


        MaterialButton btnContinueToPerson4 =
                findViewById(R.id.btnContinueToPerson4);

        accidentContinueButton = btnContinueToPerson4;

        btnContinueToPerson4.setOnClickListener(v -> {

            String collisionData;

            if (spinnerCollisionType.getVisibility() == View.VISIBLE) {
                collisionData = spinnerCollisionType
                        .getSelectedItem()
                        .toString();
            } else {
                collisionData = tilAccidentDescription.getEditText() != null
                        ? tilAccidentDescription.getEditText()
                        .getText()
                        .toString()
                        .trim()
                        : "";
            }

            if (collisionData.isEmpty()) {
                Toast.makeText(
                        this,
                        "Please enter the accident details.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            RadioGroup rgWitnesses = findViewById(R.id.rgWitnesses);

            boolean hasWitnesses =
                    rgWitnesses.getCheckedRadioButtonId()
                            == R.id.rbWitnessYes;


            boolean injuriesReported = getIntent()
                    .getBooleanExtra("INJURIES_REPORTED", false);

            saveAccidentToDatabase(
                    accidentType,
                    collisionData,
                    injuriesReported,
                    hasWitnesses,
                    btnContinueToPerson4
            );

        });
    }

    private void fetchDeviceLocation(TextView tvLocationData) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            // Request permissions if we don't have them yet
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        // We have permission, get the location
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                currentLatitude = location.getLatitude();
                currentLongitude = location.getLongitude();

                String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                String locString = String.format(Locale.getDefault(), "Lat: %.4f, Lng: %.4f", currentLatitude, currentLongitude);

                tvLocationData.setText("Location: " + locString + "\nTime: " + timestamp);
                Toast.makeText(this, "GPS Location & Timestamp Captured", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Unable to get location. Ensure GPS is enabled.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Location permission granted. Try capturing again.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupEvidencePrompts(String accidentType, LinearLayout container) {
        if (container == null) return;
        container.removeAllViews();

        String[] prompts;
        if (AccidentTypeActivity.TYPE_MULTIPLE.equals(accidentType)) {
            prompts = new String[]{
                    "1. Capture Your Vehicle Damage",
                    "2. Capture Other Vehicle(s) Damage",
                    "3. Capture Registration / License Plates",
                    "4. Capture Traffic Signs & Road Markings",
                    "5. Capture Overall Accident Scene"
            };
        } else if (AccidentTypeActivity.TYPE_PEDESTRIAN.equals(accidentType)) {
            prompts = new String[]{
                    "1. Capture Overall Accident Scene",
                    "2. Capture Pedestrian Crossing (if applicable)",
                    "3. Capture Traffic Signs & Road Markings",
                    "4. Capture Vehicle Damage",
                    "5. Capture Pedestrian-related Evidence"
            };
        } else {
            // Single Vehicle
            prompts = new String[]{
                    "1. Capture Accident Scene",
                    "2. Capture Vehicle Damage",
                    "3. Capture Object / Property Damage",
                    "4. Capture Road & Environment"
            };
        }

        for (int i = 0; i < prompts.length; i++) {
            final String promptText = prompts[i];
            MaterialButton button = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            if (i > 0) {
                params.topMargin = (int) (8 * getResources().getDisplayMetrics().density);
            }
            button.setLayoutParams(params);
            button.setText(promptText);
            button.setTextColor(ContextCompat.getColor(this, R.color.bumpr_navy));
            button.setIconResource(R.drawable.ic_image);
            button.setIconTint(ContextCompat.getColorStateList(this, R.color.bumpr_navy));

            button.setOnClickListener(v -> {
                showImagePickerDialog(promptText);
            });

            container.addView(button);
        }
    }


    private void showImagePickerDialog(String promptText) {

        currentImageTarget = promptText;

        String[] options = {
                "Take Photo",
                "Choose from Gallery"
        };

        new AlertDialog.Builder(this)
                .setTitle("Select Image Source")
                .setItems(options, (dialog, which) -> {

                    if (which == 0) {
                        openCamera();
                    } else {
                        galleryLauncher.launch("image/*");
                    }

                })
                .show();
    }

    private void openCamera() {

        try {

            File evidenceDirectory = new File(
                    getFilesDir(),
                    "accident_evidence"
            );

            if (!evidenceDirectory.exists()
                    && !evidenceDirectory.mkdirs()) {
                throw new IOException("Unable to create evidence folder");
            }

            pendingCameraFile = new File(
                    evidenceDirectory,
                    UUID.randomUUID().toString() + ".jpg"
            );

            pendingCameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    pendingCameraFile
            );

            Intent cameraIntent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE
            );

            cameraIntent.putExtra(
                    MediaStore.EXTRA_OUTPUT,
                    pendingCameraUri
            );

            cameraIntent.setClipData(
                    ClipData.newUri(
                            getContentResolver(),
                            "Accident evidence",
                            pendingCameraUri
                    )
            );

            cameraIntent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            );

            if (cameraIntent.resolveActivity(getPackageManager()) != null) {

                cameraLauncher.launch(cameraIntent);

            } else {

                Toast.makeText(
                        this,
                        "No camera application found.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (IOException | IllegalArgumentException e) {

            Toast.makeText(
                    this,
                    "Unable to prepare camera storage.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void saveGalleryPhoto(Uri sourceUri) {

        File evidenceDirectory = new File(
                getFilesDir(),
                "accident_evidence"
        );

        if (!evidenceDirectory.exists()
                && !evidenceDirectory.mkdirs()) {

            Toast.makeText(
                    this,
                    "Unable to create evidence folder.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String mimeType = getContentResolver().getType(sourceUri);

        String extension;

        if ("image/png".equals(mimeType)) {
            extension = ".png";
        } else if ("image/webp".equals(mimeType)) {
            extension = ".webp";
        } else if ("image/jpeg".equals(mimeType)) {
            extension = ".jpg";
        } else {
            Toast.makeText(
                    this,
                    "Unsupported image format. Please select a JPEG, PNG or WebP image.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        File destinationFile = new File(
                evidenceDirectory,
                UUID.randomUUID().toString() + extension
        );

        try (
                InputStream inputStream =
                        getContentResolver().openInputStream(sourceUri);

                FileOutputStream outputStream =
                        new FileOutputStream(destinationFile)
        ) {

            if (inputStream == null) {
                throw new IOException("Unable to open selected image");
            }

            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            if (destinationFile.length() == 0) {
                throw new IOException("Selected image was empty");
            }

            evidencePhotos.put(
                    currentImageTarget,
                    destinationFile.getAbsolutePath()
            );

            Toast.makeText(
                    this,
                    "Gallery photograph saved successfully.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (IOException e) {

            destinationFile.delete();

            Toast.makeText(
                    this,
                    "Unable to save selected photograph.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void saveAccidentToDatabase(
            String accidentType,
            String description,
            boolean injuriesReported,
            boolean hasWitnesses,
            Button continueButton
    ) {

        if (savedAccidentId > 0) {
            Toast.makeText(
                    this,
                    "This accident has already been saved.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences("BumprPrefs", MODE_PRIVATE);

        int userId = preferences.getInt("userId", -1);

        if (userId <= 0) {
            Toast.makeText(
                    this,
                    "Please log in before saving an accident.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        String databaseAccidentType;

        switch (accidentType) {
            case AccidentTypeActivity.TYPE_MULTIPLE:
                databaseAccidentType = "Two or More Vehicles";
                break;

            case AccidentTypeActivity.TYPE_PEDESTRIAN:
                databaseAccidentType = "Pedestrian";
                break;

            default:
                databaseAccidentType = "Single Vehicle";
                break;
        }

        continueButton.setEnabled(false);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                SAVE_ACCIDENT_URL,

                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);

                        boolean success =
                                jsonResponse.optBoolean("success", false);

                        String message =
                                jsonResponse.optString("message", "");

                        if (success) {

                            int accidentId =
                                    jsonResponse.optInt("accident_id", -1);

                            if (accidentId <= 0) {
                                continueButton.setEnabled(true);

                                Toast.makeText(
                                        this,
                                        "Accident saved, but no valid ID was returned.",
                                        Toast.LENGTH_LONG
                                ).show();
                                return;
                            }

                            savedAccidentId = accidentId;

                            uploadAccidentEvidence(
                                    accidentId,
                                    continueButton
                            );

                        } else {
                            continueButton.setEnabled(true);

                            Toast.makeText(
                                    this,
                                    message,
                                    Toast.LENGTH_LONG
                            ).show();
                        }

                    } catch (Exception e) {
                        continueButton.setEnabled(true);

                        Toast.makeText(
                                this,
                                "Unable to read server response.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {
                    continueButton.setEnabled(true);

                    String errorMessage = "Unable to save accident.";

                    if (error.networkResponse != null) {
                        errorMessage += " HTTP "
                                + error.networkResponse.statusCode;
                    } else {
                        errorMessage += " Check the server connection.";
                    }

                    Toast.makeText(
                            this,
                            errorMessage,
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("user_id", String.valueOf(userId));
                params.put("accident_type", databaseAccidentType);
                params.put("accident_description", description);

                params.put(
                        "injuries_reported",
                        injuriesReported ? "1" : "0"
                );

                params.put(
                        "has_witnesses",
                        hasWitnesses ? "1" : "0"
                );

                params.put(
                        "latitude",
                        currentLatitude == null
                                ? ""
                                : String.valueOf(currentLatitude)
                );

                params.put(
                        "longitude",
                        currentLongitude == null
                                ? ""
                                : String.valueOf(currentLongitude)
                );

                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
    private int savedAccidentId = -1;

    private final List<Map.Entry<String, String>> failedUploads =
            new ArrayList<>();

    private void uploadAccidentEvidence(
            int accidentId,
            Button continueButton
    ) {
        if (evidencePhotos.isEmpty()) {
            showUploadResult(accidentId, 0, 0);
            continueButton.setEnabled(true);
            return;
        }

        failedUploads.clear();

        List<Map.Entry<String, String>> photos =
                new ArrayList<>(evidencePhotos.entrySet());

        continueButton.setEnabled(false);

        uploadNextPhoto(
                accidentId,
                photos,
                0,
                0,
                continueButton
        );
    }

    private void retryFailedUploads(
            int accidentId,
            Button continueButton
    ) {
        if (failedUploads.isEmpty()) {
            Toast.makeText(
                    this,
                    "There are no failed uploads to retry.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        List<Map.Entry<String, String>> photosToRetry =
                new ArrayList<>(failedUploads);

        failedUploads.clear();
        continueButton.setEnabled(false);

        uploadNextPhoto(
                accidentId,
                photosToRetry,
                0,
                0,
                continueButton
        );
    }

    private void uploadNextPhoto(
            int accidentId,
            List<Map.Entry<String, String>> photos,
            int index,
            int successfulUploads,
            Button continueButton
    ) {

        if (index >= photos.size()) {
            continueButton.setEnabled(true);

            showUploadResult(
                    accidentId,
                    successfulUploads,
                    photos.size()
            );
            return;
        }

        Map.Entry<String, String> photo = photos.get(index);

        File imageFile = new File(photo.getValue());

        if (!imageFile.exists() || imageFile.length() == 0
                || imageFile.length() > 10 * 1024 * 1024) {

            failedUploads.add(photo);

            uploadNextPhoto(
                    accidentId,
                    photos,
                    index + 1,
                    successfulUploads,
                    continueButton
            );
            return;
        }

        byte[] imageBytes;

        try (FileInputStream inputStream =
                     new FileInputStream(imageFile);
             ByteArrayOutputStream outputStream =
                     new ByteArrayOutputStream()) {

            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            imageBytes = outputStream.toByteArray();

        } catch (IOException e) {

            failedUploads.add(photo);

            uploadNextPhoto(
                    accidentId,
                    photos,
                    index + 1,
                    successfulUploads,
                    continueButton
            );
            return;
        }

        String mimeType = "image/jpeg";

        String fileName = imageFile.getName().toLowerCase(Locale.ROOT);

        if (fileName.endsWith(".png")) {
            mimeType = "image/png";
        } else if (fileName.endsWith(".webp")) {
            mimeType = "image/webp";
        } else if (fileName.endsWith(".jpg")
                || fileName.endsWith(".jpeg")) {
            mimeType = "image/jpeg";
        }

        Map<String, String> params = new HashMap<>();
        params.put("accident_id", String.valueOf(accidentId));
        params.put("evidence_category", photo.getKey());

        Map<String, VolleyMultipartRequest.DataPart> files =
                new HashMap<>();

        files.put(
                "evidence_image",
                new VolleyMultipartRequest.DataPart(
                        imageFile.getName(),
                        imageBytes,
                        mimeType
                )
        );

        VolleyMultipartRequest request =
                new VolleyMultipartRequest(
                        UPLOAD_EVIDENCE_URL,
                        params,
                        files,
                        response -> {
                            boolean success = false;

                            try {
                                String jsonText = new String(
                                        response.data,
                                        StandardCharsets.UTF_8
                                );

                                JSONObject json = new JSONObject(jsonText);
                                success = json.optBoolean("success", false);

                            } catch (Exception ignored) {
                            }

                            if (!success) {
                                failedUploads.add(photo);
                            }

                            uploadNextPhoto(
                                    accidentId,
                                    photos,
                                    index + 1,
                                    successfulUploads + (success ? 1 : 0),
                                    continueButton
                            );
                        },

                        error -> {
                            failedUploads.add(photo);

                            uploadNextPhoto(
                                    accidentId,
                                    photos,
                                    index + 1,
                                    successfulUploads,
                                    continueButton
                            );
                        }
                );

        request.setRetryPolicy(
                new DefaultRetryPolicy(
                        30000,
                        0,
                        1f
                )
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void showUploadResult(
            int accidentId,
            int uploaded,
            int total
    ) {
        String message;

        if (total == 0) {
            message = "Accident details saved successfully."
                    + "\n\nAccident ID: " + accidentId
                    + "\n\nNo evidence photographs were selected.";

        } else if (uploaded == total) {
            message = "Accident details and all selected photographs "
                    + "were uploaded successfully."
                    + "\n\nAccident ID: " + accidentId
                    + "\nPhotographs uploaded in this attempt: " + uploaded;

        } else {
            message = "Accident details were saved, but some photographs "
                    + "could not be uploaded."
                    + "\n\nAccident ID: " + accidentId
                    + "\nUploaded in this attempt: " + uploaded + " of " + total
                    + "\nFailed: " + failedUploads.size()
                    + "\n\nWould you like to retry the failed photographs?";
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(
                        uploaded == total
                                ? "Documentation Saved"
                                : "Evidence Upload Incomplete"
                )
                .setMessage(message)
                .setPositiveButton("OK", null);

        if (!failedUploads.isEmpty()) {
            builder.setPositiveButton(
                    "Retry Failed",
                    (dialog, which) -> retryFailedUploads(
                            accidentId,
                            accidentContinueButton
                    )
            );

            builder.setNegativeButton("Not Now", null);
        }

        builder.show();
    }
}