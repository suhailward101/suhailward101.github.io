package com.itmdaproject.bumpr;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnAccident).setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    InjuryCheckActivity.class
            );
            startActivity(intent);
        });

        findViewById(R.id.btnAccident).setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    InjuryCheckActivity.class
            );

            startActivity(intent);
        });

        findViewById(R.id.cardVehicles).setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, VehiclesActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.cardContacts).setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ContactsActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.cardFileVault).setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, FileVaultActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.cardReports).setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    ReportsActivity.class
            );
            startActivity(intent);
        });

        findViewById(R.id.navSettings).setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsActivity.class));
        });

        findViewById(R.id.ivProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
        });

        findViewById(R.id.navLogout).setOnClickListener(v -> showLogoutConfirmation());

        String fullName = getSharedPreferences("BumprPrefs", MODE_PRIVATE)
                .getString("fullName", "there");

        TextView tvGreeting = findViewById(R.id.tvGreeting);
        tvGreeting.setText("Hi, " + fullName + "!");

    }

    private void showLogoutConfirmation() {

        new AlertDialog.Builder(this)
                .setTitle("Log out")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Log out", (dialog, which) -> {

                    getSharedPreferences(
                            "BumprPrefs",
                            MODE_PRIVATE
                    )
                            .edit()
                            .clear()
                            .apply();

                    Intent intent = new Intent(
                            this,
                            LoginActivity.class
                    );

                    intent.setFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK
                    );

                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}