package com.itmdaproject.bumpr;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class InjuryCheckActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_injury_check);

        MaterialButton btnNoInjured =
                findViewById(R.id.btnNoInjured);

        MaterialButton btnYesInjured =
                findViewById(R.id.btnYesInjured);

        btnNoInjured.setOnClickListener(v -> {
            openAccidentType(false);
        });

        btnYesInjured.setOnClickListener(v -> {
            Toast.makeText(
                    this,
                    "If anyone is seriously injured, contact emergency services immediately.",
                    Toast.LENGTH_LONG
            ).show();

            openAccidentType(true);
        });
    }

    private void openAccidentType(boolean injuriesReported) {

        Intent intent = new Intent(
                InjuryCheckActivity.this,
                AccidentTypeActivity.class
        );

        intent.putExtra(
                "INJURIES_REPORTED",
                injuriesReported
        );

        startActivity(intent);
    }
}
