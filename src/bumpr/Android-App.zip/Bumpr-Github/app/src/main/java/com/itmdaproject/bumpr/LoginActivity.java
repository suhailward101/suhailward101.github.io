package com.itmdaproject.bumpr;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.util.Patterns;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.tvTabSignUp).setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
            finish();
        });

        findViewById(R.id.tvForgotPassword).setOnClickListener(v -> {
            startActivity(new Intent(this, ForgotPasswordActivity.class));
        });

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            TextInputEditText etEmail = findViewById(R.id.etEmail);
            TextInputEditText etPassword = findViewById(R.id.etPassword);
            TextInputLayout tilEmail = findViewById(R.id.tilEmail);
            TextInputLayout tilPassword = findViewById(R.id.tilPassword);

            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();

            boolean isValid = true;

            if (email.isEmpty()) {
                tilEmail.setError("Email is required");
                isValid = false;
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.setError("Enter a valid email address");
                isValid = false;
            } else {
                tilEmail.setError(null);
            }

            if (password.isEmpty()) {
                tilPassword.setError("Password is required");
                isValid = false;
            } else {
                tilPassword.setError(null);
            }

            if (isValid) {
                String url = "http://10.0.2.2/bumpr_api/login.php";

                JSONObject requestBody = new JSONObject();
                try {
                    requestBody.put("email", email);
                    requestBody.put("password", password);
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }

                JsonObjectRequest request = new JsonObjectRequest(
                        Request.Method.POST,
                        url,
                        requestBody,
                        response -> {
                            try {
                                boolean success = response.getBoolean("success");
                                String message = response.getString("message");

                                if (success) {
                                    int userId = response.getInt("userId");
                                    String fullName = response.getString("fullName");

                                    getSharedPreferences("BumprPrefs", MODE_PRIVATE)
                                            .edit()
                                            .putInt("userId", userId)
                                            .putString("fullName", fullName)
                                            .apply();

                                    startActivity(new Intent(this, HomeActivity.class));
                                    finish();
                                } else {
                                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        },
                        error -> {
                            Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                );

                Volley.newRequestQueue(this).add(request);
            }
        });

    }
}