package com.itmdaproject.bumpr;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.IOException;

public class PdfViewerActivity extends AppCompatActivity {

    private ImageView imagePdfPage;
    private TextView txtPageNumber;
    private TextView txtPdfTitle;
    private Button btnPreviousPage;
    private Button btnNextPage;

    private ParcelFileDescriptor fileDescriptor;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page currentPage;

    private int currentPageIndex = 0;
    private Bitmap currentBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        imagePdfPage = findViewById(R.id.imagePdfPage);
        txtPageNumber = findViewById(R.id.txtPageNumber);
        txtPdfTitle = findViewById(R.id.txtPdfTitle);
        btnPreviousPage = findViewById(R.id.btnPreviousPage);
        btnNextPage = findViewById(R.id.btnNextPage);

        findViewById(R.id.btnClosePdf)
                .setOnClickListener(v -> finish());

        btnPreviousPage.setOnClickListener(v -> {
            showPage(currentPageIndex - 1);
        });

        btnNextPage.setOnClickListener(v -> {
            showPage(currentPageIndex + 1);
        });

        int accidentId = getIntent().getIntExtra(
                "accident_id",
                -1
        );

        if (accidentId <= 0) {
            showError("Invalid accident report.");
            return;
        }

        File reportsDirectory = new File(
                getFilesDir(),
                "reports"
        );

        File pdfFile = new File(
                reportsDirectory,
                "Bumpr_Accident_" + accidentId + ".pdf"
        );

        txtPdfTitle.setText(
                "Accident Report #" + accidentId
        );

        if (!pdfFile.exists()) {
            showError(
                    "PDF not found. Please generate the report first."
            );
            return;
        }

        openPdf(pdfFile);
    }

    private void openPdf(File pdfFile) {

        try {
            fileDescriptor = ParcelFileDescriptor.open(
                    pdfFile,
                    ParcelFileDescriptor.MODE_READ_ONLY
            );

            pdfRenderer = new PdfRenderer(fileDescriptor);

            if (pdfRenderer.getPageCount() == 0) {
                showError("This PDF contains no pages.");
                return;
            }

            showPage(0);

        } catch (Exception e) {
            showError(
                    "Unable to open PDF: " + e.getMessage()
            );
        }
    }

    private void showPage(int pageIndex) {

        if (pdfRenderer == null) {
            return;
        }

        if (pageIndex < 0
                || pageIndex >= pdfRenderer.getPageCount()) {
            return;
        }

        try {
            if (currentPage != null) {
                currentPage.close();
                currentPage = null;
            }

            if (currentBitmap != null) {
                imagePdfPage.setImageDrawable(null);
                currentBitmap.recycle();
                currentBitmap = null;
            }

            currentPage = pdfRenderer.openPage(pageIndex);

            int renderWidth = Math.min(
                    currentPage.getWidth() * 2,
                    1600
            );

            int renderHeight = Math.round(
                    renderWidth
                            * (float) currentPage.getHeight()
                            / currentPage.getWidth()
            );

            currentBitmap = Bitmap.createBitmap(
                    renderWidth,
                    renderHeight,
                    Bitmap.Config.ARGB_8888
            );

            currentBitmap.eraseColor(Color.WHITE);

            currentPage.render(
                    currentBitmap,
                    null,
                    null,
                    PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
            );

            imagePdfPage.setImageBitmap(currentBitmap);

            currentPageIndex = pageIndex;

            txtPageNumber.setText(
                    "Page " + (currentPageIndex + 1)
                            + " of " + pdfRenderer.getPageCount()
            );

            btnPreviousPage.setEnabled(
                    currentPageIndex > 0
            );

            btnNextPage.setEnabled(
                    currentPageIndex < pdfRenderer.getPageCount() - 1
            );

        } catch (Exception e) {
            showError(
                    "Unable to display PDF page."
            );
        }
    }

    private void showError(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();

        txtPageNumber.setText(message);

        btnPreviousPage.setEnabled(false);
        btnNextPage.setEnabled(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (currentPage != null) {
            currentPage.close();
            currentPage = null;
        }

        if (pdfRenderer != null) {
            pdfRenderer.close();
            pdfRenderer = null;
        }

        if (fileDescriptor != null) {
            try {
                fileDescriptor.close();
            } catch (IOException ignored) {
            }
            fileDescriptor = null;
        }

        if (currentBitmap != null) {
            imagePdfPage.setImageDrawable(null);
            currentBitmap.recycle();
            currentBitmap = null;
        }
    }
}
