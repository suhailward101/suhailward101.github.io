package com.itmdaproject.bumpr;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {

    private TextInputEditText etName;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private TextInputEditText etPhone;

    private MaterialButton btnEditProfile;

    private int userId;

    private static final String GET_PROFILE_URL =
            "http://10.0.2.2/bumpr_api/get_profile.php";

    private static final String UPDATE_PROFILE_URL =
            "http://10.0.2.2/bumpr_api/update_profile.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        // Find fields
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etPhone = findViewById(R.id.etPhone);

        btnEditProfile = findViewById(R.id.btnEditProfile);

        // Back button
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        // Get logged-in user's ID
        userId = getSharedPreferences(
                "BumprPrefs",
                MODE_PRIVATE
        ).getInt("userId", -1);

        // If no user is logged in
        if (userId == -1) {

            Toast.makeText(
                    this,
                    "Please log in again.",
                    Toast.LENGTH_LONG
            ).show();

            startActivity(
                    new Intent(
                            this,
                            LoginActivity.class
                    )
            );

            finish();
            return;
        }

        // Load profile information
        loadProfile();

        // Edit / Save button
        btnEditProfile.setOnClickListener(v -> {

            if (etName.isFocusableInTouchMode()) {

                // Currently editing
                saveProfile();

            } else {

                // Start editing
                setFieldsEnabled(true);
            }
        });
    }

    private void loadProfile() {

        JSONObject requestBody = new JSONObject();

        try {

            requestBody.put(
                    "userId",
                    userId
            );

        } catch (JSONException e) {

            e.printStackTrace();

            Toast.makeText(
                    this,
                    "Unable to load profile.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        JsonObjectRequest request =
                new JsonObjectRequest(
                        Request.Method.POST,
                        GET_PROFILE_URL,
                        requestBody,

                        response -> {

                            try {

                                boolean success =
                                        response.getBoolean(
                                                "success"
                                        );

                                if (success) {

                                    // Full Name
                                    etName.setText(
                                            response.getString(
                                                    "fullName"
                                            )
                                    );

                                    // Email
                                    etEmail.setText(
                                            response.getString(
                                                    "email"
                                            )
                                    );

                                    // Phone Number
                                    String phoneNumber =
                                            response.optString(
                                                    "phoneNumber",
                                                    ""
                                            );

                                    if (phoneNumber.equals("null")) {
                                        phoneNumber = "";
                                    }

                                    etPhone.setText(
                                            phoneNumber
                                    );

                                    // Password is never retrieved from the database.
                                    etPassword.setText("");

                                } else {

                                    Toast.makeText(
                                            this,
                                            response.getString(
                                                    "message"
                                            ),
                                            Toast.LENGTH_LONG
                                    ).show();
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                                Toast.makeText(
                                        this,
                                        "Error reading profile.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        },

                        error -> {

                            String errorMessage =
                                    "Network error";

                            if (error.networkResponse != null
                                    && error.networkResponse.data != null) {

                                errorMessage =
                                        new String(
                                                error.networkResponse.data
                                        );

                            } else if (error.getMessage() != null) {

                                errorMessage =
                                        error.getMessage();
                            }

                            Toast.makeText(
                                    this,
                                    errorMessage,
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );

        Volley
                .newRequestQueue(this)
                .add(request);
    }

    private void setFieldsEnabled(boolean enabled) {

        etName.setFocusableInTouchMode(enabled);
        etEmail.setFocusableInTouchMode(enabled);
        etPassword.setFocusableInTouchMode(enabled);
        etPhone.setFocusableInTouchMode(enabled);

        etName.setClickable(enabled);
        etEmail.setClickable(enabled);
        etPassword.setClickable(enabled);
        etPhone.setClickable(enabled);

        if (enabled) {

            btnEditProfile.setText("Save Changes");

        } else {

            // Remove focus from all fields
            etName.clearFocus();
            etEmail.clearFocus();
            etPassword.clearFocus();
            etPhone.clearFocus();

            // Return button to Edit Profile
            btnEditProfile.setText("Edit Profile");
        }
    }

    private void saveProfile() {

        String fullName = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phoneNumber = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (fullName.isEmpty() || email.isEmpty()) {

            Toast.makeText(
                    this,
                    "Full name and email are required.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        JSONObject requestBody = new JSONObject();

        try {

            requestBody.put("userId", userId);
            requestBody.put("fullName", fullName);
            requestBody.put("email", email);
            requestBody.put("phoneNumber", phoneNumber);

            // Only send a password if the user entered a new one
            if (!password.isEmpty()) {
                requestBody.put("password", password);
            }

        } catch (JSONException e) {

            e.printStackTrace();

            Toast.makeText(
                    this,
                    "Unable to save profile.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        JsonObjectRequest request =
                new JsonObjectRequest(
                        Request.Method.POST,
                        UPDATE_PROFILE_URL,
                        requestBody,

                        response -> {

                            try {

                                boolean success =
                                        response.getBoolean("success");

                                String message =
                                        response.getString("message");

                                Toast.makeText(
                                        this,
                                        message,
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (success) {

                                    etPassword.setText("");

                                    setFieldsEnabled(false);
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                                Toast.makeText(
                                        this,
                                        "Error reading server response.",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        },

                        error -> {

                            String errorMessage = "Network error";

                            if (error.networkResponse != null
                                    && error.networkResponse.data != null) {

                                errorMessage =
                                        new String(
                                                error.networkResponse.data
                                        );

                            } else if (error.getMessage() != null) {

                                errorMessage =
                                        error.getMessage();
                            }

                            Toast.makeText(
                                    this,
                                    errorMessage,
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );

        Volley
                .newRequestQueue(this)
                .add(request);
    }
}