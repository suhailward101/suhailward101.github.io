package com.itmdaproject.bumpr;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Login tab
        findViewById(R.id.tvTabLogin).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        // Sign up button
        findViewById(R.id.btnSignUp).setOnClickListener(v -> {

            TextInputEditText etFullName =
                    findViewById(R.id.etFullName);

            TextInputEditText etEmail =
                    findViewById(R.id.etEmail);

            TextInputEditText etPassword =
                    findViewById(R.id.etPassword);

            TextInputEditText etConfirmPassword =
                    findViewById(R.id.etConfirmPassword);

            TextInputLayout tilFullName =
                    findViewById(R.id.tilFullName);

            TextInputLayout tilEmail =
                    findViewById(R.id.tilEmail);

            TextInputLayout tilPassword =
                    findViewById(R.id.tilPassword);

            TextInputLayout tilConfirmPassword =
                    findViewById(R.id.tilConfirmPassword);

            String fullName =
                    etFullName.getText().toString().trim();

            String email =
                    etEmail.getText().toString().trim();

            String password =
                    etPassword.getText().toString().trim();

            String confirmPassword =
                    etConfirmPassword.getText().toString();

            boolean isValid = true;

            // Full name
            if (fullName.isEmpty()) {

                tilFullName.setError(
                        "Full name is required"
                );

                isValid = false;

            } else {

                tilFullName.setError(null);
            }

            // Email
            if (email.isEmpty()) {

                tilEmail.setError(
                        "Email is required"
                );

                isValid = false;

            } else if (!Patterns.EMAIL_ADDRESS
                    .matcher(email)
                    .matches()) {

                tilEmail.setError(
                        "Enter a valid email address"
                );

                isValid = false;

            } else if (!email.contains("@")
                    || !email.substring(email.lastIndexOf("@") + 1).contains(".")) {

                tilEmail.setError(
                        "Enter a valid email address"
                );

                isValid = false;

            } else {

                tilEmail.setError(null);
            }

            // Confirm password
            if (confirmPassword.isEmpty()) {

                tilConfirmPassword.setError(
                        "Please confirm your password"
                );

                isValid = false;

            } else if (!confirmPassword.equals(password)) {

                tilConfirmPassword.setError(
                        "Passwords do not match"
                );

                isValid = false;

            } else {

                tilConfirmPassword.setError(null);
            }

            // Stop if validation failed
            if (!isValid) {
                return;
            }

            // PHP registration URL
            String url =
                    "http://10.0.2.2/bumpr_api/register.php";

            // Create JSON request
            JSONObject requestBody = new JSONObject();

            try {

                requestBody.put(
                        "fullName",
                        fullName
                );

                requestBody.put(
                        "email",
                        email
                );

                requestBody.put(
                        "password",
                        password
                );

            } catch (JSONException e) {

                e.printStackTrace();

                Toast.makeText(
                        this,
                        "Unable to create registration request.",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            // Send JSON request
            JsonObjectRequest request =
                    new JsonObjectRequest(
                            Request.Method.POST,
                            url,
                            requestBody,

                            response -> {

                                try {

                                    boolean success =
                                            response.getBoolean(
                                                    "success"
                                            );

                                    String message =
                                            response.getString(
                                                    "message"
                                            );

                                    if (success) {

                                        Toast.makeText(
                                                this,
                                                message,
                                                Toast.LENGTH_SHORT
                                        ).show();

                                        // Registration PHP currently
                                        // only returns success/message.
                                        // So go to Login rather than
                                        // pretending the user is logged in.

                                        startActivity(
                                                new Intent(
                                                        this,
                                                        LoginActivity.class
                                                )
                                        );

                                        finish();

                                    } else {

                                        Toast.makeText(
                                                this,
                                                message,
                                                Toast.LENGTH_LONG
                                        ).show();
                                    }

                                } catch (JSONException e) {

                                    e.printStackTrace();

                                    Toast.makeText(
                                            this,
                                            "Invalid response from server.",
                                            Toast.LENGTH_LONG
                                    ).show();
                                }
                            },

                            error -> {

                                String errorMessage =
                                        "Network error";

                                if (error.networkResponse != null
                                        && error.networkResponse.data != null) {

                                    errorMessage =
                                            new String(
                                                    error.networkResponse.data
                                            );

                                } else if (error.getMessage() != null) {

                                    errorMessage =
                                            error.getMessage();
                                }

                                android.util.Log.e(
                                        "REGISTER_ERROR",
                                        errorMessage
                                );

                                Toast.makeText(
                                        this,
                                        "Registration failed.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                    );

            Volley
                    .newRequestQueue(this)
                    .add(request);
        });
    }
}