package com.itmdaproject.bumpr;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import android.widget.Button;
import java.io.File;

import android.content.Intent;

import android.content.ClipData;
import android.net.Uri;
import androidx.core.content.FileProvider;

public class ReportDetailsActivity extends AppCompatActivity {

    private static final String DETAILS_URL =
            "http://10.0.2.2/bumpr/get_accident_details.php";

    private static final String BASE_URL =
            "http://10.0.2.2/bumpr/";

    private TextView txtReportId;
    private TextView txtReportStatus;
    private TextView txtReportDate;
    private TextView txtReportType;
    private TextView txtDescription;
    private TextView txtInjuries;
    private TextView txtWitnesses;
    private TextView txtLocation;
    private Button btnSharePdf;
    private TextView txtEvidenceCount;
    private Button btnGeneratePdf;
    private Button btnViewPdf;
    private JSONObject currentAccident;
    private LinearLayout evidenceContainer;
    private ProgressBar progressReportDetails;
    private RequestQueue requestQueue;

    private int accidentId;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_details);

        txtReportId = findViewById(R.id.txtReportId);
        txtReportStatus = findViewById(R.id.txtReportStatus);
        txtReportDate = findViewById(R.id.txtReportDate);
        txtReportType = findViewById(R.id.txtReportType);
        txtDescription = findViewById(R.id.txtDescription);
        txtInjuries = findViewById(R.id.txtInjuries);
        txtWitnesses = findViewById(R.id.txtWitnesses);
        txtLocation = findViewById(R.id.txtLocation);
        txtEvidenceCount = findViewById(R.id.txtEvidenceCount);
        btnGeneratePdf = findViewById(R.id.btnGeneratePdf);

        btnViewPdf = findViewById(R.id.btnViewPdf);

        btnSharePdf = findViewById(R.id.btnSharePdf);

        btnSharePdf.setOnClickListener(v -> {
            sharePdfReport();
        });

        btnViewPdf.setOnClickListener(v -> {

            File pdfFile = new File(
                    new File(getFilesDir(), "reports"),
                    "Bumpr_Accident_" + accidentId + ".pdf"
            );

            if (!pdfFile.exists()) {
                Toast.makeText(
                        this,
                        "Please generate the PDF report first.",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            Intent intent = new Intent(
                    ReportDetailsActivity.this,
                    PdfViewerActivity.class
            );

            intent.putExtra("accident_id", accidentId);

            startActivity(intent);
        });

        evidenceContainer = findViewById(R.id.evidenceContainer);
        progressReportDetails =
                findViewById(R.id.progressReportDetails);

        requestQueue = Volley.newRequestQueue(this);

        btnGeneratePdf = findViewById(R.id.btnGeneratePdf);

        btnGeneratePdf.setEnabled(false);

        btnGeneratePdf.setOnClickListener(v -> {
            generatePdfReport();
        });

        findViewById(R.id.btnAIAnalysis)
                .setOnClickListener(v -> {

                    Intent intent = new Intent(
                            ReportDetailsActivity.this,
                            AccidentAIActivity.class
                    );

                    intent.putExtra("accident_id", accidentId);

                    startActivity(intent);
                });

        findViewById(R.id.btnAdditionalInfo)
                .setOnClickListener(v -> {

                    Intent intent = new Intent(
                            ReportDetailsActivity.this,
                            AccidentPartiesActivity.class
                    );

                    intent.putExtra("accident_id", accidentId);

                    startActivity(intent);
                });

        accidentId = getIntent().getIntExtra("accident_id", -1);

        userId = getSharedPreferences(
                "BumprPrefs",
                MODE_PRIVATE
        ).getInt("userId", -1);

        findViewById(R.id.btnBackToReports)
                .setOnClickListener(v -> finish());

        if (accidentId <= 0 || userId <= 0) {
            showError("Unable to identify the accident or user.");
            return;
        }

        loadAccidentDetails();
    }

    private void loadAccidentDetails() {

        progressReportDetails.setVisibility(View.VISIBLE);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                DETAILS_URL,

                response -> {
                    progressReportDetails.setVisibility(View.GONE);

                    try {
                        JSONObject json = new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            showError(json.optString(
                                    "message",
                                    "Unable to retrieve accident details."
                            ));
                            return;
                        }

                        JSONObject accident =
                                json.getJSONObject("accident");

                        currentAccident = accident;

                        displayAccidentDetails(accident);

                        btnGeneratePdf.setEnabled(true);

                    } catch (Exception e) {
                        showError("Unable to read accident details.");
                    }
                },

                error -> {
                    progressReportDetails.setVisibility(View.GONE);
                    showError("Unable to connect to the server.");
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put(
                        "accident_id",
                        String.valueOf(accidentId)
                );

                params.put(
                        "user_id",
                        String.valueOf(userId)
                );

                return params;
            }
        };

        requestQueue.add(request);
    }

    private void displayAccidentDetails(JSONObject accident) {

        txtReportId.setText(
                "Accident #" + accident.optInt("accident_id")
        );

        txtReportStatus.setText("Documentation saved");

        txtReportDate.setText(
                "Date and time: "
                        + accident.optString("accident_datetime")
        );

        txtReportType.setText(
                "Accident type: "
                        + accident.optString("accident_type")
        );

        txtDescription.setText(
                "Description: "
                        + accident.optString("description")
        );

        txtInjuries.setText(
                "Injuries reported: "
                        + (accident.optBoolean("injuries_reported")
                        ? "Yes" : "No")
        );

        txtWitnesses.setText(
                "Witnesses present: "
                        + (accident.optBoolean("has_witnesses")
                        ? "Yes" : "No")
        );

        if (!accident.isNull("latitude")
                && !accident.isNull("longitude")) {

            txtLocation.setText(
                    "GPS coordinates: "
                            + accident.optDouble("latitude")
                            + ", "
                            + accident.optDouble("longitude")
            );

        } else {
            txtLocation.setText(
                    "GPS coordinates: Not recorded"
            );
        }

        JSONArray evidence = accident.optJSONArray("evidence");

        evidenceContainer.removeAllViews();

        int count = evidence == null ? 0 : evidence.length();

        txtEvidenceCount.setText(
                "Evidence photographs: " + count
        );

        if (count == 0) {
            addEvidenceMessage("No photographs were uploaded.");
            return;
        }

        for (int i = 0; i < count; i++) {
            try {
                JSONObject item = evidence.getJSONObject(i);
                displayEvidence(item);
            } catch (Exception e) {
                addEvidenceMessage(
                        "Unable to display an evidence record."
                );
            }
        }
    }

    private void displayEvidence(JSONObject evidence) {

        String category = evidence.optString(
                "category",
                "Accident Evidence"
        );

        String imagePath = evidence.optString("image_path", "");

        TextView categoryText = new TextView(this);
        categoryText.setText(category);
        categoryText.setTextSize(16);
        categoryText.setTypeface(null, Typeface.BOLD);
        categoryText.setTextColor(Color.parseColor("#17233C"));

        LinearLayout.LayoutParams categoryParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        categoryParams.topMargin = dp(16);
        categoryParams.bottomMargin = dp(8);

        evidenceContainer.addView(categoryText, categoryParams);

        if (imagePath.isEmpty()
                || imagePath.startsWith("/")
                || imagePath.contains("..")
                || imagePath.contains("\\")
                || imagePath.contains(":")) {

            addEvidenceMessage("Invalid evidence image path.");
            return;
        }

        String imageUrl = BASE_URL + imagePath;

        ImageView imageView = new ImageView(this);

        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setBackgroundColor(Color.parseColor("#F3F5F9"));

        LinearLayout.LayoutParams imageParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(220)
                );

        evidenceContainer.addView(imageView, imageParams);

        ImageRequest imageRequest = new ImageRequest(
                imageUrl,

                bitmap -> {
                    imageView.setImageBitmap(bitmap);
                },

                1000,
                1000,
                ImageView.ScaleType.FIT_CENTER,
                android.graphics.Bitmap.Config.RGB_565,

                error -> {
                    imageView.setVisibility(View.GONE);
                    addEvidenceMessage(
                            "Unable to load photograph: " + category
                    );
                }
        );

        requestQueue.add(imageRequest);
    }

    private void addEvidenceMessage(String message) {

        TextView textView = new TextView(this);

        textView.setText(message);
        textView.setTextSize(14);
        textView.setTextColor(Color.parseColor("#667085"));

        textView.setPadding(0, dp(10), 0, dp(10));

        evidenceContainer.addView(textView);
    }

    private void showError(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();

        txtReportStatus.setText(message);
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }

    private void generatePdfReport() {

        if (currentAccident == null) {

            Toast.makeText(
                    this,
                    "Accident details have not loaded yet.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        btnGeneratePdf.setEnabled(false);

        new Thread(() -> {

            try {

                File pdfFile = AccidentPdfGenerator.generate(
                        getApplicationContext(),
                        currentAccident
                );

                runOnUiThread(() -> {

                    btnGeneratePdf.setEnabled(true);

                    Toast.makeText(
                            ReportDetailsActivity.this,
                            "PDF generated: " + pdfFile.getName(),
                            Toast.LENGTH_LONG
                    ).show();
                });

            } catch (Exception e) {

                runOnUiThread(() -> {

                    btnGeneratePdf.setEnabled(true);

                    Toast.makeText(
                            ReportDetailsActivity.this,
                            "PDF generation failed: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }

        }).start();
    }

    private void sharePdfReport() {

        if (accidentId <= 0) {
            Toast.makeText(
                    this,
                    "Invalid accident report.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        File reportsDirectory = new File(
                getFilesDir(),
                "reports"
        );

        File pdfFile = new File(
                reportsDirectory,
                "Bumpr_Accident_" + accidentId + ".pdf"
        );

        if (!pdfFile.exists() || !pdfFile.isFile()) {

            Toast.makeText(
                    this,
                    "Please generate the PDF report first.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        try {

            Uri pdfUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    pdfFile
            );

            Intent shareIntent = new Intent(Intent.ACTION_SEND);

            shareIntent.setType("application/pdf");

            shareIntent.putExtra(
                    Intent.EXTRA_STREAM,
                    pdfUri
            );

            shareIntent.putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Bumpr Accident Report #" + accidentId
            );

            shareIntent.setClipData(
                    ClipData.newRawUri("Accident PDF", pdfUri)
            );

            shareIntent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );

            Intent chooser = Intent.createChooser(
                    shareIntent,
                    "Share Accident Report"
            );

            chooser.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );

            startActivity(chooser);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Unable to share PDF: " + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
