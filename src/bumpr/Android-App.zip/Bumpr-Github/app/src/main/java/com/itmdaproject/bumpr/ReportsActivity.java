
package com.itmdaproject.bumpr;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportsActivity extends AppCompatActivity {

    private static final String REPORTS_URL =
            "http://10.0.2.2/bumpr/get_user_accidents.php";

    private LinearLayout reportsContainer;
    private EditText searchReports;
    private Button btnAllReports;
    private Button btnRecentReports;

    private final List<JSONObject> allReports = new ArrayList<>();

    private boolean showRecent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        reportsContainer = findViewById(R.id.reportsContainer);
        searchReports = findViewById(R.id.edtSearchReports);
        btnAllReports = findViewById(R.id.btnAllReports);
        btnRecentReports = findViewById(R.id.btnRecentReports);

        searchReports.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence s, int start, int count, int after
            ) {}

            @Override
            public void onTextChanged(
                    CharSequence s, int start, int before, int count
            ) {
                displayFilteredReports();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnAllReports.setOnClickListener(v -> {
            showRecent = false;
            updateFilterButtons();
            displayFilteredReports();
        });

        btnRecentReports.setOnClickListener(v -> {
            showRecent = true;
            updateFilterButtons();
            displayFilteredReports();
        });

        updateFilterButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadReports();
    }

    private void loadReports() {

        int userId = getSharedPreferences(
                "BumprPrefs", MODE_PRIVATE
        ).getInt("userId", -1);

        if (userId <= 0) {
            showMessage("Please log in to view your reports.");
            return;
        }

        showMessage("Loading accident reports...");

        StringRequest request = new StringRequest(
                Request.Method.POST,
                REPORTS_URL,

                response -> {
                    try {
                        JSONObject json = new JSONObject(response);

                        if (!json.optBoolean("success", false)) {
                            showMessage(json.optString(
                                    "message",
                                    "Unable to retrieve reports."
                            ));
                            return;
                        }

                        JSONArray accidents =
                                json.optJSONArray("accidents");

                        allReports.clear();

                        if (accidents != null) {
                            for (int i = 0; i < accidents.length(); i++) {
                                allReports.add(accidents.getJSONObject(i));
                            }
                        }

                        displayFilteredReports();

                    } catch (Exception e) {
                        showMessage("Unable to read the server response.");
                    }
                },

                error -> {
                    showMessage("Unable to connect to the Bumpr server.");
                }
        ) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("user_id", String.valueOf(userId));

                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void updateFilterButtons() {

        btnAllReports.setBackgroundResource(
                showRecent
                        ? R.drawable.filter_button_unselected
                        : R.drawable.filter_button_selected
        );

        btnAllReports.setTextColor(
                showRecent ? Color.parseColor("#1F2937") : Color.WHITE
        );

        btnRecentReports.setBackgroundResource(
                showRecent
                        ? R.drawable.filter_button_selected
                        : R.drawable.filter_button_unselected
        );

        btnRecentReports.setTextColor(
                showRecent ? Color.WHITE : Color.parseColor("#1F2937")
        );
    }

    private void displayFilteredReports() {

        reportsContainer.removeAllViews();

        String search = searchReports.getText()
                .toString()
                .toLowerCase()
                .trim();

        int displayed = 0;
        int considered = 0;

        for (JSONObject accident : allReports) {

            if (showRecent && considered >= 3) {
                break;
            }

            considered++;

            String searchableText =
                    accident.optInt("accident_id") + " "
                            + accident.optString("accident_type") + " "
                            + accident.optString("description") + " "
                            + accident.optString("accident_datetime");

            if (!searchableText.toLowerCase().contains(search)) {
                continue;
            }

            addReportCard(accident);
            displayed++;
        }

        if (displayed == 0) {
            showMessage(
                    allReports.isEmpty()
                            ? "No accident documentation available yet."
                            : "No matching accident reports found."
            );
        }
    }

    private void addReportCard(JSONObject accident) {

        int accidentId = accident.optInt("accident_id");

        String accidentType =
                accident.optString("accident_type");

        String description =
                accident.optString("description");

        String date =
                accident.optString("accident_datetime");

        int evidenceCount =
                accident.optInt("evidence_count");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);

        int padding = dp(18);
        card.setPadding(padding, padding, padding, padding);

        card.setBackgroundResource(R.drawable.report_card);

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.bottomMargin = dp(16);
        card.setLayoutParams(cardParams);

        TextView title = createText(
                "Accident #" + accidentId + " — " + accidentType,
                18,
                "#1F2937",
                true
        );

        TextView dateText = createText(
                date,
                14,
                "#6B7280",
                false
        );

        TextView descriptionText = createText(
                description,
                14,
                "#1F2937",
                false
        );

        TextView evidenceText = createText(
                "Evidence photographs: " + evidenceCount,
                14,
                "#6B7280",
                false
        );

        TextView statusText = createText(
                "Documentation saved",
                14,
                "#2E8B57",
                true
        );

        TextView viewText = createText(
                "View Report  →",
                14,
                "#1F2937",
                true
        );

        viewText.setGravity(Gravity.END);

        card.addView(title);
        card.addView(dateText);
        card.addView(descriptionText);
        card.addView(evidenceText);
        card.addView(statusText);
        card.addView(viewText);

        card.setOnClickListener(v -> {

            Intent intent = new Intent(
                    ReportsActivity.this,
                    ReportDetailsActivity.class
            );

            intent.putExtra("accident_id", accidentId);

            startActivity(intent);
        });

        reportsContainer.addView(card);
    }

    private TextView createText(
            String value,
            int size,
            String color,
            boolean bold
    ) {

        TextView textView = new TextView(this);

        textView.setText(value);
        textView.setTextSize(size);
        textView.setTextColor(Color.parseColor(color));

        if (bold) {
            textView.setTypeface(
                    null,
                    android.graphics.Typeface.BOLD
            );
        }

        textView.setPadding(0, 0, 0, dp(9));

        return textView;
    }

    private void showMessage(String message) {

        reportsContainer.removeAllViews();

        TextView textView = createText(
                message,
                16,
                "#FFFFFF",
                false
        );

        textView.setGravity(Gravity.CENTER);

        textView.setPadding(
                dp(12), dp(30), dp(12), dp(30)
        );

        reportsContainer.addView(textView);
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }
}
