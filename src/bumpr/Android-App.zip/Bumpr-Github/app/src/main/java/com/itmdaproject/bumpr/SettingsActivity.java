package com.itmdaproject.bumpr;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    private static final String REPORT_PROBLEM_URL =
            "http://10.0.2.2/bumpr_api/report_problem.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Edit Profile
        findViewById(R.id.rowEditProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
        });

        // Security
        findViewById(R.id.rowSecurity).setOnClickListener(v -> {
            showSecurityDialog();
        });

        // Privacy
        findViewById(R.id.rowPrivacy).setOnClickListener(v -> {
            showPrivacyDialog();
        });

        // Back
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        // Log Out
        findViewById(R.id.rowLogOut).setOnClickListener(
                v -> showLogoutConfirmation()
        );

        // Help & Support
        findViewById(R.id.rowHelpSupport).setOnClickListener(v -> {
            showHelpSupportDialog();
        });

        // Terms & Policies
        findViewById(R.id.rowTermsPolicies).setOnClickListener(v -> {
            showTermsPoliciesDialog();
        });

        // Free Up Space
        findViewById(R.id.rowFreeUpSpace).setOnClickListener(v -> {
            showFreeUpSpaceDialog();
        });

        // Report a Problem
        findViewById(R.id.rowReportProblem).setOnClickListener(v -> {
            showReportProblemDialog();
        });

        // Add Account
        findViewById(R.id.rowAddAccount).setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }

    private void showSecurityDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Security")
                .setMessage(
                        "Your Bumpr account is protected by your email " +
                                "address and password.\n\n" +
                                "You can change your password from your Profile. " +
                                "If you forget your password, use the Forgot Password " +
                                "option on the Login screen."
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void showPrivacyDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Privacy")
                .setMessage(
                        "Bumpr uses your account information to provide " +
                                "the app's features.\n\n" +
                                "Your account information is stored securely and " +
                                "is only used for the functionality provided by the app."
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void showHelpSupportDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Help & Support")
                .setMessage(
                        "Need help using Bumpr?\n\n" +
                                "For account-related issues, you can update your " +
                                "information from Profile or use Forgot Password " +
                                "from the Login screen.\n\n" +
                                "For technical issues or problems with the app, " +
                                "please contact the Bumpr support team at bumprsupport@gmail.com"
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void showTermsPoliciesDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Terms & Policies")
                .setMessage(
                        "By using Bumpr, you agree to use the application " +
                                "responsibly and provide accurate information.\n\n" +
                                "The information provided through Bumpr should not " +
                                "be considered a replacement for emergency services " +
                                "or professional advice."
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void showFreeUpSpaceDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Free Up Space")
                .setMessage(
                        "This will clear temporary Bumpr app data " +
                                "stored on this device.\n\n" +
                                "Your account and saved profile information " +
                                "will not be deleted."
                )
                .setPositiveButton("Clear", (dialog, which) -> {

                    boolean cleared = clearCache(getCacheDir());

                    new AlertDialog.Builder(this)
                            .setTitle(cleared ? "Space Cleared" : "Unable to Clear Everything")
                            .setMessage(cleared
                                    ? "Temporary app data has been cleared successfully."
                                    : "Some temporary files could not be deleted.")
                            .setPositiveButton("OK", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private boolean clearCache(File directory) {

        if (directory == null || !directory.exists()) {
            return true;
        }

        File[] files = directory.listFiles();

        if (files == null) {
            return false;
        }

        boolean success = true;

        for (File file : files) {

            if (file.isDirectory()) {
                if (!clearCache(file)) {
                    success = false;
                }
            }

            if (!file.delete()) {
                success = false;
            }
        }

        return success;
    }

    private void showReportProblemDialog() {

        final android.widget.EditText input =
                new android.widget.EditText(this);

        input.setHint("Describe the problem...");
        input.setGravity(android.view.Gravity.TOP);
        input.setMinLines(4);
        input.setPadding(20, 20, 20, 20);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Report a Problem")
                .setMessage("Please describe the problem you experienced.")
                .setView(input)
                .setPositiveButton("Submit", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> {

            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(v -> {

                        String problem =
                                input.getText().toString().trim();

                        if (problem.isEmpty()) {

                            input.setError(
                                    "Please describe the problem."
                            );

                            return;
                        }

                        sendProblemReport(
                                problem,
                                dialog
                        );
                    });
        });

        dialog.show();
    }

    private void sendProblemReport(
            String problem,
            AlertDialog dialog) {

        android.content.SharedPreferences prefs =
                getSharedPreferences(
                        "BumprPrefs",
                        MODE_PRIVATE
                );

        int userId = prefs.getInt("userId", 0);

        if (userId == 0) {

            Toast.makeText(
                    this,
                    "User session not found.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        JSONObject requestData = new JSONObject();

        try {

            requestData.put("userId", userId);
            requestData.put("problem", problem);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Something went wrong.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        JsonObjectRequest request =
                new JsonObjectRequest(
                        Request.Method.POST,
                        REPORT_PROBLEM_URL,
                        requestData,

                        response -> {

                            try {

                                boolean success =
                                        response.getBoolean("success");

                                String message =
                                        response.getString("message");

                                if (success) {

                                    dialog.dismiss();

                                    new AlertDialog.Builder(this)
                                            .setTitle("Report Submitted")
                                            .setMessage(
                                                    "Thank you for your feedback.\n\n" +
                                                            "Your problem has been sent to the Bumpr support team."
                                            )
                                            .setPositiveButton(
                                                    "OK",
                                                    null
                                            )
                                            .show();

                                } else {

                                    Toast.makeText(
                                            this,
                                            message,
                                            Toast.LENGTH_LONG
                                    ).show();
                                }

                            } catch (Exception e) {

                                Toast.makeText(
                                        this,
                                        "Invalid server response.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        },

                        error -> {

                            Toast.makeText(
                                    this,
                                    "Could not send the report. " +
                                            "Please check your connection.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );

        Volley.newRequestQueue(this)
                .add(request);
    }

    private void showLogoutConfirmation() {

        new AlertDialog.Builder(this)
                .setTitle("Log out")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Log out", (dialog, which) -> {

                    // Clear saved login information
                    getSharedPreferences("BumprPrefs", MODE_PRIVATE)
                            .edit()
                            .clear()
                            .apply();

                    // Go to Login and clear previous activities
                    Intent intent = new Intent(this, LoginActivity.class);

                    intent.setFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK
                    );

                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}