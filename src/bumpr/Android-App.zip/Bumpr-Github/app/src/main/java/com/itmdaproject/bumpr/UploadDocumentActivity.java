package com.itmdaproject.bumpr;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class UploadDocumentActivity extends AppCompatActivity {

    private EditText etDocumentName;
    private EditText etDocumentType;
    private EditText etSelectedFile;

    private Button btnChooseFile;
    private Button btnUploadDocument;

    private Uri selectedFileUri;

    private ActivityResultLauncher<String[]> filePickerLauncher;

    private static final String UPLOAD_URL =
            "http://10.0.2.2/bumpr/add_document.php";

    private static final long MAX_FILE_SIZE = 10L * 1024 * 1024;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_document);

        etDocumentName = findViewById(R.id.etDocumentName);
        etDocumentType = findViewById(R.id.etDocumentType);
        etSelectedFile = findViewById(R.id.etSelectedFile);

        btnChooseFile = findViewById(R.id.btnChooseFile);
        btnUploadDocument = findViewById(R.id.btnUploadDocument);

        findViewById(R.id.btnBackUpload)
                .setOnClickListener(v -> finish());

        etSelectedFile.setFocusable(false);
        etSelectedFile.setClickable(false);

        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        selectedFileUri = uri;
                        etSelectedFile.setText(getFileName(uri));
                    }
                }
        );

        btnChooseFile.setOnClickListener(v ->
                filePickerLauncher.launch(
                        new String[]{
                                "application/pdf",
                                "image/jpeg",
                                "image/png",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        }
                )
        );

        btnUploadDocument.setOnClickListener(v -> validateAndUpload());
    }

    private String getFileName(Uri uri) {

        String fileName = "document";

        try (Cursor cursor = getContentResolver().query(
                uri, null, null, null, null)) {

            if (cursor != null && cursor.moveToFirst()) {

                int index = cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                );

                if (index >= 0) {
                    String name = cursor.getString(index);

                    if (name != null && !name.isEmpty()) {
                        fileName = name;
                    }
                }
            }
        }

        return fileName;
    }

    private void validateAndUpload() {

        String documentName =
                etDocumentName.getText().toString().trim();

        String documentType =
                etDocumentType.getText().toString().trim();

        if (documentName.isEmpty()) {
            etDocumentName.setError("Enter document name");
            return;
        }

        if (documentType.isEmpty()) {
            etDocumentType.setError("Enter document type");
            return;
        }

        if (selectedFileUri == null) {
            Toast.makeText(
                    this,
                    "Please choose a file",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        String fileName = getFileName(selectedFileUri);

        btnUploadDocument.setEnabled(false);
        btnChooseFile.setEnabled(false);
        btnUploadDocument.setText("UPLOADING...");

        Uri fileUri = selectedFileUri;

        new Thread(() -> {

            String result;

            try {
                result = uploadFile(
                        fileUri,
                        fileName,
                        documentName,
                        documentType
                );

            } catch (Exception e) {
                result = "failed: " + e.getMessage();
            }

            String finalResult = result;

            runOnUiThread(() -> {

                btnUploadDocument.setEnabled(true);
                btnChooseFile.setEnabled(true);
                btnUploadDocument.setText("UPLOAD DOCUMENT");

                if (finalResult.trim().equalsIgnoreCase("success")) {

                    Toast.makeText(
                            this,
                            "Document uploaded successfully!",
                            Toast.LENGTH_LONG
                    ).show();

                    etDocumentName.setText("");
                    etDocumentType.setText("");
                    etSelectedFile.setText("");
                    selectedFileUri = null;

                } else {

                    Toast.makeText(
                            this,
                            finalResult,
                            Toast.LENGTH_LONG
                    ).show();
                }
            });

        }).start();
    }

    private String uploadFile(
            Uri fileUri,
            String fileName,
            String documentName,
            String documentType
    ) throws Exception {

        String boundary = "BumprBoundary" +
                UUID.randomUUID().toString();

        String lineEnd = "\r\n";

        HttpURLConnection connection = null;

        try {

            URL url = new URL(UPLOAD_URL);

            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setChunkedStreamingMode(8192);

            connection.setRequestProperty(
                    "Content-Type",
                    "multipart/form-data; boundary=" + boundary
            );

            try (OutputStream output = connection.getOutputStream()) {

                writeTextField(
                        output,
                        boundary,
                        "documentName",
                        documentName
                );

                writeTextField(
                        output,
                        boundary,
                        "documentType",
                        documentType
                );

                String safeFileName = fileName.replaceAll(
                        "[\\r\\n\"\\\\]",
                        "_"
                );

                String mimeType =
                        getContentResolver().getType(fileUri);

                if (mimeType == null) {
                    mimeType = "application/octet-stream";
                }

                String fileHeader =
                        "--" + boundary + lineEnd +
                                "Content-Disposition: form-data; name=\"file\"; filename=\"" +
                                safeFileName + "\"" + lineEnd +
                                "Content-Type: " + mimeType + lineEnd +
                                lineEnd;

                output.write(
                        fileHeader.getBytes(StandardCharsets.UTF_8)
                );

                try (InputStream input =
                             getContentResolver().openInputStream(fileUri)) {

                    if (input == null) {
                        throw new Exception("Cannot open selected file.");
                    }

                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    long totalBytes = 0;

                    while ((bytesRead = input.read(buffer)) != -1) {

                        totalBytes += bytesRead;

                        if (totalBytes > MAX_FILE_SIZE) {
                            throw new Exception(
                                    "File must be 10 MB or smaller."
                            );
                        }

                        output.write(buffer, 0, bytesRead);
                    }
                }

                output.write(lineEnd.getBytes(StandardCharsets.UTF_8));

                String closingBoundary =
                        "--" + boundary + "--" + lineEnd;

                output.write(
                        closingBoundary.getBytes(StandardCharsets.UTF_8)
                );

                output.flush();
            }

            int responseCode = connection.getResponseCode();

            InputStream responseStream =
                    responseCode >= 200 && responseCode < 300
                            ? connection.getInputStream()
                            : connection.getErrorStream();

            if (responseStream == null) {
                return "failed: Server returned HTTP " + responseCode;
            }

            StringBuilder response = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            responseStream,
                            StandardCharsets.UTF_8
                    ))) {

                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }

            String responseText = response.toString().trim();

            if (responseCode < 200 || responseCode >= 300) {
                return responseText.isEmpty()
                        ? "failed: HTTP " + responseCode
                        : responseText;
            }

            return responseText;

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private void writeTextField(
            OutputStream output,
            String boundary,
            String fieldName,
            String value
    ) throws Exception {

        String lineEnd = "\r\n";

        String field =
                "--" + boundary + lineEnd +
                        "Content-Disposition: form-data; name=\"" +
                        fieldName + "\"" + lineEnd +
                        "Content-Type: text/plain; charset=UTF-8" +
                        lineEnd + lineEnd +
                        value + lineEnd;

        output.write(
                field.getBytes(StandardCharsets.UTF_8)
        );
    }
}
