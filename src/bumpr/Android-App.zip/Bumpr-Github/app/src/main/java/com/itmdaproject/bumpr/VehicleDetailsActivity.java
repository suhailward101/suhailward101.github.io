package com.itmdaproject.bumpr;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class VehicleDetailsActivity extends AppCompatActivity {

    private EditText txtVehicleName;
    private EditText txtRegistration;
    private EditText txtMake;
    private EditText txtModel;
    private EditText txtYear;
    private EditText txtColour;
    private EditText txtInsurance;

    private Button btnUpdateVehicle;
    private Button btnDeleteVehicle;

    private RequestQueue requestQueue;
    private String vehicleID;

    private static final String VEHICLES_URL =
            "http://10.0.2.2/bumpr/get_vehicles.php";

    private static final String UPDATE_URL =
            "http://10.0.2.2/bumpr/update_vehicle.php";

    private static final String DELETE_URL =
            "http://10.0.2.2/bumpr/delete_vehicle.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_vehicle_details);

        txtVehicleName = findViewById(R.id.txtVehicleName);
        txtRegistration = findViewById(R.id.txtRegistration);
        txtMake = findViewById(R.id.txtMake);
        txtModel = findViewById(R.id.txtModel);
        txtYear = findViewById(R.id.txtYear);
        txtColour = findViewById(R.id.txtColour);
        txtInsurance = findViewById(R.id.txtInsurance);

        btnUpdateVehicle = findViewById(R.id.btnUpdateVehicle);
        btnDeleteVehicle = findViewById(R.id.btnDeleteVehicle);

        requestQueue = Volley.newRequestQueue(this);

        vehicleID = getIntent().getStringExtra("vehicleID");

        findViewById(R.id.btnBackVehicleDetails)
                .setOnClickListener(v -> finish());

        if (vehicleID == null ||
                !vehicleID.matches("[1-9][0-9]*")) {

            Toast.makeText(
                    this,
                    "Invalid vehicle selected",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        btnUpdateVehicle.setEnabled(false);
        btnDeleteVehicle.setEnabled(false);

        btnUpdateVehicle.setOnClickListener(v -> updateVehicle());

        btnDeleteVehicle.setOnClickListener(v ->
                showDeleteConfirmation()
        );

        loadVehicleDetails();
    }

    private void loadVehicleDetails() {

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                VEHICLES_URL,
                null,

                response -> {

                    boolean vehicleFound = false;

                    for (int i = 0; i < response.length(); i++) {

                        JSONObject vehicle =
                                response.optJSONObject(i);

                        if (vehicle == null) {
                            continue;
                        }

                        String currentID =
                                vehicle.optString("vehicleID", "");

                        if (vehicleID.equals(currentID)) {

                            displayVehicleDetails(vehicle);
                            vehicleFound = true;
                            break;
                        }
                    }

                    if (!vehicleFound) {

                        Toast.makeText(
                                this,
                                "Vehicle not found",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();
                    }
                },

                error -> {

                    Log.e(
                            "VehicleDetails",
                            "Failed to load vehicle",
                            error
                    );

                    Toast.makeText(
                            this,
                            "Failed to load vehicle details",
                            Toast.LENGTH_LONG
                    ).show();
                }
        );

        requestQueue.add(request);
    }

    private void displayVehicleDetails(JSONObject vehicle) {

        String make = vehicle.optString("vehicleMake", "");
        String model = vehicle.optString("vehicleModel", "");

        txtVehicleName.setText(make + " " + model);

        txtRegistration.setText(
                vehicle.optString("registrationNumber", "")
        );

        txtMake.setText(make);
        txtModel.setText(model);

        txtYear.setText(
                vehicle.optString("vehicleYear", "")
        );

        txtColour.setText(
                vehicle.optString("vehicleColour", "")
        );

        String insurance = vehicle.optString(
                "insurancePolicyNumber", ""
        );

        if (insurance.equalsIgnoreCase("null")) {
            insurance = "";
        }

        txtInsurance.setText(insurance);

        btnUpdateVehicle.setEnabled(true);
        btnDeleteVehicle.setEnabled(true);
    }

    private void updateVehicle() {

        String registration =
                txtRegistration.getText().toString().trim();

        String make =
                txtMake.getText().toString().trim();

        String model =
                txtModel.getText().toString().trim();

        String year =
                txtYear.getText().toString().trim();

        String colour =
                txtColour.getText().toString().trim();

        String insurance =
                txtInsurance.getText().toString().trim();

        if (registration.isEmpty()) {
            txtRegistration.setError("Enter registration");
            return;
        }

        if (make.isEmpty()) {
            txtMake.setError("Enter vehicle make");
            return;
        }

        if (model.isEmpty()) {
            txtModel.setError("Enter vehicle model");
            return;
        }

        if (year.isEmpty()) {
            txtYear.setError("Enter vehicle year");
            return;
        }

        int yearNumber;

        try {
            yearNumber = Integer.parseInt(year);
        } catch (NumberFormatException e) {
            txtYear.setError("Enter a valid year");
            return;
        }

        int currentYear =
                Calendar.getInstance().get(Calendar.YEAR);

        if (yearNumber < 1886 ||
                yearNumber > currentYear + 1) {

            txtYear.setError("Enter a valid vehicle year");
            return;
        }

        if (colour.isEmpty()) {
            txtColour.setError("Enter vehicle colour");
            return;
        }

        btnUpdateVehicle.setEnabled(false);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                UPDATE_URL,

                response -> {

                    btnUpdateVehicle.setEnabled(true);

                    if (response.trim().equalsIgnoreCase("success")) {

                        Toast.makeText(
                                this,
                                "Vehicle updated successfully",
                                Toast.LENGTH_SHORT
                        ).show();

                        finish();

                    } else {

                        Toast.makeText(
                                this,
                                "Failed to update vehicle",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {

                    btnUpdateVehicle.setEnabled(true);

                    Log.e(
                            "VehicleDetails",
                            "Vehicle update failed",
                            error
                    );

                    Toast.makeText(
                            this,
                            "Failed to update vehicle",
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("vehicleID", vehicleID);
                params.put("registrationNumber", registration);
                params.put("vehicleMake", make);
                params.put("vehicleModel", model);
                params.put("vehicleYear", year);
                params.put("vehicleColour", colour);
                params.put("insurancePolicyNumber", insurance);

                return params;
            }
        };

        requestQueue.add(request);
    }

    private void showDeleteConfirmation() {

        new AlertDialog.Builder(this)
                .setTitle("Delete Vehicle")
                .setMessage(
                        "Are you sure you want to delete this vehicle?\n\n"
                                + "This action cannot be undone."
                )
                .setNegativeButton("CANCEL", null)
                .setPositiveButton(
                        "DELETE",
                        (dialog, which) -> deleteVehicle()
                )
                .show();
    }

    private void deleteVehicle() {

        btnDeleteVehicle.setEnabled(false);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                DELETE_URL,

                response -> {

                    btnDeleteVehicle.setEnabled(true);

                    if (response.trim().equalsIgnoreCase("success")) {

                        Toast.makeText(
                                this,
                                "Vehicle deleted successfully",
                                Toast.LENGTH_SHORT
                        ).show();

                        finish();

                    } else {

                        Toast.makeText(
                                this,
                                "Failed to delete vehicle",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {

                    btnDeleteVehicle.setEnabled(true);

                    Log.e(
                            "VehicleDetails",
                            "Vehicle deletion failed",
                            error
                    );

                    Toast.makeText(
                            this,
                            "Failed to delete vehicle",
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("vehicleID", vehicleID);

                return params;
            }
        };

        requestQueue.add(request);
    }
}
