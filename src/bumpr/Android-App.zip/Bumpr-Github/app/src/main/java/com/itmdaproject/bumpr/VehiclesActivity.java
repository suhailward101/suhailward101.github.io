package com.itmdaproject.bumpr;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class VehiclesActivity extends AppCompatActivity {

    private LinearLayout layoutVehicleList;
    private LinearLayout layoutEmptyVehicles;

    private RequestQueue requestQueue;

    private static final String VEHICLES_URL =
            "http://10.0.2.2/bumpr/get_vehicles.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vehicles);

        layoutVehicleList = findViewById(R.id.layoutVehicleList);
        layoutEmptyVehicles = findViewById(R.id.layoutEmptyVehicles);

        requestQueue = Volley.newRequestQueue(this);

        findViewById(R.id.btnBack)
                .setOnClickListener(v -> finish());

        findViewById(R.id.btnAddVehicle)
                .setOnClickListener(v -> {

                    Intent intent = new Intent(
                            VehiclesActivity.this,
                            AddVehicleActivity.class
                    );

                    startActivity(intent);
                });

        View mainView = findViewById(R.id.main);

        if (mainView != null) {

            int originalLeft = mainView.getPaddingLeft();
            int originalTop = mainView.getPaddingTop();
            int originalRight = mainView.getPaddingRight();
            int originalBottom = mainView.getPaddingBottom();

            ViewCompat.setOnApplyWindowInsetsListener(
                    mainView,
                    (v, insets) -> {

                        Insets systemBars = insets.getInsets(
                                WindowInsetsCompat.Type.systemBars()
                        );

                        v.setPadding(
                                originalLeft + systemBars.left,
                                originalTop + systemBars.top,
                                originalRight + systemBars.right,
                                originalBottom + systemBars.bottom
                        );

                        return insets;
                    }
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVehicles();
    }

    private void loadVehicles() {

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                VEHICLES_URL,
                null,

                this::displayVehicles,

                error -> Toast.makeText(
                        VehiclesActivity.this,
                        "Failed to load vehicles: " + error,
                        Toast.LENGTH_LONG
                ).show()
        );

        requestQueue.add(request);
    }


    private void displayVehicles(JSONArray vehicles) {

        layoutVehicleList.removeAllViews();

        if (vehicles.length() == 0) {

            layoutEmptyVehicles.setVisibility(View.VISIBLE);
            layoutVehicleList.setVisibility(View.GONE);

            return;
        }

        layoutEmptyVehicles.setVisibility(View.GONE);
        layoutVehicleList.setVisibility(View.VISIBLE);

        for (int i = 0; i < vehicles.length(); i++) {

            JSONObject vehicle = vehicles.optJSONObject(i);

            if (vehicle == null) {
                continue;
            }

            String vehicleID = vehicle.optString("vehicleID", "");

            String make = vehicle.optString(
                    "vehicleMake", ""
            );

            String model = vehicle.optString(
                    "vehicleModel", ""
            );

            String registration = vehicle.optString(
                    "registrationNumber", ""
            );

            String year = vehicle.optString(
                    "vehicleYear", ""
            );

            String colour = vehicle.optString(
                    "vehicleColour", ""
            );

            LinearLayout vehicleItem = new LinearLayout(this);
            vehicleItem.setOrientation(LinearLayout.VERTICAL);
            vehicleItem.setPadding(
                    dp(16), dp(14), dp(16), dp(14)
            );

            vehicleItem.setBackgroundResource(
                    R.drawable.grey_input_background
            );

            LinearLayout.LayoutParams itemParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            itemParams.setMargins(0, dp(10), 0, 0);

            TextView vehicleName = new TextView(this);
            vehicleName.setText(make + " " + model);
            vehicleName.setTextSize(17);
            vehicleName.setTextColor(Color.rgb(30, 41, 59));
            vehicleName.setTypeface(null, Typeface.BOLD);

            TextView registrationText = new TextView(this);
            registrationText.setText(
                    "Registration: " + registration
            );
            registrationText.setTextSize(14);
            registrationText.setTextColor(
                    Color.rgb(71, 85, 105)
            );

            TextView detailsText = new TextView(this);
            detailsText.setText(
                    "Year: " + year + "  |  Colour: " + colour
            );
            detailsText.setTextSize(14);
            detailsText.setTextColor(
                    Color.rgb(100, 116, 139)
            );

            vehicleItem.addView(vehicleName);
            vehicleItem.addView(registrationText);
            vehicleItem.addView(detailsText);

            vehicleItem.setOnClickListener(v -> {

                if (vehicleID.isEmpty() ||
                        vehicleID.equalsIgnoreCase("null")) {

                    Toast.makeText(
                            VehiclesActivity.this,
                            "Invalid vehicle ID",
                            Toast.LENGTH_LONG
                    ).show();

                    return;
                }

                Intent intent = new Intent(
                        VehiclesActivity.this,
                        VehicleDetailsActivity.class
                );

                intent.putExtra("vehicleID", vehicleID);

                startActivity(intent);
            });

            layoutVehicleList.addView(
                    vehicleItem,
                    itemParams
            );
        }
    }

    private int dp(int value) {

        return (int) (
                value * getResources()
                        .getDisplayMetrics()
                        .density + 0.5f
        );
    }
}