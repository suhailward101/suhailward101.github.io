package com.itmdaproject.bumpr;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;

public class VolleyMultipartRequest extends Request<NetworkResponse> {

    private final Response.Listener<NetworkResponse> listener;
    private final Map<String, String> parameters;
    private final Map<String, DataPart> files;
    private final String boundary;

    public VolleyMultipartRequest(
            String url,
            Map<String, String> parameters,
            Map<String, DataPart> files,
            Response.Listener<NetworkResponse> listener,
            Response.ErrorListener errorListener
    ) {
        super(Method.POST, url, errorListener);

        this.parameters = parameters;
        this.files = files;
        this.listener = listener;
        this.boundary = "BumprBoundary" + UUID.randomUUID();
    }

    @Override
    public String getBodyContentType() {
        return "multipart/form-data; boundary=" + boundary;
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        ByteArrayOutputStream output = new ByteArrayOutputStream();

        try {
            for (Map.Entry<String, String> entry : parameters.entrySet()) {
                writeText(output, entry.getKey(), entry.getValue());
            }

            for (Map.Entry<String, DataPart> entry : files.entrySet()) {
                writeFile(output, entry.getKey(), entry.getValue());
            }

            output.write(("--" + boundary + "--\r\n")
                    .getBytes(StandardCharsets.UTF_8));

        } catch (IOException e) {
            throw new AuthFailureError("Unable to prepare upload.", e);
        }

        return output.toByteArray();
    }

    private void writeText(
            ByteArrayOutputStream output,
            String name,
            String value
    ) throws IOException {

        output.write(("--" + boundary + "\r\n")
                .getBytes(StandardCharsets.UTF_8));

        output.write(
                ("Content-Disposition: form-data; name=\""
                        + name + "\"\r\n\r\n")
                        .getBytes(StandardCharsets.UTF_8)
        );

        output.write(value.getBytes(StandardCharsets.UTF_8));
        output.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private void writeFile(
            ByteArrayOutputStream output,
            String name,
            DataPart file
    ) throws IOException {

        output.write(("--" + boundary + "\r\n")
                .getBytes(StandardCharsets.UTF_8));

        output.write(
                ("Content-Disposition: form-data; name=\""
                        + name + "\"; filename=\""
                        + file.fileName + "\"\r\n")
                        .getBytes(StandardCharsets.UTF_8)
        );

        output.write(
                ("Content-Type: " + file.mimeType + "\r\n\r\n")
                        .getBytes(StandardCharsets.UTF_8)
        );

        output.write(file.content);
        output.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    @Override
    protected Response<NetworkResponse> parseNetworkResponse(
            NetworkResponse response
    ) {
        return Response.success(
                response,
                HttpHeaderParser.parseCacheHeaders(response)
        );
    }

    @Override
    protected void deliverResponse(NetworkResponse response) {
        listener.onResponse(response);
    }

    public static class DataPart {

        public final String fileName;
        public final byte[] content;
        public final String mimeType;

        public DataPart(
                String fileName,
                byte[] content,
                String mimeType
        ) {
            this.fileName = fileName;
            this.content = content;
            this.mimeType = mimeType;
        }
    }
}
