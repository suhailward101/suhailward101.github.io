<?php

include 'db_connect.php';

$contactName = $_POST['contactName'];
$phoneNumber = $_POST['phoneNumber'];
$relationship = $_POST['relationship'];

$sql = "INSERT INTO Contacts
(
contactName,
phoneNumber,
relationship
)
VALUES
(
'$contactName',
'$phoneNumber',
'$relationship'
)";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo "failed";
}

?>