<?php

include 'db_connect.php';

header('Content-Type: text/plain; charset=UTF-8');

// Check that the request contains a file.
if (!isset($_FILES['file'])) {
    http_response_code(400);
    exit('failed: No file was uploaded.');
}

// Read the document details.
$documentName = trim($_POST['documentName'] ?? '');
$documentType = trim($_POST['documentType'] ?? '');

// Check required fields.
if ($documentName === '' || $documentType === '') {
    http_response_code(400);
    exit('failed: Document name and type are required.');
}

// Check for upload errors.
if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    exit('failed: File upload error.');
}

// Limit the file size to 10 MB.
$maxFileSize = 10 * 1024 * 1024;

if ($_FILES['file']['size'] > $maxFileSize) {
    http_response_code(400);
    exit('failed: File must be 10 MB or smaller.');
}

// Allow only these file extensions.
$allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];

$originalName = basename($_FILES['file']['name']);
$extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

if (!in_array($extension, $allowedExtensions, true)) {
    http_response_code(400);
    exit('failed: Unsupported file type.');
}

if (!function_exists('finfo_open')) {
    http_response_code(500);
    exit('failed: File validation is unavailable.');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $_FILES['file']['tmp_name']);
finfo_close($finfo);

$allowedMimeTypes = [
    'pdf'  => ['application/pdf'],
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
    'doc'  => ['application/msword', 'application/octet-stream'],
    'docx' => [
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip',
        'application/octet-stream'
    ]
];

if (!in_array($mimeType, $allowedMimeTypes[$extension] ?? [], true)) {
    http_response_code(400);
    exit('failed: File content does not match an allowed type.');
}

$uploadDirectory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';

if (!is_dir($uploadDirectory)) {
    if (!mkdir($uploadDirectory, 0755, true)) {
        http_response_code(500);
        exit('failed: Could not create upload folder.');
    }
}

$storedFileName = bin2hex(random_bytes(16)) . '.' . $extension;

$destination = $uploadDirectory . DIRECTORY_SEPARATOR . $storedFileName;


$documentPath = 'uploads/' . $storedFileName;

if (!move_uploaded_file($_FILES['file']['tmp_name'], $destination)) {
    http_response_code(500);
    exit('failed: Could not save uploaded file.');
}

$sql = "INSERT INTO FileVault
        (documentName, documentType, documentPath)
        VALUES (?, ?, ?)";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    unlink($destination);
    http_response_code(500);
    exit('failed: Could not prepare database query.');
}

mysqli_stmt_bind_param(
    $stmt,
    'sss',
    $documentName,
    $documentType,
    $documentPath
);

if (mysqli_stmt_execute($stmt)) {
    echo 'success';
} else {
    unlink($destination);

    http_response_code(500);
    echo 'failed: Could not save document information.';
}

mysqli_stmt_close($stmt);

?>