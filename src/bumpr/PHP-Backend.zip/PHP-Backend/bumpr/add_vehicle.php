<?php

include 'db_connect.php';

$registrationNumber = $_POST['registrationNumber'];
$vehicleMake = $_POST['vehicleMake'];
$vehicleModel = $_POST['vehicleModel'];
$vehicleYear = $_POST['vehicleYear'];
$vehicleColour = $_POST['vehicleColour'];
$insurancePolicyNumber = $_POST['insurancePolicyNumber'];

$sql = "INSERT INTO Vehicles
(
registrationNumber,
vehicleMake,
vehicleModel,
vehicleYear,
vehicleColour,
insurancePolicyNumber
)
VALUES
(
'$registrationNumber',
'$vehicleMake',
'$vehicleModel',
'$vehicleYear',
'$vehicleColour',
'$insurancePolicyNumber'
)";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo "failed";
}

?>