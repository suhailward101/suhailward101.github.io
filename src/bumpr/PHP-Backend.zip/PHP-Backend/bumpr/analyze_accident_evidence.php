<?php

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

function sendResponse($success, $message, $extra = []) {
    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra));
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    sendResponse(false, "POST request required.");
}

$accidentId = filter_var(
    $_POST["accident_id"] ?? null,
    FILTER_VALIDATE_INT
);

$evidenceId = filter_var(
    $_POST["evidence_id"] ?? null,
    FILTER_VALIDATE_INT
);

$userId = filter_var(
    $_POST["user_id"] ?? null,
    FILTER_VALIDATE_INT
);

if (!$accidentId || !$evidenceId || !$userId ||
    $accidentId <= 0 || $evidenceId <= 0 || $userId <= 0) {

    http_response_code(400);
    sendResponse(false, "Valid accident, evidence and user IDs are required.");
}

/*
 * DEVELOPMENT NOTE:
 * user_id is checked against accident ownership here.
 * It is not secure authentication because a caller could
 * supply another user's ID.
 * Do not expose this endpoint publicly until proper
 * authentication has been implemented.
 */

// Verify the accident belongs to the supplied user
$stmt = $conn->prepare("
    SELECT
        ae.EvidenceID,
        ae.ImagePath
    FROM accident_evidence ae
    INNER JOIN accidents a
        ON ae.AccidentID = a.AccidentID
    WHERE a.AccidentID = ?
      AND a.UserID = ?
      AND ae.EvidenceID = ?
    LIMIT 1
");

if (!$stmt) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare evidence query.");
}

$stmt->bind_param(
    "iii",
    $accidentId,
    $userId,
    $evidenceId
);

if (!$stmt->execute()) {
    $stmt->close();
    http_response_code(500);
    sendResponse(false, "Unable to retrieve evidence.");
}

$result = $stmt->get_result();
$evidence = $result->fetch_assoc();
$stmt->close();

if (!$evidence) {
    http_response_code(404);
    sendResponse(false, "Evidence not found for this accident and user.");
}

// Resolve the stored evidence path safely
$uploadDirectory = realpath(
    __DIR__ . "/accident_uploads"
);

if ($uploadDirectory === false) {
    http_response_code(500);
    sendResponse(false, "Evidence storage directory not found.");
}

$storedPath = str_replace(
    "\\",
    "/",
    $evidence["ImagePath"]
);

$prefix = "accident_uploads/";

if (strpos($storedPath, $prefix) !== 0) {
    http_response_code(400);
    sendResponse(false, "Invalid evidence path.");
}

$filename = substr(
    $storedPath,
    strlen($prefix)
);

// Uploaded evidence uses random filenames, not subfolders
if ($filename === "" ||
    basename($filename) !== $filename) {

    http_response_code(400);
    sendResponse(false, "Invalid evidence filename.");
}

$imagePath = realpath(
    $uploadDirectory . DIRECTORY_SEPARATOR . $filename
);

if ($imagePath === false ||
    dirname($imagePath) !== $uploadDirectory ||
    !is_file($imagePath)) {

    http_response_code(404);
    sendResponse(false, "Evidence photograph not found.");
}

$imageSize = filesize($imagePath);

if ($imageSize === false ||
    $imageSize <= 0 ||
    $imageSize > 10 * 1024 * 1024) {

    http_response_code(400);
    sendResponse(false, "Invalid evidence image size.");
}

$mimeType = (new finfo(FILEINFO_MIME_TYPE))
    ->file($imagePath);

if (!in_array($mimeType, [
    "image/jpeg",
    "image/png",
    "image/webp"
], true)) {

    http_response_code(400);
    sendResponse(false, "Unsupported evidence image format.");
}

$imageData = file_get_contents($imagePath);

if ($imageData === false) {
    http_response_code(500);
    sendResponse(false, "Unable to read evidence photograph.");
}

$imageBase64 = base64_encode($imageData);

// Define the AI instructions
$prompt = <<<PROMPT
You are Bumpr's AI accident evidence assistant.

Analyse ONLY what is visibly present in this photograph.

Return an objective evidence description using
the following five numbered sections:

1. Vehicle Damage
Describe damage that is clearly visible.

2. Affected Vehicle Areas
Identify visibly affected vehicle components.

3. Road Conditions
Describe visible road surface, markings
and environmental conditions.

4. Additional Evidence
Describe visible debris, objects or other
potentially relevant scene details.

5. Limitations
Explain what cannot be reliably determined
from the photograph alone.

Rules:
- Do not assign fault or responsibility.
- Do not speculate about accident causes.
- Do not estimate vehicle speed.
- Do not diagnose injuries.
- Do not invent evidence.
- Clearly distinguish visible observations
  from uncertain interpretations.
- If a section cannot be assessed, say so.
PROMPT;

$payload = [
    "model" => "gemma4:e2b",
    "messages" => [
        [
            "role" => "user",
            "content" => $prompt,
            "images" => [$imageBase64]
        ]
    ],
    "stream" => false
];

// Send photograph to locally running Ollama
$ch = curl_init(
    "http://127.0.0.1:11434/api/chat"
);

curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 300
]);

$response = curl_exec($ch);
$curlError = curl_error($ch);
$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

if ($response === false || $httpStatus !== 200) {

    error_log(
        "Bumpr Ollama error: HTTP " .
        $httpStatus . " " . $curlError
    );

    http_response_code(502);
    sendResponse(false, "Gemma AI analysis failed.");
}

$aiResult = json_decode($response, true);

$analysis = $aiResult["message"]["content"] ?? "";

if (!is_string($analysis) ||
    trim($analysis) === "") {

    http_response_code(502);
    sendResponse(false, "Gemma returned an empty analysis.");
}

// Save the generated analysis
$insert = $conn->prepare("
    INSERT INTO accident_ai_analysis
    (
        AccidentID,
        EvidenceID,
        AIModel,
        AIAnalysis,
        AnalysisStatus
    )
    VALUES (?, ?, ?, ?, 'Generated')
");

if (!$insert) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare AI analysis record.");
}

$model = "gemma4:e2b";

$insert->bind_param(
    "iiss",
    $accidentId,
    $evidenceId,
    $model,
    $analysis
);

if (!$insert->execute()) {
    $insert->close();
    http_response_code(500);
    sendResponse(false, "Unable to save AI analysis.");
}

$analysisId = $conn->insert_id;

$insert->close();

sendResponse(true, "AI analysis completed successfully.", [
    "analysis_id" => (int)$analysisId,
    "accident_id" => (int)$accidentId,
    "evidence_id" => (int)$evidenceId,
    "model" => $model,
    "analysis" => $analysis,
    "status" => "Generated"
]);

?>