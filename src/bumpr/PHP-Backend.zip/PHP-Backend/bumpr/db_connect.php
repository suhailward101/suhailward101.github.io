<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "bumpr"
);

if(!$conn){
    die("Connection Failed");
}

?>