<?php

include 'db_connect.php';

$contactID = $_POST['contactID'];

$sql = "DELETE FROM Contacts
WHERE contactID='$contactID'";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo "failed";
}

?>