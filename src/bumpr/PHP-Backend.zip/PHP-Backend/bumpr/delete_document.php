<?php

include 'db_connect.php';

$documentID = filter_input(
    INPUT_POST,
    'documentID',
    FILTER_VALIDATE_INT
);

if (!$documentID || $documentID < 1) {
    http_response_code(400);
    exit("failed: invalid document ID");
}

$stmt = mysqli_prepare(
    $conn,
    "SELECT documentPath FROM FileVault WHERE documentID = ?"
);

mysqli_stmt_bind_param($stmt, "i", $documentID);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $documentPath);

if (!mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    http_response_code(404);
    exit("failed: document not found");
}

mysqli_stmt_close($stmt);

$uploadsDirectory = realpath(__DIR__ . '/uploads');
$filePath = null;

if (!empty($documentPath)) {

    if ($uploadsDirectory === false) {
        http_response_code(500);
        exit("failed: uploads directory missing");
    }

    $resolvedPath = realpath(__DIR__ . '/' . $documentPath);

    if (
        $resolvedPath !== false &&
        is_file($resolvedPath) &&
        str_starts_with(
            $resolvedPath,
            $uploadsDirectory . DIRECTORY_SEPARATOR
        )
    ) {
        $filePath = $resolvedPath;
    }
}

$deleteStmt = mysqli_prepare(
    $conn,
    "DELETE FROM FileVault WHERE documentID = ?"
);

mysqli_stmt_bind_param($deleteStmt, "i", $documentID);

if (!mysqli_stmt_execute($deleteStmt)) {
    mysqli_stmt_close($deleteStmt);
    http_response_code(500);
    exit("failed: database deletion failed");
}

$deletedRows = mysqli_stmt_affected_rows($deleteStmt);
mysqli_stmt_close($deleteStmt);

if ($deletedRows < 1) {
    http_response_code(404);
    exit("failed: document not found");
}

if ($filePath !== null && file_exists($filePath)) {

    if (!unlink($filePath)) {
        http_response_code(500);
        exit("failed: database record deleted but file removal failed");
    }
}

echo "success";

?>
