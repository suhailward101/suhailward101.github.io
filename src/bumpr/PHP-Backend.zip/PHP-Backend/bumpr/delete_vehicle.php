<?php

include 'db_connect.php';

$vehicleID = filter_input(
    INPUT_POST,
    'vehicleID',
    FILTER_VALIDATE_INT
);

if (!$vehicleID || $vehicleID < 1) {
    http_response_code(400);
    exit("failed: invalid vehicle ID");
}

$sql = "DELETE FROM Vehicles WHERE vehicleID = ?";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    http_response_code(500);
    exit("failed: database error");
}

mysqli_stmt_bind_param($stmt, "i", $vehicleID);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    http_response_code(500);
    exit("failed: deletion error");
}

$deletedRows = mysqli_stmt_affected_rows($stmt);

mysqli_stmt_close($stmt);

if ($deletedRows === 0) {
    http_response_code(404);
    exit("failed: vehicle not found");
}

echo "success";

?>
