<?php

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

function sendResponse($success, $message, $analyses = []) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "analyses" => $analyses
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    sendResponse(false, "POST request required.");
}

$accidentId = filter_var(
    $_POST["accident_id"] ?? null,
    FILTER_VALIDATE_INT
);

$userId = filter_var(
    $_POST["user_id"] ?? null,
    FILTER_VALIDATE_INT
);

if (!$accidentId || !$userId ||
    $accidentId <= 0 || $userId <= 0) {

    http_response_code(400);
    sendResponse(false, "Valid accident and user IDs required.");
}

// Check accident ownership
$check = $conn->prepare("
    SELECT AccidentID
    FROM accidents
    WHERE AccidentID = ?
      AND UserID = ?
    LIMIT 1
");

if (!$check) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare accident query.");
}

$check->bind_param("ii", $accidentId, $userId);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    $check->close();
    http_response_code(404);
    sendResponse(false, "Accident not found.");
}

$check->close();

// Retrieve saved analyses
$stmt = $conn->prepare("
    SELECT
        AnalysisID,
        AccidentID,
        EvidenceID,
        AIModel,
        AIAnalysis,
        ReviewedAnalysis,
        AnalysisStatus,
        CreatedAt
    FROM accident_ai_analysis
    WHERE AccidentID = ?
    ORDER BY CreatedAt DESC, AnalysisID DESC
");

if (!$stmt) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare analysis query.");
}

$stmt->bind_param("i", $accidentId);
$stmt->execute();

$result = $stmt->get_result();

$analyses = [];

while ($row = $result->fetch_assoc()) {
    $analyses[] = [
        "analysis_id" => (int)$row["AnalysisID"],
        "accident_id" => (int)$row["AccidentID"],
        "evidence_id" => (int)$row["EvidenceID"],
        "model" => $row["AIModel"],
        "analysis" => $row["AIAnalysis"],
        "reviewed_analysis" => $row["ReviewedAnalysis"],
        "status" => $row["AnalysisStatus"],
        "created_at" => $row["CreatedAt"]
    ];
}

$stmt->close();

sendResponse(
    true,
    "AI analyses retrieved successfully.",
    $analyses
);

?>