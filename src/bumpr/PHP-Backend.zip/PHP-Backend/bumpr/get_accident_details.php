<?php

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

function sendResponse($success, $message, $accident = null) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "accident" => $accident
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendResponse(false, "POST request required.");
}

$accidentId = filter_input(
    INPUT_POST,
    "accident_id",
    FILTER_VALIDATE_INT
);

$userId = filter_input(
    INPUT_POST,
    "user_id",
    FILTER_VALIDATE_INT
);

if (!$accidentId || $accidentId <= 0) {
    sendResponse(false, "A valid accident ID is required.");
}

if (!$userId || $userId <= 0) {
    sendResponse(false, "A valid user ID is required.");
}

$sql = "
    SELECT
        AccidentID,
        UserID,
        AccidentType,
        AccidentDescription,
        InjuriesReported,
        HasWitnesses,
        Latitude,
        Longitude,
        AccidentDateTime
    FROM accidents
    WHERE AccidentID = ?
      AND UserID = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    sendResponse(false, "Unable to prepare accident query.");
}

mysqli_stmt_bind_param(
    $stmt,
    "ii",
    $accidentId,
    $userId
);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    sendResponse(false, "Unable to retrieve accident.");
}

$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$row) {
    sendResponse(false, "Accident not found.");
}

$evidenceSql = "
    SELECT
        EvidenceID,
        EvidenceCategory,
        ImagePath,
        UploadedAt
    FROM accident_evidence
    WHERE AccidentID = ?
    ORDER BY EvidenceID ASC
";

$evidenceStmt = mysqli_prepare($conn, $evidenceSql);

if (!$evidenceStmt) {
    sendResponse(false, "Unable to prepare evidence query.");
}

mysqli_stmt_bind_param(
    $evidenceStmt,
    "i",
    $accidentId
);

if (!mysqli_stmt_execute($evidenceStmt)) {
    mysqli_stmt_close($evidenceStmt);
    sendResponse(false, "Unable to retrieve evidence.");
}

$evidenceResult = mysqli_stmt_get_result($evidenceStmt);

$evidence = [];

while ($evidenceRow = mysqli_fetch_assoc($evidenceResult)) {

    $evidence[] = [
        "evidence_id" => (int)$evidenceRow["EvidenceID"],
        "category" => $evidenceRow["EvidenceCategory"],
        "image_path" => $evidenceRow["ImagePath"],
        "uploaded_at" => $evidenceRow["UploadedAt"]
    ];
}

mysqli_stmt_close($evidenceStmt);

$accident = [
    "accident_id" => (int)$row["AccidentID"],
    "user_id" => (int)$row["UserID"],
    "accident_type" => $row["AccidentType"],
    "description" => $row["AccidentDescription"],
    "injuries_reported" => (bool)$row["InjuriesReported"],
    "has_witnesses" => (bool)$row["HasWitnesses"],
    "latitude" => $row["Latitude"] === null
        ? null
        : (float)$row["Latitude"],
    "longitude" => $row["Longitude"] === null
        ? null
        : (float)$row["Longitude"],
    "accident_datetime" => $row["AccidentDateTime"],
    "evidence" => $evidence
];

sendResponse(
    true,
    "Accident details retrieved successfully.",
    $accident
);

?>
