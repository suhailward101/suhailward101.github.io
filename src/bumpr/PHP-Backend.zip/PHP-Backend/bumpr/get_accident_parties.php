<?php
header("Content-Type: application/json; charset=utf-8");

require_once "db_connect.php";

$accidentId = (int)($_POST["accident_id"] ?? 0);
$userId = (int)($_POST["user_id"] ?? 0);

if ($accidentId <= 0 || $userId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid accident or user."
    ]);
    exit;
}

$check = $conn->prepare(
    "SELECT AccidentID FROM accidents
     WHERE AccidentID = ? AND UserID = ?"
);

$check->bind_param("ii", $accidentId, $userId);
$check->execute();

$found = $check->get_result()->fetch_assoc();
$check->close();

if (!$found) {
    echo json_encode([
        "success" => false,
        "message" => "Accident not found."
    ]);
    exit;
}

$tables = [
    "vehicles" => "othervehicle",
    "drivers" => "otherdriver",
    "witnesses" => "witnessinformation",
    "pedestrians" => "pedestrianinformation"
];

$result = [
    "success" => true,
    "accident_id" => $accidentId
];

foreach ($tables as $key => $table) {

    $stmt = $conn->prepare(
        "SELECT * FROM `$table` WHERE accidentID = ?"
    );

    $stmt->bind_param("i", $accidentId);
    $stmt->execute();

    $rows = $stmt->get_result();

    $result[$key] = $rows->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}

echo json_encode($result);