<?php

include 'db_connect.php';

$sql = "SELECT * FROM Contacts";

$result = mysqli_query($conn,$sql);

$data = array();

while($row = mysqli_fetch_assoc($result)){
    $data[] = $row;
}

echo json_encode($data);

?>