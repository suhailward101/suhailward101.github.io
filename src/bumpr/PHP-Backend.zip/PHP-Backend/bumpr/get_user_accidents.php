<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "db_connect.php";

function sendResponse($success, $message, $accidents = []) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "accidents" => $accidents
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendResponse(false, "POST request required.");
}

$userId = filter_input(
    INPUT_POST,
    "user_id",
    FILTER_VALIDATE_INT
);

if (!$userId || $userId <= 0) {
    sendResponse(false, "A valid user ID is required.");
}

$sql = "
    SELECT
        a.AccidentID,
        a.AccidentType,
        a.AccidentDescription,
        a.InjuriesReported,
        a.HasWitnesses,
        a.Latitude,
        a.Longitude,
        a.AccidentDateTime,
        COUNT(e.EvidenceID) AS EvidenceCount
    FROM accidents a
    LEFT JOIN accident_evidence e
        ON a.AccidentID = e.AccidentID
    WHERE a.UserID = ?
    GROUP BY
        a.AccidentID,
        a.AccidentType,
        a.AccidentDescription,
        a.InjuriesReported,
        a.HasWitnesses,
        a.Latitude,
        a.Longitude,
        a.AccidentDateTime
    ORDER BY a.AccidentDateTime DESC, a.AccidentID DESC
";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    sendResponse(false, "Unable to prepare database query.");
}

mysqli_stmt_bind_param($stmt, "i", $userId);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    sendResponse(false, "Unable to retrieve accidents.");
}

$result = mysqli_stmt_get_result($stmt);

$accidents = [];

while ($row = mysqli_fetch_assoc($result)) {
    $accidents[] = [
        "accident_id" => (int) $row["AccidentID"],
        "accident_type" => $row["AccidentType"],
        "description" => $row["AccidentDescription"],
        "injuries_reported" => (bool) $row["InjuriesReported"],
        "has_witnesses" => (bool) $row["HasWitnesses"],
        "latitude" => $row["Latitude"] === null
            ? null
            : (float) $row["Latitude"],
        "longitude" => $row["Longitude"] === null
            ? null
            : (float) $row["Longitude"],
        "accident_datetime" => $row["AccidentDateTime"],
        "evidence_count" => (int) $row["EvidenceCount"]
    ];
}

mysqli_stmt_close($stmt);

sendResponse(
    true,
    "Accident records retrieved successfully.",
    $accidents
);

?>
