<?php
header("Content-Type: application/json");
require_once "db_connect.php";

$userId = (int)($_POST["user_id"] ?? 0);

if ($userId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid user ID"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "SELECT vehicleID, registrationNumber,
            vehicleMake, vehicleModel
     FROM vehicles
     WHERE userID = ?
     ORDER BY vehicleID DESC"
);

$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();
$vehicles = [];

while ($row = $result->fetch_assoc()) {
    $vehicles[] = $row;
}

echo json_encode([
    "success" => true,
    "vehicles" => $vehicles
]);

$stmt->close();
$conn->close();
?>
