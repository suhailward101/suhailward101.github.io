<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "db_connect.php";

function sendResponse($success, $message, $accidentId = null) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "accident_id" => $accidentId
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    sendResponse(false, "POST request required.");
}

$userId = filter_var(
    $_POST["user_id"] ?? null,
    FILTER_VALIDATE_INT
);

$accidentType = trim($_POST["accident_type"] ?? "");
$description = trim($_POST["accident_description"] ?? "");

$injuries = $_POST["injuries_reported"] ?? null;
$witnesses = $_POST["has_witnesses"] ?? null;

$latitude = $_POST["latitude"] ?? "";
$longitude = $_POST["longitude"] ?? "";

$allowedTypes = [
    "Single Vehicle",
    "Two or More Vehicles",
    "Pedestrian"
];

if (!$userId || $userId <= 0) {
    http_response_code(400);
    sendResponse(false, "A valid user ID is required.");
}

if (!in_array($accidentType, $allowedTypes, true)) {
    http_response_code(400);
    sendResponse(false, "Invalid accident type.");
}

if ($description === "") {
    http_response_code(400);
    sendResponse(false, "Accident description is required.");
}

if (!in_array((string)$injuries, ["0", "1"], true) ||
    !in_array((string)$witnesses, ["0", "1"], true)) {

    http_response_code(400);
    sendResponse(false, "Invalid injury or witness response.");
}

if ($latitude === "" && $longitude === "") {
    $latitude = null;
    $longitude = null;
} elseif (
    !is_numeric($latitude) ||
    !is_numeric($longitude) ||
    (float)$latitude < -90 ||
    (float)$latitude > 90 ||
    (float)$longitude < -180 ||
    (float)$longitude > 180
) {
    http_response_code(400);
    sendResponse(false, "Invalid GPS coordinates.");
}

$checkUser = $conn->prepare(
    "SELECT UserID FROM users WHERE UserID = ?"
);

if (!$checkUser) {
    http_response_code(500);
    sendResponse(false, "Unable to validate user.");
}

$checkUser->bind_param("i", $userId);
$checkUser->execute();
$checkUser->store_result();

if ($checkUser->num_rows === 0) {
    $checkUser->close();
    http_response_code(400);
    sendResponse(false, "User does not exist.");
}

$checkUser->close();

$stmt = $conn->prepare(
    "INSERT INTO accidents
    (
        UserID,
        AccidentType,
        AccidentDescription,
        InjuriesReported,
        HasWitnesses,
        Latitude,
        Longitude
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)"
);

if (!$stmt) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare accident record.");
}

$injuries = (int)$injuries;
$witnesses = (int)$witnesses;

$stmt->bind_param(
    "issiidd",
    $userId,
    $accidentType,
    $description,
    $injuries,
    $witnesses,
    $latitude,
    $longitude
);

if ($stmt->execute()) {

    $accidentId = $conn->insert_id;

    sendResponse(
        true,
        "Accident saved successfully.",
        $accidentId
    );

} else {

    http_response_code(500);

    sendResponse(
        false,
        "Unable to save accident."
    );
}

$stmt->close();
$conn->close();

?>
