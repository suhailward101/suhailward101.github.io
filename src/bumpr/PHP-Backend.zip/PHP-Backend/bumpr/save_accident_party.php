<?php
header("Content-Type: application/json; charset=utf-8");

require_once "db_connect.php";

function respond($success, $message, $extra = []) {
    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra));
    exit;
}

function getOptional($data, $key, $maxLength = 255) {
    $value = trim((string)($data[$key] ?? ""));
    return $value === "" ? null : mb_substr($value, 0, $maxLength);
}

function getRequired($data, $key, $maxLength = 255) {
    $value = getOptional($data, $key, $maxLength);

    if ($value === null) {
        throw new Exception("Missing field: " . $key);
    }

    return $value;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    respond(false, "POST request required.");
}

try {

    $data = json_decode(file_get_contents("php://input"), true);

    if (!is_array($data)) {
        $data = $_POST;
    }

    $accidentId = (int)($data["accident_id"] ?? 0);
    $userId = (int)($data["user_id"] ?? 0);
    $type = (string)($data["type"] ?? "");

    if ($accidentId <= 0 || $userId <= 0) {
        respond(false, "Invalid accident or user.");
    }

    $allowed = ["vehicle", "driver", "witness", "pedestrian"];

    if (!in_array($type, $allowed, true)) {
        respond(false, "Invalid record type.");
    }

    // Check the accident belongs to the user.
    $check = $conn->prepare(
        "SELECT AccidentID FROM accidents
         WHERE AccidentID = ? AND UserID = ?"
    );

    $check->bind_param("ii", $accidentId, $userId);
    $check->execute();

    $found = $check->get_result()->fetch_assoc();
    $check->close();

    if (!$found) {
        respond(false, "Accident not found for this user.");
    }

    $conn->begin_transaction();

    if ($type === "vehicle") {

        $registration = getRequired($data, "registration", 20);
        $make = getRequired($data, "make", 50);
        $model = getRequired($data, "model", 50);
        $colour = getRequired($data, "colour", 30);

        $insurance = getOptional($data, "insuranceName", 100);
        $policy = getOptional($data, "policyNumber", 50);
        $owner = getOptional($data, "ownerName", 100);
        $ownerPhone = getOptional($data, "ownerPhone", 20);

        $stmt = $conn->prepare(
            "INSERT INTO othervehicle
             (accidentID, registration, make, model, colour,
              insuranceName, policyNumber, ownerName, ownerPhone)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "issssssss",
            $accidentId, $registration, $make, $model,
            $colour, $insurance, $policy, $owner, $ownerPhone
        );

    } elseif ($type === "driver") {

        $vehicleId = (int)($data["otherVehicleID"] ?? 0);

        $verify = $conn->prepare(
            "SELECT otherVehicleID FROM othervehicle
             WHERE otherVehicleID = ? AND accidentID = ?"
        );

        $verify->bind_param("ii", $vehicleId, $accidentId);
        $verify->execute();

        $vehicleExists = $verify->get_result()->fetch_assoc();
        $verify->close();

        if (!$vehicleExists) {
            throw new Exception(
                "Save an associated vehicle first."
            );
        }

        $name = getRequired($data, "fullName", 100);
        $phone = getRequired($data, "phone", 20);
        $idNumber = getOptional($data, "idNumber", 20);
        $email = getOptional($data, "email", 100);
        $licence = getOptional($data, "licenceNumber", 20);
        $address = getOptional($data, "address", 255);

        $stmt = $conn->prepare(
            "INSERT INTO otherdriver
             (accidentID, otherVehicleID, fullName, idNumber,
              phone, email, licenceNumber, address)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "iissssss",
            $accidentId, $vehicleId, $name, $idNumber,
            $phone, $email, $licence, $address
        );

    } elseif ($type === "witness") {

        $name = getRequired($data, "fullName", 100);
        $phone = getRequired($data, "phone", 20);
        $address = getRequired($data, "address", 255);
        $statement = getRequired($data, "statement", 10000);

        $stmt = $conn->prepare(
            "INSERT INTO witnessinformation
             (accidentID, fullName, phone, address, statement)
             VALUES (?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "issss",
            $accidentId, $name, $phone, $address, $statement
        );

    } else {

        $name = getOptional($data, "fullName", 100);
        $phone = getOptional($data, "phone", 20);
        $address = getOptional($data, "address", 255);

        $injured = !empty($data["wasInjured"]) ? 1 : 0;

        $injuryDescription = getOptional(
            $data, "injuryDescription", 10000
        );

        $emergency = !empty(
            $data["emergencyServicesCalled"]
        ) ? 1 : 0;

        $notes = getOptional(
            $data, "additionalNotes", 10000
        );

        $stmt = $conn->prepare(
            "INSERT INTO pedestrianinformation
             (accidentID, fullName, phone, address,
              wasInjured, injuryDescription,
              emergencyServicesCalled, additionalNotes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "isssisis",
            $accidentId, $name, $phone, $address,
            $injured, $injuryDescription, $emergency, $notes
        );
    }

    if (!$stmt->execute()) {
        throw new Exception("Unable to save record.");
    }

    $newId = $conn->insert_id;

    $stmt->close();
    $conn->commit();

    respond(true, "Information saved successfully.", [
        "record_id" => $newId
    ]);

} catch (Throwable $e) {

    if (isset($conn)) {
        try {
            $conn->rollback();
        } catch (Throwable $ignored) {}
    }

    error_log("save_accident_party: " . $e->getMessage());

    http_response_code(400);

    respond(false, "Unable to save information.");
}