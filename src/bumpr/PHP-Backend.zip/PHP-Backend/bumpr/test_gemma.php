<?php

header("Content-Type: application/json; charset=utf-8");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "POST request required."
    ]);
    exit;
}

if (
    !isset($_FILES["image"]) ||
    $_FILES["image"]["error"] !== UPLOAD_ERR_OK
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "No valid image uploaded."
    ]);
    exit;
}

if ($_FILES["image"]["size"] > 5 * 1024 * 1024) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Image must be under 5 MB."
    ]);
    exit;
}

$imagePath = $_FILES["image"]["tmp_name"];

$imageInfo = getimagesize($imagePath);

if (
    $imageInfo === false ||
    !in_array(
        $imageInfo["mime"],
        ["image/jpeg", "image/png"],
        true
    )
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Only JPEG and PNG images are supported."
    ]);
    exit;
}

$imageBase64 = base64_encode(
    file_get_contents($imagePath)
);

$prompt = <<<PROMPT
You are Bumpr's AI accident evidence assistant.

Analyse ONLY what is visible in this photograph.

Respond using these sections:

1. Vehicle Damage
Describe visible damage without exaggeration.

2. Affected Vehicle Areas
Identify visibly damaged vehicle components.

3. Road Conditions
Describe visible road or weather conditions.
If unclear, state that they cannot be determined.

4. Additional Evidence
Describe visible debris, road markings or other evidence.

5. Limitations
Explain what cannot reliably be determined.

Do not:
- Assign fault or responsibility.
- Estimate vehicle speed.
- Diagnose injuries.
- Assume the cause of the accident.
- Invent details not visible in the photograph.

Clearly distinguish observations from uncertainty.
PROMPT;

$payload = [
    "model" => "gemma4:e2b",
    "messages" => [
        [
            "role" => "user",
            "content" => $prompt,
            "images" => [$imageBase64]
        ]
    ],
    "stream" => false
];

$ch = curl_init(
    "http://127.0.0.1:11434/api/chat"
);

curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 300
]);

$response = curl_exec($ch);
$error = curl_error($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

if ($response === false || $status !== 200) {

    error_log(
        "Bumpr AI error: HTTP " . $status . " " . $error
    );

    http_response_code(502);

    echo json_encode([
        "success" => false,
        "message" => "AI analysis failed."
    ]);
    exit;
}

$data = json_decode($response, true);

$analysis = $data["message"]["content"] ?? "";

if (trim($analysis) === "") {

    http_response_code(502);

    echo json_encode([
        "success" => false,
        "message" => "AI returned an empty response."
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "model" => "gemma4:e2b",
    "analysis" => $analysis
]);