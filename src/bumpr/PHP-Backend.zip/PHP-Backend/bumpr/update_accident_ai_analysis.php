<?php

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db_connect.php";

function sendResponse($success, $message, $extra = []) {
    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra));
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    sendResponse(false, "POST request required.");
}

// Retrieve request parameters
$analysisId = filter_var(
    $_POST["analysis_id"] ?? null,
    FILTER_VALIDATE_INT
);

$accidentId = filter_var(
    $_POST["accident_id"] ?? null,
    FILTER_VALIDATE_INT
);

$userId = filter_var(
    $_POST["user_id"] ?? null,
    FILTER_VALIDATE_INT
);

$reviewedAnalysis = trim(
    $_POST["reviewed_analysis"] ?? ""
);

// Validate inputs
if (!$analysisId || !$accidentId || !$userId ||
    $analysisId <= 0 ||
    $accidentId <= 0 ||
    $userId <= 0) {

    http_response_code(400);

    sendResponse(
        false,
        "Valid analysis, accident and user IDs are required."
    );
}

if ($reviewedAnalysis === "") {
    http_response_code(400);

    sendResponse(
        false,
        "Reviewed analysis cannot be empty."
    );
}

if (strlen($reviewedAnalysis) > 60000) {
    http_response_code(400);

    sendResponse(
        false,
        "Reviewed analysis is too long."
    );
}

/*
 * DEVELOPMENT SECURITY NOTE:
 * This endpoint checks ownership using user_id.
 * A caller can impersonate another user by supplying
 * their ID, so this is suitable only for controlled
 * local development testing.
 *
 * Before production, replace this with authenticated
 * server-side identity verification.
 */

// Verify analysis and accident ownership
$check = $conn->prepare("
    SELECT ai.AnalysisID
    FROM accident_ai_analysis ai
    INNER JOIN accidents a
        ON ai.AccidentID = a.AccidentID
    WHERE ai.AnalysisID = ?
      AND ai.AccidentID = ?
      AND a.UserID = ?
    LIMIT 1
");

if (!$check) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare analysis query.");
}

$check->bind_param(
    "iii",
    $analysisId,
    $accidentId,
    $userId
);

if (!$check->execute()) {
    $check->close();

    http_response_code(500);
    sendResponse(false, "Unable to verify analysis.");
}

$check->store_result();

if ($check->num_rows === 0) {
    $check->close();

    http_response_code(404);
    sendResponse(false, "Analysis not found for this accident.");
}

$check->close();

// Save reviewed version while retaining original AI output
$stmt = $conn->prepare("
    UPDATE accident_ai_analysis
    SET
        ReviewedAnalysis = ?,
        AnalysisStatus = 'Reviewed'
    WHERE AnalysisID = ?
      AND AccidentID = ?
");

if (!$stmt) {
    http_response_code(500);
    sendResponse(false, "Unable to prepare update.");
}

$stmt->bind_param(
    "sii",
    $reviewedAnalysis,
    $analysisId,
    $accidentId
);

if (!$stmt->execute()) {
    $stmt->close();

    http_response_code(500);
    sendResponse(false, "Unable to save reviewed analysis.");
}

$stmt->close();

sendResponse(
    true,
    "AI analysis reviewed successfully.",
    [
        "analysis_id" => (int)$analysisId,
        "accident_id" => (int)$accidentId,
        "reviewed_analysis" => $reviewedAnalysis,
        "status" => "Reviewed"
    ]
);

?>