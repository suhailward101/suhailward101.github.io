<?php
header("Content-Type: application/json");
require_once "db_connect.php";

$accidentId = (int)($_POST["accident_id"] ?? 0);
$vehicleId = (int)($_POST["vehicle_id"] ?? 0);
$userId = (int)($_POST["user_id"] ?? 0);

if ($accidentId <= 0 || $vehicleId <= 0 || $userId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request"
    ]);
    exit;
}

$check = $conn->prepare(
    "SELECT
        (SELECT COUNT(*) FROM accidents
         WHERE AccidentID = ? AND UserID = ?) AS accident_count,
        (SELECT COUNT(*) FROM vehicles
         WHERE vehicleID = ? AND userID = ?) AS vehicle_count"
);

$check->bind_param(
    "iiii",
    $accidentId,
    $userId,
    $vehicleId,
    $userId
);

$check->execute();
$ownership = $check->get_result()->fetch_assoc();
$check->close();

if ((int)$ownership["accident_count"] !== 1 ||
    (int)$ownership["vehicle_count"] !== 1) {

    echo json_encode([
        "success" => false,
        "message" => "Accident or vehicle not found"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "UPDATE accidents
     SET VehicleID = ?
     WHERE AccidentID = ? AND UserID = ?"
);

$stmt->bind_param(
    "iii",
    $vehicleId,
    $accidentId,
    $userId
);

$success = $stmt->execute();

echo json_encode([
    "success" => $success,
    "message" => $success
        ? "Accident vehicle saved"
        : "Unable to save accident vehicle"
]);

$stmt->close();
$conn->close();
?>