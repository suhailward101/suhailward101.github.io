<?php

include 'db_connect.php';

$contactID = $_POST['contactID'];

$contactName = $_POST['contactName'];
$phoneNumber = $_POST['phoneNumber'];
$relationship = $_POST['relationship'];

$sql = "UPDATE Contacts SET

contactName='$contactName',
phoneNumber='$phoneNumber',
relationship='$relationship'

WHERE contactID='$contactID'";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo "failed";
}

?>