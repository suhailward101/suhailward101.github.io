<?php

include 'db_connect.php';

$documentID = filter_input(
    INPUT_POST,
    'documentID',
    FILTER_VALIDATE_INT
);

$documentName = trim($_POST['documentName'] ?? '');
$documentType = trim($_POST['documentType'] ?? '');

if (
    !$documentID ||
    $documentID < 1 ||
    $documentName === '' ||
    $documentType === ''
) {
    http_response_code(400);
    exit("failed: invalid document information");
}

$sql = "UPDATE FileVault
        SET documentName = ?, documentType = ?
        WHERE documentID = ?";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    http_response_code(500);
    exit("failed");
}

mysqli_stmt_bind_param(
    $stmt,
    "ssi",
    $documentName,
    $documentType,
    $documentID
);

if (mysqli_stmt_execute($stmt)) {
    echo "success";
} else {
    http_response_code(500);
    echo "failed";
}

mysqli_stmt_close($stmt);

?>
