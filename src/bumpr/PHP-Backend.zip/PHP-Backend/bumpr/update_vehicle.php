<?php

include 'db_connect.php';

$vehicleID = filter_input(
    INPUT_POST,
    'vehicleID',
    FILTER_VALIDATE_INT
);

$registrationNumber = trim($_POST['registrationNumber'] ?? '');
$vehicleMake = trim($_POST['vehicleMake'] ?? '');
$vehicleModel = trim($_POST['vehicleModel'] ?? '');
$vehicleYear = filter_input(
    INPUT_POST,
    'vehicleYear',
    FILTER_VALIDATE_INT
);
$vehicleColour = trim($_POST['vehicleColour'] ?? '');
$insurancePolicyNumber = trim($_POST['insurancePolicyNumber'] ?? '');

if (
    !$vehicleID ||
    $vehicleID < 1 ||
    $registrationNumber === '' ||
    $vehicleMake === '' ||
    $vehicleModel === '' ||
    !$vehicleYear ||
    $vehicleYear < 1886 ||
    $vehicleYear > (int)date('Y') + 1 ||
    $vehicleColour === ''
) {
    http_response_code(400);
    exit("failed: invalid vehicle information");
}

$sql = "UPDATE Vehicles SET
    registrationNumber = ?,
    vehicleMake = ?,
    vehicleModel = ?,
    vehicleYear = ?,
    vehicleColour = ?,
    insurancePolicyNumber = ?
    WHERE vehicleID = ?";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    http_response_code(500);
    exit("failed: database error");
}

mysqli_stmt_bind_param(
    $stmt,
    "sssissi",
    $registrationNumber,
    $vehicleMake,
    $vehicleModel,
    $vehicleYear,
    $vehicleColour,
    $insurancePolicyNumber,
    $vehicleID
);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    http_response_code(500);
    exit("failed: update error");
}

mysqli_stmt_close($stmt);

echo "success";

?>
