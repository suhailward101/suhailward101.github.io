<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "db_connect.php";

function sendResponse($success, $message, $evidenceId = null) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "evidence_id" => $evidenceId
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    sendResponse(false, "POST request required.");
}

$accidentId = filter_var(
    $_POST["accident_id"] ?? null,
    FILTER_VALIDATE_INT
);

$category = trim($_POST["evidence_category"] ?? "");

if (!$accidentId || $accidentId <= 0) {
    http_response_code(400);
    sendResponse(false, "A valid accident ID is required.");
}

if ($category === "" || strlen($category) > 150) {
    http_response_code(400);
    sendResponse(false, "A valid evidence category is required.");
}

if (!isset($_FILES["evidence_image"])) {
    http_response_code(400);
    sendResponse(false, "No evidence image was received.");
}

$image = $_FILES["evidence_image"];

if ($image["error"] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    sendResponse(false, "Image upload failed.");
}

$maxSize = 10 * 1024 * 1024;

if ($image["size"] <= 0 || $image["size"] > $maxSize) {
    http_response_code(400);
    sendResponse(false, "Image must be smaller than 10 MB.");
}

$check = $conn->prepare(
    "SELECT AccidentID FROM accidents WHERE AccidentID = ?"
);

if (!$check) {
    http_response_code(500);
    sendResponse(false, "Unable to validate accident.");
}

$check->bind_param("i", $accidentId);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    $check->close();
    http_response_code(404);
    sendResponse(false, "Accident not found.");
}

$check->close();

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($image["tmp_name"]);

$allowedTypes = [
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/webp" => "webp"
];

if (!isset($allowedTypes[$mimeType])) {
    http_response_code(400);
    sendResponse(false, "Only JPEG, PNG and WebP images are supported.");
}

$uploadDirectory = __DIR__ . "/accident_uploads/";

if (!is_dir($uploadDirectory)) {
    if (!mkdir($uploadDirectory, 0755, true)) {
        http_response_code(500);
        sendResponse(false, "Unable to create upload folder.");
    }
}

$fileName = bin2hex(random_bytes(16))
        . "." . $allowedTypes[$mimeType];

$destination = $uploadDirectory . $fileName;

if (!move_uploaded_file($image["tmp_name"], $destination)) {
    http_response_code(500);
    sendResponse(false, "Unable to store evidence image.");
}

$imagePath = "accident_uploads/" . $fileName;

$stmt = $conn->prepare(
    "INSERT INTO accident_evidence
    (AccidentID, EvidenceCategory, ImagePath)
    VALUES (?, ?, ?)"
);

if (!$stmt) {
    unlink($destination);
    http_response_code(500);
    sendResponse(false, "Unable to prepare evidence record.");
}

$stmt->bind_param(
    "iss",
    $accidentId,
    $category,
    $imagePath
);

if ($stmt->execute()) {
    $evidenceId = $conn->insert_id;

    $stmt->close();
    $conn->close();

    sendResponse(
        true,
        "Evidence uploaded successfully.",
        $evidenceId
    );
}

$stmt->close();
unlink($destination);

http_response_code(500);
sendResponse(false, "Unable to save evidence record.");

?>
