<?php

include 'db_connect.php';

$documentID = filter_input(
    INPUT_GET,
    'documentID',
    FILTER_VALIDATE_INT
);

if (!$documentID || $documentID < 1) {
    http_response_code(400);
    exit("Invalid document ID");
}

$stmt = mysqli_prepare(
    $conn,
    "SELECT documentPath FROM FileVault WHERE documentID = ?"
);

mysqli_stmt_bind_param($stmt, "i", $documentID);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $documentPath);

if (!mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    http_response_code(404);
    exit("Document not found");
}

mysqli_stmt_close($stmt);

if (empty($documentPath)) {
    http_response_code(404);
    exit("No file attached to this document");
}

$uploadsDirectory = realpath(__DIR__ . '/uploads');

if ($uploadsDirectory === false) {
    http_response_code(500);
    exit("Uploads directory not found");
}

$filePath = realpath(__DIR__ . '/' . $documentPath);

if (
    $filePath === false ||
    !is_file($filePath) ||
    !str_starts_with(
        $filePath,
        $uploadsDirectory . DIRECTORY_SEPARATOR
    )
) {
    http_response_code(404);
    exit("File not found");
}

$mimeType = mime_content_type($filePath);

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($filePath));
header('Content-Disposition: inline; filename="document"');
header('X-Content-Type-Options: nosniff');

readfile($filePath);
exit;

?>
