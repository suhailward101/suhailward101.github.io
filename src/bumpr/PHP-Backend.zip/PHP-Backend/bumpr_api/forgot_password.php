<?php

require 'db_connect.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email'] ?? '');

if (empty($email)) {
    echo json_encode([
        "success" => false,
        "message" => "Email is required."
    ]);
    exit;
}

/*
 * Find the user
 */
$stmt = $conn->prepare(
    "SELECT UserID, FullName, Email
     FROM Users
     WHERE Email = ?"
);

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "No account found with that email address."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

$stmt->close();

/*
 * Generate a secure reset token
 */
$token = bin2hex(random_bytes(32));

/*
 * Token expires after 30 minutes
 */
$expiresAt = date(
    'Y-m-d H:i:s',
    strtotime('+30 minutes')
);

/*
 * Remove old unused reset tokens for this user
 */
$deleteStmt = $conn->prepare(
    "DELETE FROM password_resets
     WHERE UserID = ?
     AND Used = 0"
);

$deleteStmt->bind_param("i", $user['UserID']);
$deleteStmt->execute();
$deleteStmt->close();

/*
 * Store the new reset token
 */
$insertStmt = $conn->prepare(
    "INSERT INTO password_resets
     (UserID, Token, ExpiresAt)
     VALUES (?, ?, ?)"
);

$insertStmt->bind_param(
    "iss",
    $user['UserID'],
    $token,
    $expiresAt
);

if (!$insertStmt->execute()) {

    echo json_encode([
        "success" => false,
        "message" => "Could not create password reset request."
    ]);

    $insertStmt->close();
    $conn->close();
    exit;
}

$insertStmt->close();

/*
 * Create reset link
 *
 * This currently uses your local XAMPP server.
 */
$resetLink =
    "http://192.168.1.173/bumpr_api/reset_password.php?token="
    . urlencode($token);

/*
 * Load Bumpr email configuration
 */
$emailConfig = require 'email_config.php';

/*
 * Send email using PHPMailer
 */
$mail = new PHPMailer(true);

try {

    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $emailConfig['username'];
    $mail->Password = $emailConfig['password'];

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom(
        $emailConfig['username'],
        'Bumpr Support'
    );

    $mail->addAddress(
        $user['Email'],
        $user['FullName']
    );

    $mail->isHTML(true);

    $mail->Subject = 'Reset your Bumpr password';

    $mail->Body = '
        <h2>Bumpr Password Reset</h2>

        <p>Hello ' . htmlspecialchars($user['FullName']) . ',</p>

        <p>
            We received a request to reset your Bumpr password.
        </p>

        <p>
            Click the button below to create a new password:
        </p>

        <p>
            <a href="' . $resetLink . '"
               style="
               display:inline-block;
               padding:12px 20px;
               background-color:#1E88E5;
               color:white;
               text-decoration:none;
               border-radius:8px;">
               Reset Password
            </a>
        </p>

        <p>
            This link will expire in 30 minutes.
        </p>

        <p>
            If you did not request a password reset, you can ignore this email.
        </p>

        <p>
            Regards,<br>
            Bumpr Support
        </p>
    ';

    $mail->AltBody =
        "Bumpr Password Reset\n\n"
        . "Hello " . $user['FullName'] . ",\n\n"
        . "Use the following link to reset your password:\n"
        . $resetLink . "\n\n"
        . "This link will expire in 30 minutes.";

    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Password reset instructions sent!"
    ]);

} catch (Exception $e) {

    echo json_encode([
        "success" => false,
        "message" => "Could not send reset email."
    ]);
}

$conn->close();

?>