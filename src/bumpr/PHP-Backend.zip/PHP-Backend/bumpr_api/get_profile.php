<?php
require 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);

$userId = $data['userId'] ?? 0;

if (empty($userId)) {
    echo json_encode([
        "success" => false,
        "message" => "User ID is required."
    ]);
    exit;
}

$stmt = $conn->prepare(
    "SELECT UserID, FullName, Email, PhoneNumber
     FROM Users
     WHERE UserID = ?"
);

$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "User not found."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

echo json_encode([
    "success" => true,
    "userId" => $user['UserID'],
    "fullName" => $user['FullName'],
    "email" => $user['Email'],
    "phoneNumber" => $user['PhoneNumber']
]);

$stmt->close();
$conn->close();
?>