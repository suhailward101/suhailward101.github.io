<?php
require 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(["success" => false, "message" => "Email and password are required."]);
    exit;
}

$stmt = $conn->prepare("SELECT UserID, FullName, Password FROM Users WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Incorrect email or password."]);
    $stmt->close();
    exit;
}

$user = $result->fetch_assoc();

if (password_verify($password, $user['Password'])) {
    echo json_encode([
        "success" => true,
        "message" => "Login successful.",
        "userId" => $user['UserID'],
        "fullName" => $user['FullName']
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Incorrect email or password."]);
}

$stmt->close();
$conn->close();
?>