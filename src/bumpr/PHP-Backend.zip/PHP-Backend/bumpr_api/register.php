<?php

require 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);

$fullName = trim($data['fullName'] ?? '');
$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';

/* =========================
   REQUIRED FIELD VALIDATION
   ========================= */

if (empty($fullName) || empty($email) || empty($password)) {

    echo json_encode([
        "success" => false,
        "message" => "All fields are required."
    ]);

    exit;
}


/* =========================
   FULL NAME VALIDATION
   ========================= */

if (strlen($fullName) < 2) {

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid full name."
    ]);

    exit;
}


/* =========================
   EMAIL VALIDATION
   ========================= */

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);

    exit;
}


/* =========================
   PASSWORD VALIDATION
   ========================= */

if (strlen($password) < 8) {

    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 8 characters."
    ]);

    exit;
}


/* =========================
   CHECK IF EMAIL EXISTS
   ========================= */

$checkStmt = $conn->prepare(
    "SELECT UserID FROM Users WHERE Email = ?"
);

$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {

    echo json_encode([
        "success" => false,
        "message" => "Email already registered."
    ]);

    $checkStmt->close();
    $conn->close();

    exit;
}

$checkStmt->close();


/* =========================
   HASH PASSWORD
   ========================= */

$hashedPassword = password_hash(
    $password,
    PASSWORD_BCRYPT
);


/* =========================
   INSERT USER
   ========================= */

$insertStmt = $conn->prepare(
    "INSERT INTO Users (FullName, Email, Password)
     VALUES (?, ?, ?)"
);

$insertStmt->bind_param(
    "sss",
    $fullName,
    $email,
    $hashedPassword
);


/* =========================
   RESULT
   ========================= */

if ($insertStmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Registration successful."
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Registration failed: " . $insertStmt->error
    ]);
}


$insertStmt->close();
$conn->close();

?>