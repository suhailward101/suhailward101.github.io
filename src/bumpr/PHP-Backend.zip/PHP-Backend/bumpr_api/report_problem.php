<?php

require 'db_connect.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$data = json_decode(file_get_contents("php://input"), true);

$userId = $data['userId'] ?? 0;
$problem = trim($data['problem'] ?? '');

if (empty($userId) || empty($problem)) {

    echo json_encode([
        "success" => false,
        "message" => "Please describe the problem."
    ]);

    exit;
}

/*
 * Get the user's details from the database.
 */
$stmt = $conn->prepare(
    "SELECT FullName, Email
     FROM Users
     WHERE UserID = ?"
);

$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "message" => "User not found."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}

$user = $result->fetch_assoc();

$stmt->close();

/*
 * Load Bumpr email credentials.
 */
$emailConfig = require __DIR__ . '/email_config.php';

$mail = new PHPMailer(true);

try {

    /*
     * Gmail SMTP settings.
     */
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $emailConfig['username'];
    $mail->Password = $emailConfig['password'];
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    /*
     * Sender.
     */
    $mail->setFrom(
        $emailConfig['username'],
        'Bumpr Support'
    );

    /*
     * Send the report to the Bumpr support email.
     */
    $mail->addAddress(
        $emailConfig['username'],
        'Bumpr Support'
    );

    /*
     * Allow the support team to reply directly
     * to the user who submitted the report.
     */
    $mail->addReplyTo(
        $user['Email'],
        $user['FullName']
    );

    /*
     * Email format.
     */
    $mail->isHTML(true);

    $mail->Subject = 'Bumpr Problem Report';

    /*
     * Protect user-submitted information before
     * putting it into the HTML email.
     */
    $fullName = htmlspecialchars(
        $user['FullName'],
        ENT_QUOTES,
        'UTF-8'
    );

    $email = htmlspecialchars(
        $user['Email'],
        ENT_QUOTES,
        'UTF-8'
    );

    $problemText = nl2br(
        htmlspecialchars(
            $problem,
            ENT_QUOTES,
            'UTF-8'
        )
    );

    /*
     * HTML email.
     */
    $mail->Body = '
        <div style="
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: auto;
            padding: 25px;
            border: 1px solid #dddddd;
            border-radius: 12px;
        ">

            <h2 style="color: #0B1F3A;">
                Bumpr Problem Report
            </h2>

            <p>
                A user has submitted a problem through the Bumpr app.
            </p>

            <hr>

            <p>
                <strong>User:</strong><br>
                ' . $fullName . '
            </p>

            <p>
                <strong>Email:</strong><br>
                ' . $email . '
            </p>

            <p>
                <strong>Problem:</strong><br>
                ' . $problemText . '
            </p>

            <hr>

            <p style="color: #777777; font-size: 13px;">
                This report was submitted through the Bumpr application.
            </p>

        </div>
    ';

    /*
     * Plain-text version for email clients
     * that do not support HTML.
     */
    $mail->AltBody =
        "Bumpr Problem Report\n\n" .
        "User: " . $user['FullName'] . "\n" .
        "Email: " . $user['Email'] . "\n\n" .
        "Problem:\n" .
        $problem . "\n\n" .
        "This report was submitted through the Bumpr application.";

    /*
     * Send the email.
     */
    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Your problem has been reported successfully."
    ]);

} catch (Exception $e) {

    echo json_encode([
        "success" => false,
        "message" => "Could not send the problem report."
    ]);
}

$conn->close();

?>