<?php

require 'db_connect.php';

$token = $_GET['token'] ?? '';

if (empty($token)) {
    die("Invalid password reset link.");
}

/*
 * Check that the token exists, hasn't been used,
 * and hasn't expired.
 */
$stmt = $conn->prepare(
    "SELECT UserID
     FROM password_resets
     WHERE Token = ?
     AND Used = 0
     AND ExpiresAt > NOW()"
);

$stmt->bind_param("s", $token);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();

    die("This password reset link is invalid or has expired.");
}

$reset = $result->fetch_assoc();

$stmt->close();

$userId = $reset['UserID'];


/*
 * If the form was submitted
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';

    if (empty($password) || empty($confirmPassword)) {

        $error = "Please enter and confirm your new password.";

    } elseif ($password !== $confirmPassword) {

        $error = "Passwords do not match.";

    } elseif (strlen($password) < 6) {

        $error = "Password must be at least 6 characters.";

    } else {

        /*
         * Hash the new password
         */
        $hashedPassword = password_hash(
            $password,
            PASSWORD_BCRYPT
        );

        /*
         * Update the user's password
         */
        $updateStmt = $conn->prepare(
            "UPDATE Users
             SET Password = ?
             WHERE UserID = ?"
        );

        $updateStmt->bind_param(
            "si",
            $hashedPassword,
            $userId
        );

        if ($updateStmt->execute()) {

            /*
             * Mark the reset token as used
             */
            $usedStmt = $conn->prepare(
                "UPDATE password_resets
                 SET Used = 1
                 WHERE Token = ?"
            );

            $usedStmt->bind_param("s", $token);
            $usedStmt->execute();
            $usedStmt->close();

            $updateStmt->close();
            $conn->close();

            ?>

            <!DOCTYPE html>
            <html>
            <head>

                <meta charset="UTF-8">

                <meta name="viewport"
                      content="width=device-width, initial-scale=1.0">

                <title>Bumpr - Password Reset</title>

                <style>

                    body {
                        font-family: Arial, sans-serif;
                        background: #0B1F3A;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                    }

                    .card {
                        background: white;
                        padding: 35px;
                        border-radius: 16px;
                        width: 90%;
                        max-width: 420px;
                        text-align: center;
                    }

                    h1 {
                        color: #0B1F3A;
                    }

                    p {
                        color: #555;
                    }

                </style>

            </head>

            <body>

                <div class="card">

                    <h1>Password Reset Successful</h1>

                    <p>
                        Your Bumpr password has been successfully changed.
                    </p>

                    <p>
                        You can now return to the Bumpr app and log in
                        using your new password.
                    </p>

                </div>

            </body>
            </html>

            <?php

            exit;

        } else {

            $error = "Could not update your password.";
        }

        $updateStmt->close();
    }
}

?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Bumpr - Reset Password</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #0B1F3A;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .card {
            background: white;
            padding: 35px;
            border-radius: 16px;
            width: 90%;
            max-width: 420px;
        }

        h1 {
            color: #0B1F3A;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 18px;
            margin-bottom: 6px;
            color: #333;
            font-weight: bold;
        }

        input {
            width: 100%;
            box-sizing: border-box;
            padding: 13px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        button {
            width: 100%;
            margin-top: 25px;
            padding: 14px;
            border: none;
            border-radius: 8px;
            background: #1E88E5;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .error {
            background: #ffe5e5;
            color: #b00020;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="card">

    <h1>Reset Your Password</h1>

    <?php if (!empty($error)): ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>

    <form method="POST">

        <label for="password">
            New Password
        </label>

        <input
            type="password"
            id="password"
            name="password"
            required
        >

        <label for="confirmPassword">
            Confirm New Password
        </label>

        <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            required
        >

        <button type="submit">
            Reset Password
        </button>

    </form>

</div>

</body>

</html>

<?php

$conn->close();

?>