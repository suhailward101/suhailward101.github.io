<?php

require 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);

$userId = $data['userId'] ?? 0;
$fullName = $data['fullName'] ?? '';
$email = $data['email'] ?? '';
$phoneNumber = $data['phoneNumber'] ?? '';
$password = $data['password'] ?? '';

if (empty($userId) || empty($fullName) || empty($email)) {

    echo json_encode([
        "success" => false,
        "message" => "Full name and email are required."
    ]);

    exit;
}


/*
 * Check if another user is already using this email.
 */
$checkStmt = $conn->prepare(
    "SELECT UserID
     FROM Users
     WHERE Email = ?
     AND UserID != ?"
);

$checkStmt->bind_param(
    "si",
    $email,
    $userId
);

$checkStmt->execute();

$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {

    echo json_encode([
        "success" => false,
        "message" => "This email is already registered to another account."
    ]);

    $checkStmt->close();
    $conn->close();

    exit;
}

$checkStmt->close();


/*
 * Update profile information.
 */
if (!empty($password)) {

    $hashedPassword = password_hash(
        $password,
        PASSWORD_BCRYPT
    );

    $updateStmt = $conn->prepare(
        "UPDATE Users
         SET FullName = ?,
             Email = ?,
             PhoneNumber = ?,
             Password = ?
         WHERE UserID = ?"
    );

    $updateStmt->bind_param(
        "ssssi",
        $fullName,
        $email,
        $phoneNumber,
        $hashedPassword,
        $userId
    );

} else {

    $updateStmt = $conn->prepare(
        "UPDATE Users
         SET FullName = ?,
             Email = ?,
             PhoneNumber = ?
         WHERE UserID = ?"
    );

    $updateStmt->bind_param(
        "sssi",
        $fullName,
        $email,
        $phoneNumber,
        $userId
    );
}


if ($updateStmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Profile updated successfully."
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Profile update failed: " . $updateStmt->error
    ]);
}

$updateStmt->close();
$conn->close();

?>