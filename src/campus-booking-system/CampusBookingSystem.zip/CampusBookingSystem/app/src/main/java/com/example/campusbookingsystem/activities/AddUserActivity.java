package com.example.campusbookingsystem.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.R;

public class AddUserActivity extends BaseActivity {

    EditText edtName;
    EditText edtSurname;
    EditText edtEmail;
    EditText edtPassword;

    Spinner spinnerRole;

    Button btnSaveUser;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        databaseHelper = new DatabaseHelper(this);

        edtName = findViewById(R.id.edtName);

        edtSurname = findViewById(R.id.edtSurname);

        edtEmail = findViewById(R.id.edtEmail);

        edtPassword = findViewById(R.id.edtPassword);

        spinnerRole = findViewById(R.id.spinnerRole);

        btnSaveUser = findViewById(R.id.btnSaveUser);

        String[] roles = {

                "Student",

                "Admin"

        };
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        roles
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerRole.setAdapter(adapter);

        btnSaveUser.setOnClickListener(v -> {

            String name = edtName.getText().toString().trim();

            String surname = edtSurname.getText().toString().trim();

            String email = edtEmail.getText().toString().trim();

            String password = edtPassword.getText().toString().trim();

            String role = spinnerRole.getSelectedItem().toString();

            if (name.isEmpty() ||
                    surname.isEmpty() ||
                    email.isEmpty() ||
                    password.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please complete all fields.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (databaseHelper.emailExists(email)) {

                Toast.makeText(
                        this,
                        "Email address already exists.",
                        Toast.LENGTH_SHORT
                ).show();

                return;

            }

            boolean inserted = databaseHelper.insertUser(

                    name,

                    surname,

                    email,

                    password,

                    role

            );

            if (inserted) {
                Toast.makeText(

                        this,

                        "User added successfully.",

                        Toast.LENGTH_SHORT

                ).show();
                finish();
            }

            else {

                Toast.makeText(

                        this,

                        "Failed to add user.",

                        Toast.LENGTH_SHORT

                ).show();

            }

        });

    }

}