package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import com.example.campusbookingsystem.utils.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.session.SessionManager;

public class AddVenueActivity extends BaseActivity {

    EditText etVenueName;
    EditText etLocation;
    EditText etCapacity;
    EditText etDescription;

    Button btnSaveVenue;

    Animation pressAnimation;
    Animation releaseAnimation;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_venue);

        sessionManager = new SessionManager(this);

        if (sessionManager.getUserId() == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        etVenueName = findViewById(R.id.etVenueName);
        etLocation = findViewById(R.id.etLocation);
        etCapacity = findViewById(R.id.etCapacity);
        etDescription = findViewById(R.id.etDescription);
        btnSaveVenue = findViewById(R.id.btnSaveVenue);

        etVenueName.animate()
                .alpha(1f)
                .setDuration(400)
                .start();

        etLocation.animate()
                .alpha(1f)
                .setStartDelay(100)
                .setDuration(400)
                .start();

        etCapacity.animate()
                .alpha(1f)
                .setStartDelay(200)
                .setDuration(400)
                .start();

        etDescription.animate()
                .alpha(1f)
                .setStartDelay(300)
                .setDuration(400)
                .start();

        btnSaveVenue.animate()
                .alpha(1f)
                .setStartDelay(400)
                .setDuration(400)
                .start();

        pressAnimation = android.view.animation.AnimationUtils.loadAnimation(
                this,
                R.anim.button_press
        );

        releaseAnimation = android.view.animation.AnimationUtils.loadAnimation(
                this,
                R.anim.button_release
        );

        AnimationUtils.addPressAnimation(
                btnSaveVenue,
                pressAnimation,
                releaseAnimation
        );

        databaseHelper = new DatabaseHelper(this);

        btnSaveVenue.setOnClickListener(v -> {

            String venueName = etVenueName.getText().toString().trim();
            String location = etLocation.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String capacityText = etCapacity.getText().toString().trim();

            if (venueName.isEmpty() ||
                    location.isEmpty() ||
                    description.isEmpty() ||
                    capacityText.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please fill all fields",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int capacity;

            try {

                capacity = Integer.parseInt(capacityText);

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Capacity must be a valid number",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean inserted = databaseHelper.insertVenue(
                    venueName,
                    location,
                    capacity,
                    description
            );

            if (inserted) {

                Toast.makeText(
                        this,
                        "Venue Saved",
                        Toast.LENGTH_SHORT
                ).show();

                etVenueName.setText("");
                etLocation.setText("");
                etCapacity.setText("");
                etDescription.setText("");

            } else {

                Toast.makeText(
                        this,
                        "Save Failed",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}