package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.session.SessionManager;

import java.util.ArrayList;

public class AdminBookingListActivity extends BaseActivity {

    ListView listView;

    EditText etSearchBookings;

    Button btnAll;
    Button btnPending;
    Button btnApproved;
    Button btnRejected;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    ArrayList<Integer> bookingIds;
    ArrayList<String> bookingInfo;

    ArrayList<String> studentNames;
    ArrayList<String> venueNames;
    ArrayList<String> bookingDates;
    ArrayList<String> bookingTimes;
    ArrayList<String> bookingStatuses;

    ArrayList<Integer> filteredBookingIds;
    ArrayList<String> filteredBookingInfo;
    ArrayList<String> filteredStudents;
    ArrayList<String> filteredVenues;
    ArrayList<String> filteredDates;
    ArrayList<String> filteredTimes;
    ArrayList<String> filteredStatuses;

    String currentFilter = "All";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_bookings);

        sessionManager = new SessionManager(this);

        if (sessionManager.getUserId() == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        listView = findViewById(R.id.listView);

        etSearchBookings = findViewById(R.id.etSearchBookings);

        btnAll = findViewById(R.id.btnAll);
        btnPending = findViewById(R.id.btnPending);
        btnApproved = findViewById(R.id.btnApproved);
        btnRejected = findViewById(R.id.btnRejected);

        loadBookings();

        btnAll.setOnClickListener(v -> {
            currentFilter = "All";
            filterBookings();
        });

        btnPending.setOnClickListener(v -> {
            currentFilter = "Pending";
            filterBookings();
        });

        btnApproved.setOnClickListener(v -> {
            currentFilter = "Approved";
            filterBookings();
        });

        btnRejected.setOnClickListener(v -> {
            currentFilter = "Rejected";
            filterBookings();
        });

        etSearchBookings.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterBookings();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {

            Intent intent = new Intent(
                    AdminBookingListActivity.this,
                    UpdateBookingActivity.class
            );

            intent.putExtra("bookingId", filteredBookingIds.get(position));
            intent.putExtra("student", filteredStudents.get(position));
            intent.putExtra("venue", filteredVenues.get(position));
            intent.putExtra("date", filteredDates.get(position));
            intent.putExtra("time", filteredTimes.get(position));
            intent.putExtra("status", filteredStatuses.get(position));

            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBookings();
    }

    private void loadBookings() {

        bookingIds = new ArrayList<>();
        bookingInfo = new ArrayList<>();

        studentNames = new ArrayList<>();
        venueNames = new ArrayList<>();
        bookingDates = new ArrayList<>();
        bookingTimes = new ArrayList<>();
        bookingStatuses = new ArrayList<>();

        Cursor cursor = databaseHelper.getAllBookings();

        if (cursor != null) {

            if (cursor.moveToFirst()) {

                do {

                    int bookingId = cursor.getInt(0);

                    String student =
                            cursor.getString(1) + " " + cursor.getString(2);

                    String venue = cursor.getString(3);

                    String date = cursor.getString(4);

                    String time =
                            cursor.getString(5) +
                                    " - " +
                                    cursor.getString(6);

                    String status = cursor.getString(7);

                    String info =
                            "Booking ID: " + bookingId +

                                    "\n\nStudent: " + student +

                                    "\nVenue: " + venue +

                                    "\nDate: " + date +

                                    "\nTime: " + time +

                                    "\nStatus: " + status;

                    bookingIds.add(bookingId);
                    bookingInfo.add(info);

                    studentNames.add(student);
                    venueNames.add(venue);
                    bookingDates.add(date);
                    bookingTimes.add(time);
                    bookingStatuses.add(status);

                } while (cursor.moveToNext());
            }

            cursor.close();
        }

        filterBookings();
    }

    private void filterBookings() {

        filteredBookingIds = new ArrayList<>();
        filteredBookingInfo = new ArrayList<>();

        filteredStudents = new ArrayList<>();
        filteredVenues = new ArrayList<>();
        filteredDates = new ArrayList<>();
        filteredTimes = new ArrayList<>();
        filteredStatuses = new ArrayList<>();

        String search = etSearchBookings.getText().toString().toLowerCase().trim();

        for (int i = 0; i < bookingInfo.size(); i++) {

            boolean matchesStatus =
                    currentFilter.equals("All") ||
                            bookingStatuses.get(i).equalsIgnoreCase(currentFilter);

            boolean matchesSearch =
                    bookingInfo.get(i).toLowerCase().contains(search);

            if (matchesStatus && matchesSearch) {

                filteredBookingIds.add(bookingIds.get(i));
                filteredBookingInfo.add(bookingInfo.get(i));

                filteredStudents.add(studentNames.get(i));
                filteredVenues.add(venueNames.get(i));
                filteredDates.add(bookingDates.get(i));
                filteredTimes.add(bookingTimes.get(i));
                filteredStatuses.add(bookingStatuses.get(i));
            }
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_list_item_1,
                        filteredBookingInfo
                );

        listView.setAdapter(adapter);
    }
}