package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.session.SessionManager;

public class AdminDashboardActivity extends BaseActivity {

    CardView cardAddVenue;
    CardView cardBookings;
    CardView cardManageUsers;
    CardView cardLogout;

    TextView txtVenueCount;
    TextView txtBookingCount;
    TextView txtPendingCount;
    TextView txtApprovedCount;
    TextView txtStudentCount;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        databaseHelper = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        if (sessionManager.getUserId() == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        String role = databaseHelper.getUserRoleById(
                sessionManager.getUserId()
        );

        if (!"Admin".equals(role)) {
            startActivity(new Intent(this, StudentDashboardActivity.class));
            finish();
            return;
        }

        txtVenueCount = findViewById(R.id.txtVenueCount);
        txtBookingCount = findViewById(R.id.txtBookingCount);
        txtPendingCount = findViewById(R.id.txtPendingCount);
        txtApprovedCount = findViewById(R.id.txtApprovedCount);
        txtStudentCount = findViewById(R.id.txtStudentCount);

        cardAddVenue = findViewById(R.id.cardAddVenue);
        cardBookings = findViewById(R.id.cardBookings);
        cardManageUsers = findViewById(R.id.cardManageUsers);
        cardLogout = findViewById(R.id.cardLogout);

        loadDashboardStats();

        cardAddVenue.setOnClickListener(v -> {

            Intent intent = new Intent(
                    AdminDashboardActivity.this,
                    ManageVenuesActivity.class
            );

            startActivity(intent);
        });

        cardBookings.setOnClickListener(v -> {

            Intent intent = new Intent(
                    AdminDashboardActivity.this,
                    AdminBookingListActivity.class
            );

            startActivity(intent);
        });

        cardManageUsers.setOnClickListener(v -> {

            Intent intent = new Intent(
                    AdminDashboardActivity.this,
                    UserManagementActivity.class
            );

            startActivity(intent);

        });

        cardLogout.setOnClickListener(v -> {

            sessionManager.logout();

            Intent intent = new Intent(
                    AdminDashboardActivity.this,
                    LoginActivity.class
            );

            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {

        super.onResume();

        loadDashboardStats();

    }

    private void loadDashboardStats() {

        txtVenueCount.setText(
                String.valueOf(
                        databaseHelper.getVenueCount()
                )
        );

        txtBookingCount.setText(
                String.valueOf(
                        databaseHelper.getBookingCount()
                )
        );

        txtPendingCount.setText(
                String.valueOf(
                        databaseHelper.getPendingBookingCount()
                )
        );

        txtApprovedCount.setText(
                String.valueOf(
                        databaseHelper.getApprovedBookingCount()
                )
        );

        txtStudentCount.setText(
                String.valueOf(
                        databaseHelper.getStudentCount()
                )
        );
    }
}