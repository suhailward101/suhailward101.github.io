package com.example.campusbookingsystem.activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.session.SessionManager;
import java.util.Locale;
import java.util.Calendar;

public class BookingActivity extends AppCompatActivity {

    EditText etBookingDate, etStartTime, etEndTime;
    TextView txtVenueName;
    TextView txtVenueLocation;
    TextView txtVenueCapacity;
    TextView txtVenueDescription;
    Button btnBookVenue;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    int venueId;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        txtVenueName = findViewById(R.id.txtVenueName);

        txtVenueLocation = findViewById(R.id.txtVenueLocation);
        txtVenueCapacity = findViewById(R.id.txtVenueCapacity);
        txtVenueDescription = findViewById(R.id.txtVenueDescription);

        etBookingDate = findViewById(R.id.etBookingDate);

        etBookingDate.setFocusable(false);
        etBookingDate.setClickable(true);

        etStartTime = findViewById(R.id.etStartTime);
        etEndTime = findViewById(R.id.etEndTime);

        etStartTime.setFocusable(false);
        etStartTime.setClickable(true);

        etEndTime.setFocusable(false);
        etEndTime.setClickable(true);

        btnBookVenue = findViewById(R.id.btnBookVenue);

        databaseHelper = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        if (sessionManager.getUserId() == -1) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        userId = sessionManager.getUserId();

        Intent intent = getIntent();

        venueId = intent.getIntExtra("venueId", -1);

        String venueName = intent.getStringExtra("venueName");

        String location = intent.getStringExtra("location");
        int capacity = intent.getIntExtra("capacity", 0);
        String description = intent.getStringExtra("description");

        txtVenueName.setText(
                getString(
                        R.string.selected_venue,
                        venueName
                )
        );

        txtVenueLocation.setText(location);

        txtVenueCapacity.setText(
                capacity + " Students"
        );

        txtVenueDescription.setText(description);

        if (venueId == -1) {
            Toast.makeText(this, "Invalid venue selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Calendar calendar = Calendar.getInstance();

        etBookingDate.setOnClickListener(v -> {

            DatePickerDialog picker = new DatePickerDialog(
                    BookingActivity.this,
                    (view, year, month, dayOfMonth) -> {

                        String date = year + "-" +
                                String.format(Locale.getDefault(), "%02d", month + 1) + "-" +
                                String.format(Locale.getDefault(), "%02d", dayOfMonth);

                        etBookingDate.setText(date);

                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            picker.getDatePicker().setMinDate(
                    System.currentTimeMillis() - 1000
            );

            picker.show();
        });

        etStartTime.setOnClickListener(v -> {

            TimePickerDialog picker = new TimePickerDialog(
                    BookingActivity.this,
                    (view, hourOfDay, minute) -> {

                        String time = String.format(
                                Locale.getDefault(),
                                "%02d:%02d",
                                hourOfDay,
                                minute
                        );

                        etStartTime.setText(time);

                    },
                    8,
                    0,
                    true
            );

            picker.show();
        });

        etEndTime.setOnClickListener(v -> {

            TimePickerDialog picker = new TimePickerDialog(
                    BookingActivity.this,
                    (view, hourOfDay, minute) -> {

                        String time = String.format(
                                Locale.getDefault(),
                                "%02d:%02d",
                                hourOfDay,
                                minute
                        );

                        etEndTime.setText(time);

                    },
                    9,
                    0,
                    true
            );

            picker.show();
        });

        btnBookVenue.setOnClickListener(v -> {

            if (!btnBookVenue.isEnabled()) {
                return;
            }

            String date = etBookingDate.getText().toString().trim();
            String start = etStartTime.getText().toString().trim();
            String end = etEndTime.getText().toString().trim();

            if (date.isEmpty() || start.isEmpty() || end.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isEndTimeAfterStartTime(start, end)) {

                Toast.makeText(
                        this,
                        "End time must be after start time",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (!isBookingDurationValid(start, end)) {

                Toast.makeText(
                        this,
                        "Bookings cannot exceed 4 hours",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (!isWithinCampusHours(start, end)) {

                Toast.makeText(
                        this,
                        "Bookings are only allowed between 08:00 and 18:00",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (databaseHelper.hasUserBookedVenue(
                    userId,
                    venueId,
                    date,
                    start,
                    end
            )) {

                Toast.makeText(
                        this,
                        "You have already made this booking.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean available = databaseHelper.isVenueAvailable(
                    venueId,
                    date,
                    start,
                    end
            );

            if (!available) {
                Toast.makeText(this, "Time slot already booked", Toast.LENGTH_SHORT).show();
                return;
            }

            new AlertDialog.Builder(BookingActivity.this)
                    .setTitle("Confirm Booking")
                    .setMessage(
                            "Venue: " + txtVenueName.getText().toString() +
                                    "\n\nDate: " + date +
                                    "\nStart Time: " + start +
                                    "\nEnd Time: " + end +
                                    "\n\nConfirm this booking?"
                    )

                    .setPositiveButton("Confirm", (dialog, which) -> {

                        btnBookVenue.setEnabled(false);

                        boolean inserted = databaseHelper.insertBooking(
                                userId,
                                venueId,
                                date,
                                start,
                                end,
                                "Pending"
                        );

                        if (inserted) {

                            Toast.makeText(
                                    this,
                                    "Booking Successful",
                                    Toast.LENGTH_SHORT
                            ).show();

                            etBookingDate.setText("");
                            etStartTime.setText("");
                            etEndTime.setText("");

                            Intent myBookingsIntent = new Intent(
                                    BookingActivity.this,
                                    MyBookingsActivity.class
                            );

                            startActivity(myBookingsIntent);

                            finish();

                        } else {

                            Toast.makeText(
                                    this,
                                    "Booking Failed",
                                    Toast.LENGTH_SHORT
                            ).show();

                            btnBookVenue.setEnabled(true);

                        }

                    })

                    .setNegativeButton("Cancel", null)

                    .show();
        });
    }
    private boolean isEndTimeAfterStartTime(
            String start,
            String end
    ) {

        String[] startParts = start.split(":");
        String[] endParts = end.split(":");

        int startMinutes =
                Integer.parseInt(startParts[0]) * 60 +
                        Integer.parseInt(startParts[1]);

        int endMinutes =
                Integer.parseInt(endParts[0]) * 60 +
                        Integer.parseInt(endParts[1]);

        return endMinutes > startMinutes;
    }

    private boolean isWithinCampusHours(
            String start,
            String end
    ) {

        String[] startParts = start.split(":");
        String[] endParts = end.split(":");

        int startMinutes =
                Integer.parseInt(startParts[0]) * 60 +
                        Integer.parseInt(startParts[1]);

        int endMinutes =
                Integer.parseInt(endParts[0]) * 60 +
                        Integer.parseInt(endParts[1]);

        int openingTime = 8 * 60;
        int closingTime = 18 * 60;

        return startMinutes >= openingTime &&
                endMinutes <= closingTime;
    }

    private boolean isBookingDurationValid(
            String start,
            String end
    ) {

        String[] startParts = start.split(":");
        String[] endParts = end.split(":");

        int startMinutes =
                Integer.parseInt(startParts[0]) * 60 +
                        Integer.parseInt(startParts[1]);

        int endMinutes =
                Integer.parseInt(endParts[0]) * 60 +
                        Integer.parseInt(endParts[1]);

        int duration = endMinutes - startMinutes;

        return duration <= 240;
    }
}