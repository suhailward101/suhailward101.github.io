package com.example.campusbookingsystem.activities;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;


public class EditUserActivity extends BaseActivity {

    EditText edtName;
    EditText edtSurname;
    EditText edtEmail;
    EditText edtPassword;

    Spinner spinnerRole;

    Button btnUpdateUser;

    DatabaseHelper databaseHelper;

    int userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_user);
        databaseHelper = new DatabaseHelper(this);

        edtName = findViewById(R.id.edtName);

        edtSurname = findViewById(R.id.edtSurname);

        edtEmail = findViewById(R.id.edtEmail);

        edtPassword = findViewById(R.id.edtPassword);

        spinnerRole = findViewById(R.id.spinnerRole);

        btnUpdateUser = findViewById(R.id.btnUpdateUser);

        userId = getIntent().getIntExtra(
                "userId",
                -1
        );

        String[] roles = {

                "Student",

                "Admin"

        };


        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        roles
                );


        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        spinnerRole.setAdapter(adapter);

        if (userId != -1) {

            loadUser();

        } else {

            Toast.makeText(
                    this,
                    "Unable to load user.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        }

        btnUpdateUser.setOnClickListener(v -> {

            String name = edtName.getText().toString().trim();

            String surname = edtSurname.getText().toString().trim();

            String email = edtEmail.getText().toString().trim();

            String password = edtPassword.getText().toString().trim();

            String role = spinnerRole.getSelectedItem().toString();

            if (name.isEmpty() ||
                    surname.isEmpty() ||
                    email.isEmpty() ||
                    password.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please complete all fields.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean updated = databaseHelper.updateUser(
                    userId,
                    name,
                    surname,
                    email,
                    password,
                    role
            );

            if (updated) {

                Toast.makeText(
                        this,
                        "User updated successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Failed to update user.",
                        Toast.LENGTH_SHORT
                ).show();

            }

        });


    }

    private void loadUser() {

        Cursor cursor = databaseHelper.getUserById(userId);

        if (cursor.moveToFirst()) {

            edtName.setText(
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("name")
                    )
            );

            edtSurname.setText(
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("surname")
                    )
            );

            edtEmail.setText(
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("email")
                    )
            );

            edtPassword.setText(
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("password")
                    )
            );

            String role = cursor.getString(
                    cursor.getColumnIndexOrThrow("role")
            );

            if (role.equals("Admin")) {

                spinnerRole.setSelection(1);

            } else {

                spinnerRole.setSelection(0);

            }

        }

        cursor.close();

    }

}
