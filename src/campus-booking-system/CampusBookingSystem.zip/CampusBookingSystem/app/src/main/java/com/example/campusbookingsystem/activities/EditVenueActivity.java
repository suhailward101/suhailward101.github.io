package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.models.Venue;

public class EditVenueActivity extends BaseActivity {

    EditText etVenueName;
    EditText etLocation;
    EditText etCapacity;
    EditText etDescription;

    Button btnSave;
    Button btnDelete;

    DatabaseHelper databaseHelper;

    int venueId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_venue);
        etVenueName = findViewById(R.id.etVenueName);
        etLocation = findViewById(R.id.etLocation);
        etCapacity = findViewById(R.id.etCapacity);
        etDescription = findViewById(R.id.etDescription);

        btnSave = findViewById(R.id.btnSave);
        btnDelete = findViewById(R.id.btnDelete);

        databaseHelper = new DatabaseHelper(this);

        Intent intent = getIntent();

        venueId = intent.getIntExtra(
                "venueId",
                -1
        );

        if (venueId == -1) {

            Toast.makeText(
                    this,
                    "Invalid venue selected",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        Venue venue = databaseHelper.getVenueById(venueId);

        if (venue == null) {

            Toast.makeText(
                    this,
                    "Venue not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        etVenueName.setText(
                venue.getVenueName()
        );

        etLocation.setText(
                venue.getLocation()
        );

        etCapacity.setText(
                String.valueOf(
                        venue.getCapacity()
                )
        );

        etDescription.setText(
                venue.getDescription()
        );

        btnSave.setOnClickListener(v -> {

            String venueName = etVenueName.getText().toString().trim();
            String location = etLocation.getText().toString().trim();
            String capacityText = etCapacity.getText().toString().trim();
            String description = etDescription.getText().toString().trim();

            if (venueName.isEmpty() ||
                    location.isEmpty() ||
                    capacityText.isEmpty() ||
                    description.isEmpty()) {

                Toast.makeText(
                        EditVenueActivity.this,
                        "Please fill in all fields",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int capacity = Integer.parseInt(capacityText);

            boolean updated = databaseHelper.updateVenue(
                    venueId,
                    venueName,
                    location,
                    capacity,
                    description
            );

            if (updated) {

                Toast.makeText(
                        EditVenueActivity.this,
                        "Venue updated successfully",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        EditVenueActivity.this,
                        "Update failed",
                        Toast.LENGTH_SHORT
                ).show();

            }

        });

        btnDelete.setOnClickListener(v -> {

            if (databaseHelper.venueHasBookings(venueId)) {

                Toast.makeText(
                        EditVenueActivity.this,
                        "Cannot delete a venue that has bookings.",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            new AlertDialog.Builder(EditVenueActivity.this)

                    .setTitle("Delete Venue")

                    .setMessage(
                            "Are you sure you want to delete this venue?"
                    )

                    .setPositiveButton("Delete", (dialog, which) -> {

                        boolean deleted =
                                databaseHelper.deleteVenue(venueId);

                        if (deleted) {

                            Toast.makeText(
                                    EditVenueActivity.this,
                                    "Venue deleted successfully",
                                    Toast.LENGTH_SHORT
                            ).show();

                            finish();

                        } else {

                            Toast.makeText(
                                    EditVenueActivity.this,
                                    "Delete failed",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }

                    })

                    .setNegativeButton("Cancel", null)

                    .show();

        });
    }
}