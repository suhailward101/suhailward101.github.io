package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.session.SessionManager;
import com.example.campusbookingsystem.R;

public class LoginActivity extends AppCompatActivity {

    Button btnLogin;
    Button btnRegister;

    EditText etEmail;
    EditText etPassword;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnGoRegister);

        databaseHelper = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        if (sessionManager.isLoggedIn()) {

            String role = sessionManager.getRole();

            Intent intent = "Admin".equals(role)
                    ? new Intent(this, AdminDashboardActivity.class)
                    : new Intent(this, StudentDashboardActivity.class);

            startActivity(intent);
            finish();
            return;
        }

        btnRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class))
        );

        btnLogin.setOnClickListener(v -> {

            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            int userId = databaseHelper.getUserId(email, password);
            String role = databaseHelper.getUserRole(email, password);

            if (userId != -1 && role != null) {

                sessionManager.createLoginSession(userId, email, role);

                Intent intent = "Admin".equals(role)
                        ? new Intent(this, AdminDashboardActivity.class)
                        : new Intent(this, StudentDashboardActivity.class);

                startActivity(intent);
                finish();

            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });
    }
}