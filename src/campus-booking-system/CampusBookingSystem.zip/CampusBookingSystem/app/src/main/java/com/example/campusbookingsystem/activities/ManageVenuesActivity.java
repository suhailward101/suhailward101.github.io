package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.adapters.ManageVenueAdapter;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.models.Venue;
import com.example.campusbookingsystem.session.SessionManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ManageVenuesActivity extends BaseActivity {

    RecyclerView recyclerManageVenues;
    FloatingActionButton fabAddVenue;
    EditText etSearchVenue;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    ArrayList<Venue> venueList;
    ManageVenueAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_venues);

        sessionManager = new SessionManager(this);

        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        recyclerManageVenues = findViewById(R.id.recyclerManageVenues);
        etSearchVenue = findViewById(R.id.etSearchVenue);
        fabAddVenue = findViewById(R.id.fabAddVenue);

        databaseHelper = new DatabaseHelper(this);

        recyclerManageVenues.setLayoutManager(new LinearLayoutManager(this));

        loadVenues();

        etSearchVenue.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                ArrayList<Venue> filteredList = new ArrayList<>();

                for (Venue venue : venueList) {

                    if (venue.getVenueName()
                            .toLowerCase()
                            .contains(s.toString().toLowerCase())) {

                        filteredList.add(venue);

                    }

                }

                adapter.updateList(filteredList);

            }

            @Override
            public void afterTextChanged(Editable s) {
            }

        });

        fabAddVenue.setOnClickListener(v -> {

            Intent intent = new Intent(
                    ManageVenuesActivity.this,
                    AddVenueActivity.class
            );

            startActivity(intent);

        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVenues();
    }

    private void loadVenues() {

        venueList = databaseHelper.getAllVenues();

        if (adapter == null) {

            adapter = new ManageVenueAdapter(
                    this,
                    new ArrayList<>(venueList)
            );

            recyclerManageVenues.setAdapter(adapter);

        } else {

            adapter.updateList(new ArrayList<>(venueList));

        }

    }

}