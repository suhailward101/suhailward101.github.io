package com.example.campusbookingsystem.activities;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.adapters.BookingAdapter;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.models.Booking;
import com.example.campusbookingsystem.session.SessionManager;
import com.google.android.material.chip.Chip;

import java.util.ArrayList;

public class MyBookingsActivity extends AppCompatActivity {

    RecyclerView recyclerBookings;

    EditText etSearchBookings;

    Chip chipAll;
    Chip chipPending;
    Chip chipApproved;
    Chip chipRejected;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    ArrayList<Booking> bookingList;
    ArrayList<Booking> filteredBookings;

    BookingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bookings);

        etSearchBookings = findViewById(R.id.etSearchBookings);
        recyclerBookings = findViewById(R.id.recyclerBookings);

        chipAll = findViewById(R.id.chipAll);
        chipPending = findViewById(R.id.chipPending);
        chipApproved = findViewById(R.id.chipApproved);
        chipRejected = findViewById(R.id.chipRejected);

        databaseHelper = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        bookingList = new ArrayList<>();

        Cursor cursor = databaseHelper.getBookingsByUserId(
                sessionManager.getUserId()
        );

        if (cursor.moveToFirst()) {

            do {

                Booking booking = new Booking();

                booking.setBookingId(cursor.getInt(0));
                booking.setVenueName(cursor.getString(1));
                booking.setBookingDate(cursor.getString(2));
                booking.setStartTime(cursor.getString(3));
                booking.setEndTime(cursor.getString(4));
                booking.setStatus(cursor.getString(5));

                bookingList.add(booking);

            } while (cursor.moveToNext());

        } else {

            Toast.makeText(
                    this,
                    "No bookings found",
                    Toast.LENGTH_SHORT
            ).show();

        }

        cursor.close();

        filteredBookings = new ArrayList<>(bookingList);

        adapter = new BookingAdapter(
                this,
                filteredBookings
        );

        recyclerBookings.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerBookings.setAdapter(adapter);

        etSearchBookings.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {

                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {

                        filteredBookings.clear();

                        String search =
                                s.toString().toLowerCase();

                        for (Booking booking : bookingList) {

                            if (booking.getVenueName()
                                    .toLowerCase()
                                    .contains(search)

                                    ||

                                    booking.getStatus()
                                            .toLowerCase()
                                            .contains(search)

                                    ||

                                    booking.getBookingDate()
                                            .toLowerCase()
                                            .contains(search)) {

                                filteredBookings.add(booking);

                            }

                        }

                        adapter.notifyDataSetChanged();

                    }

                    @Override
                    public void afterTextChanged(
                            Editable s
                    ) {

                    }

                });

        chipAll.setOnClickListener(v -> filterBookings("All"));

        chipPending.setOnClickListener(v -> filterBookings("Pending"));

        chipApproved.setOnClickListener(v -> filterBookings("Approved"));

        chipRejected.setOnClickListener(v -> filterBookings("Rejected"));

    }

    private void filterBookings(String status) {

        filteredBookings.clear();

        for (Booking booking : bookingList) {

            if (status.equals("All")) {

                filteredBookings.add(booking);

            } else if (booking.getStatus().equalsIgnoreCase(status)) {

                filteredBookings.add(booking);

            }

        }

        adapter.notifyDataSetChanged();

    }

}