package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import com.example.campusbookingsystem.database.DatabaseHelper;
import androidx.cardview.widget.CardView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.session.SessionManager;

public class StudentDashboardActivity extends BaseActivity {

    CardView cardVenues;
    CardView cardBookings;
    CardView cardLogout;

    TextView txtWelcome;

    SessionManager sessionManager;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_student_dashboard);

        sessionManager = new SessionManager(this);
        databaseHelper = new DatabaseHelper(this);

        if (sessionManager.getUserId() == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        cardVenues = findViewById(R.id.cardVenues);
        cardBookings = findViewById(R.id.cardBookings);
        cardLogout = findViewById(R.id.cardLogout);

        cardVenues.setOnClickListener(v -> {

            Intent intent = new Intent(
                    StudentDashboardActivity.this,
                    VenueListActivity.class
            );

            startActivity(intent);

        });

        cardBookings.setOnClickListener(v -> {

            Intent intent = new Intent(
                    StudentDashboardActivity.this,
                    MyBookingsActivity.class
            );

            startActivity(intent);

        });

        cardLogout.setOnClickListener(v -> {

            sessionManager.logout();

            Intent intent = new Intent(
                    StudentDashboardActivity.this,
                    LoginActivity.class
            );

            startActivity(intent);
            finish();

        });

        txtWelcome = findViewById(R.id.txtWelcome);

        String firstName = databaseHelper.getUserNameById(
                sessionManager.getUserId()
        );

        if (!firstName.isEmpty()) {
            txtWelcome.setText("Welcome " + firstName);
        }
    }

}