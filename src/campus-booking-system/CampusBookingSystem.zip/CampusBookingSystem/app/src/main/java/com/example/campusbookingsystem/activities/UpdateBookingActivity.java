package com.example.campusbookingsystem.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.database.DatabaseHelper;

public class UpdateBookingActivity extends BaseActivity {

    TextView txtStudent;
    TextView txtVenue;
    TextView txtDate;
    TextView txtTime;
    TextView txtStatus;

    Button btnApprove;
    Button btnReject;

    DatabaseHelper databaseHelper;

    int bookingId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_booking);

        txtStudent = findViewById(R.id.txtStudent);
        txtVenue = findViewById(R.id.txtVenue);
        txtDate = findViewById(R.id.txtDate);
        txtTime = findViewById(R.id.txtTime);
        txtStatus = findViewById(R.id.txtStatus);

        btnApprove = findViewById(R.id.btnApprove);
        btnReject = findViewById(R.id.btnReject);

        databaseHelper = new DatabaseHelper(this);

        bookingId = getIntent().getIntExtra("bookingId", -1);

        txtStudent.setText(getIntent().getStringExtra("student"));
        txtVenue.setText(getIntent().getStringExtra("venue"));
        txtDate.setText(getIntent().getStringExtra("date"));
        txtTime.setText(getIntent().getStringExtra("time"));
        txtStatus.setText(getIntent().getStringExtra("status"));

        btnApprove.setOnClickListener(v -> {

            String status = databaseHelper.getBookingStatus(bookingId);

            if (status == null || !status.equalsIgnoreCase("Pending")) {

                Toast.makeText(
                        this,
                        "Booking already processed",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean updated = databaseHelper.updateBookingStatus(
                    bookingId,
                    "Approved"
            );

            if (updated) {

                Toast.makeText(
                        this,
                        "Booking Approved",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Failed to update booking",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        btnReject.setOnClickListener(v -> {

            String status = databaseHelper.getBookingStatus(bookingId);

            if (status == null || !status.equalsIgnoreCase("Pending")) {

                Toast.makeText(
                        this,
                        "Booking already processed",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean updated = databaseHelper.updateBookingStatus(
                    bookingId,
                    "Rejected"
            );

            if (updated) {

                Toast.makeText(
                        this,
                        "Booking Rejected",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Failed to update booking",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}