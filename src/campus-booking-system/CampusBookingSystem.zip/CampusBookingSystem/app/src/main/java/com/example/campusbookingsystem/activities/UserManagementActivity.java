package com.example.campusbookingsystem.activities;

import android.os.Bundle;
import android.widget.TextView;
import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.adapters.UserAdapter;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.models.User;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.content.Intent;
import android.widget.Toast;
import com.example.campusbookingsystem.session.SessionManager;
import androidx.appcompat.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class UserManagementActivity extends AppCompatActivity {

    RecyclerView recyclerUsers;

    ArrayList<User> userList;

    UserAdapter adapter;

    DatabaseHelper databaseHelper;

    SessionManager sessionManager;

    TextView txtUserCount;

    EditText edtSearchUser;

    FloatingActionButton fabAddUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_management);

        databaseHelper = new DatabaseHelper(this);

        sessionManager = new SessionManager(this);

        txtUserCount = findViewById(R.id.txtUserCount);

        edtSearchUser = findViewById(R.id.edtSearchUser);

        fabAddUser = findViewById(R.id.fabAddUser);

        fabAddUser.setOnClickListener(v -> {

            Intent intent = new Intent(
                    UserManagementActivity.this,
                    AddUserActivity.class
            );

            startActivity(intent);

        });

        recyclerUsers = findViewById(R.id.recyclerUsers);

        edtSearchUser.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after
            ) {

            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count
            ) {

                if (s.toString().trim().isEmpty()) {

                    loadUsers();

                } else {

                    if (s.toString().trim().isEmpty()) {

                        loadUsers();

                    } else {

                        searchUsers(s.toString());

                    }

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }

        });

        userList = new ArrayList<>();

        adapter = new UserAdapter(

                this,

                userList,

                user -> showDeleteDialog(user)

        );

        recyclerUsers.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerUsers.setAdapter(adapter);
        loadUsers();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUsers();
    }

    private void loadUsers() {

        userList.clear();

        Cursor cursor = databaseHelper.getAllUsers();

        if (cursor.moveToFirst()) {

            do {

                User user = new User();

                user.setUserId(
                        cursor.getInt(
                                cursor.getColumnIndexOrThrow("userId")
                        )
                );

                user.setName(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("name")
                        )
                );

                user.setSurname(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("surname")
                        )
                );

                user.setEmail(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("email")
                        )
                );

                user.setPassword(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("password")
                        )
                );

                user.setRole(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("role")
                        )
                );

                userList.add(user);

            } while (cursor.moveToNext());

        }

        cursor.close();

        txtUserCount.setText(
                String.valueOf(userList.size())
        );

        adapter.notifyDataSetChanged();

    }

    private void searchUsers(String keyword) {

        userList.clear();

        Cursor cursor = databaseHelper.searchUsers(keyword);

        if (cursor.moveToFirst()) {

            do {

                User user = new User();

                user.setUserId(
                        cursor.getInt(
                                cursor.getColumnIndexOrThrow("userId")
                        )
                );

                user.setName(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("name")
                        )
                );

                user.setSurname(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("surname")
                        )
                );

                user.setEmail(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("email")
                        )
                );

                user.setPassword(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("password")
                        )
                );

                user.setRole(
                        cursor.getString(
                                cursor.getColumnIndexOrThrow("role")
                        )
                );

                userList.add(user);

            } while (cursor.moveToNext());

        }

        cursor.close();

        txtUserCount.setText(
                String.valueOf(userList.size())
        );

        adapter.notifyDataSetChanged();

    }

    private void showDeleteDialog(User user) {

        if (user.getUserId() == sessionManager.getUserId()) {

            Toast.makeText(
                    this,
                    "You cannot delete your own account.",
                    Toast.LENGTH_SHORT
            ).show();

            return;

        }

        new AlertDialog.Builder(this)

                .setTitle("Delete User")

                .setMessage(
                        "Are you sure you want to delete this user?"
                )

                .setPositiveButton("Yes", (dialog, which) -> {

                    boolean deleted = databaseHelper.deleteUser(
                            user.getUserId()
                    );

                    if (deleted) {

                        Toast.makeText(
                                this,
                                "User deleted successfully.",
                                Toast.LENGTH_SHORT
                        ).show();

                        searchUsers(
                                edtSearchUser.getText().toString()
                        );

                    } else {

                        Toast.makeText(
                                this,
                                "Failed to delete user.",
                                Toast.LENGTH_SHORT
                        ).show();

                    }

                })

                .setNegativeButton("No", null)

                .show();

    }
}