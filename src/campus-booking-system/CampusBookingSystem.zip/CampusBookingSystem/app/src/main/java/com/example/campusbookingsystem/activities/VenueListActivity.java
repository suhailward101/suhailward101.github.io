package com.example.campusbookingsystem.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.widget.EditText;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.adapters.VenueAdapter;
import com.example.campusbookingsystem.database.DatabaseHelper;
import com.example.campusbookingsystem.models.Venue;
import com.example.campusbookingsystem.session.SessionManager;
import java.util.ArrayList;

public class VenueListActivity extends BaseActivity {

    RecyclerView recyclerVenues;

    EditText etSearchVenue;

    DatabaseHelper databaseHelper;
    SessionManager sessionManager;

    ArrayList<Venue> venueList;

    VenueAdapter venueAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_venue_list);

        etSearchVenue = findViewById(R.id.etSearchVenue);

        sessionManager = new SessionManager(this);

        if (sessionManager.getUserId() == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        recyclerVenues = findViewById(R.id.recyclerVenues);

        databaseHelper = new DatabaseHelper(this);

        venueList = databaseHelper.getAllVenues();

        ArrayList<Venue> filteredList =
                new ArrayList<>(venueList);

        venueAdapter = new VenueAdapter(
                this,
                filteredList
        );

        recyclerVenues.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerVenues.setAdapter(venueAdapter);

        recyclerVenues.scheduleLayoutAnimation();

        etSearchVenue.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {

                        filteredList.clear();

                        for (Venue venue : venueList) {

                            if (venue.getVenueName()
                                    .toLowerCase()
                                    .contains(
                                            s.toString().toLowerCase()
                                    )) {

                                filteredList.add(venue);

                            }

                        }

                        venueAdapter.updateList(filteredList);

                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s
                    ) {
                    }

                });
    }
}