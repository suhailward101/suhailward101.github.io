package com.example.campusbookingsystem.adapters;

public class AdminBookingAdapter {
}
