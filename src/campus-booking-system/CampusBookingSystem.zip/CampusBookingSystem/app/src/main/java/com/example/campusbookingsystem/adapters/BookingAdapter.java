package com.example.campusbookingsystem.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.models.Booking;
import android.widget.Toast;
import android.app.AlertDialog;
import java.util.ArrayList;
import android.content.Context;
import com.example.campusbookingsystem.database.DatabaseHelper;

public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.ViewHolder> {

    Context context;

    ArrayList<Booking> bookingList;

    Animation pressAnimation;
    Animation releaseAnimation;

    DatabaseHelper databaseHelper;

    public BookingAdapter(
            Context context,
            ArrayList<Booking> bookingList
    ) {

        this.context = context;
        this.bookingList = bookingList;
        databaseHelper = new DatabaseHelper(context);

        pressAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_press
        );

        releaseAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_release
        );

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_booking, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Booking booking = bookingList.get(position);

        holder.txtVenue.setText(
                booking.getVenueName()
        );

        holder.txtDate.setText(
                booking.getBookingDate()
        );

        holder.txtTime.setText(
                booking.getStartTime()
                        + " - "
                        + booking.getEndTime()
        );

        String status = booking.getStatus();

        holder.txtStatus.setText(status);

        com.example.campusbookingsystem.utils.AnimationUtils.addPressAnimation(
                holder.btnCancelBooking,
                pressAnimation,
                releaseAnimation
        );


        if (status.equalsIgnoreCase("Pending")) {

            holder.btnCancelBooking.setVisibility(View.VISIBLE);

        } else {

            holder.btnCancelBooking.setVisibility(View.GONE);

        }

        holder.btnCancelBooking.setOnClickListener(v -> {

            new AlertDialog.Builder(context)

                    .setTitle("Cancel Booking")

                    .setMessage(
                            "Are you sure you want to cancel this booking?"
                    )

                    .setPositiveButton("Yes", (dialog, which) -> {

                        boolean deleted =
                                databaseHelper.deleteBooking(
                                        booking.getBookingId()
                                );

                        if (deleted) {

                            int adapterPosition = holder.getAdapterPosition();

                            if (adapterPosition != RecyclerView.NO_POSITION) {
                                bookingList.remove(adapterPosition);
                                notifyItemRemoved(adapterPosition);
                            }

                            Toast.makeText(
                                    context,
                                    "Booking cancelled",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                        else {

                            Toast.makeText(
                                    context,
                                    "Unable to cancel booking",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }

                    })

                    .setNegativeButton("No", null)

                    .show();

        });
    }

    @Override
    public int getItemCount() {
        return bookingList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtVenue;
        TextView txtDate;
        TextView txtTime;
        TextView txtStatus;
        Button btnCancelBooking;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtVenue = itemView.findViewById(R.id.txtVenue);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtTime = itemView.findViewById(R.id.txtTime);
            txtStatus = itemView.findViewById(R.id.txtStatus);

            btnCancelBooking = itemView.findViewById(R.id.btnCancelBooking);
        }

    }
}