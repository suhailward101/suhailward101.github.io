package com.example.campusbookingsystem.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import com.example.campusbookingsystem.activities.EditVenueActivity;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.models.Venue;
import java.util.ArrayList;

public class ManageVenueAdapter extends RecyclerView.Adapter<ManageVenueAdapter.ViewHolder> {

    Context context;
    ArrayList<Venue> venueList;

    Animation pressAnimation;
    Animation releaseAnimation;

    public ManageVenueAdapter(Context context, ArrayList<Venue> venueList) {

        this.context = context;
        this.venueList = venueList;

        pressAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_press
        );

        releaseAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_release
        );

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_manage_venue, parent, false);

        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Venue venue = venueList.get(position);

        holder.txtVenueName.setText(venue.getVenueName());

        holder.txtLocation.setText(
                venue.getLocation());

        holder.txtCapacity.setText(
                venue.getCapacity() + " Students");

        holder.txtDescription.setText(
                venue.getDescription());


        com.example.campusbookingsystem.utils.AnimationUtils.addPressAnimation(
                holder.btnEdit,
                pressAnimation,
                releaseAnimation
        );

        com.example.campusbookingsystem.utils.AnimationUtils.addPressAnimation(
                holder.btnDelete,
                pressAnimation,
                releaseAnimation
        );

        holder.btnEdit.setOnClickListener(v -> {

            Intent intent = new Intent(
                    context,
                    EditVenueActivity.class
            );

            intent.putExtra(
                    "venueId",
                    venue.getVenueId()
            );

            context.startActivity(intent);

        });

        holder.btnDelete.setOnClickListener(v -> {

        });

    }

    @Override
    public int getItemCount() {

        return venueList.size();

    }

    public void updateList(ArrayList<Venue> newVenueList) {

        venueList = newVenueList;
        notifyDataSetChanged();

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtVenueName;
        TextView txtLocation;
        TextView txtCapacity;
        TextView txtDescription;

        Button btnEdit;
        Button btnDelete;

        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            txtVenueName = itemView.findViewById(R.id.txtVenueName);
            txtLocation = itemView.findViewById(R.id.txtLocation);
            txtCapacity = itemView.findViewById(R.id.txtCapacity);
            txtDescription = itemView.findViewById(R.id.txtDescription);

            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);

        }
    }

}