package com.example.campusbookingsystem.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.content.Context;
import android.content.Intent;
import com.example.campusbookingsystem.activities.EditUserActivity;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.models.User;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private ArrayList<User> userList;

    private Context context;

    private OnDeleteClickListener deleteListener;

    public UserAdapter(
            Context context,
            ArrayList<User> userList,
            OnDeleteClickListener deleteListener
    ) {

        this.context = context;

        this.userList = userList;

        this.deleteListener = deleteListener;

    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {

        TextView txtName;
        TextView txtEmail;
        TextView txtRole;
        Button btnEditUser;
        Button btnDeleteUser;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtEmail = itemView.findViewById(R.id.txtEmail);
            txtRole = itemView.findViewById(R.id.txtRole);
            btnEditUser = itemView.findViewById(R.id.btnEditUser);
            btnDeleteUser = itemView.findViewById(R.id.btnDeleteUser);
        }
    }

    public interface OnDeleteClickListener {

        void onDeleteClick(User user);

    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_item, parent, false);

        return new UserViewHolder(view);

    }

    @Override
    public void onBindViewHolder(
            @NonNull UserViewHolder holder,
            int position
    ) {

        User user = userList.get(position);

        holder.txtName.setText(
                user.getName() + " " + user.getSurname()
        );

        holder.txtEmail.setText(
                user.getEmail()
        );

        holder.txtRole.setText(
                user.getRole()
        );

        holder.btnEditUser.setOnClickListener(v -> {

            Intent intent = new Intent(
                    context,
                    EditUserActivity.class
            );

            intent.putExtra(
                    "userId",
                    user.getUserId()
            );

            context.startActivity(intent);

        });

        holder.btnDeleteUser.setOnClickListener(v -> {

            deleteListener.onDeleteClick(user);

        });

    }

    @Override
    public int getItemCount() {

        return userList.size();

    }

}