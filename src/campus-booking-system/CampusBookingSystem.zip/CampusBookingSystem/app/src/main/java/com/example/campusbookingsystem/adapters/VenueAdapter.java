package com.example.campusbookingsystem.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusbookingsystem.R;
import com.example.campusbookingsystem.activities.BookingActivity;
import com.example.campusbookingsystem.models.Venue;
import java.util.ArrayList;
import android.view.animation.Animation;

public class VenueAdapter extends RecyclerView.Adapter<VenueAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Venue> venueList;

    Animation pressAnimation;
    Animation releaseAnimation;

    public VenueAdapter(Context context, ArrayList<Venue> venueList) {
        this.context = context;
        this.venueList = venueList;

        pressAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_press
        );

        releaseAnimation = android.view.animation.AnimationUtils.loadAnimation(
                context,
                R.anim.button_release
        );
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_venue, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Venue venue = venueList.get(position);

        holder.txtVenueName.setText(venue.getVenueName());

        holder.txtLocation.setText(
                venue.getLocation()
        );

        holder.txtCapacity.setText(
                venue.getCapacity() + " Students"
        );

        holder.txtDescription.setText(
                venue.getDescription()
        );

        com.example.campusbookingsystem.utils.AnimationUtils.addPressAnimation(
                holder.btnBookVenue,
                pressAnimation,
                releaseAnimation
        );

        holder.btnBookVenue.setOnClickListener(v -> {

            Intent intent = new Intent(
                    context,
                    BookingActivity.class
            );

            intent.putExtra("venueId", venue.getVenueId());
            intent.putExtra("venueName", venue.getVenueName());
            intent.putExtra(
                    "location",
                    venue.getLocation()
            );

            intent.putExtra(
                    "capacity",
                    venue.getCapacity()
            );

            intent.putExtra(
                    "description",
                    venue.getDescription()
            );

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return venueList.size();
    }

    public void updateList(ArrayList<Venue> venueList) {
        this.venueList = venueList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtVenueName;
        TextView txtLocation;
        TextView txtCapacity;
        TextView txtDescription;
        Button btnBookVenue;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtVenueName = itemView.findViewById(R.id.txtVenueName);
            txtLocation = itemView.findViewById(R.id.txtLocation);
            txtCapacity = itemView.findViewById(R.id.txtCapacity);
            txtDescription = itemView.findViewById(R.id.txtDescription);
            btnBookVenue = itemView.findViewById(R.id.btnBookVenue);
        }
    }
}