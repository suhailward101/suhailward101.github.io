package com.example.campusbookingsystem.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.campusbookingsystem.models.Venue;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CampusBooking.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE Users (" +
                "userId INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "surname TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT," +
                "role TEXT)");

        db.execSQL("CREATE TABLE Venues (" +
                "venueId INTEGER PRIMARY KEY AUTOINCREMENT," +
                "venueName TEXT," +
                "location TEXT," +
                "capacity INTEGER," +
                "description TEXT)");

        db.execSQL("CREATE TABLE Bookings (" +
                "bookingId INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userId INTEGER," +
                "venueId INTEGER," +
                "bookingDate TEXT," +
                "startTime TEXT," +
                "endTime TEXT," +
                "status TEXT)");

        ContentValues adminValues = new ContentValues();
        adminValues.put("name", "Admin");
        adminValues.put("surname", "User");
        adminValues.put("email", "admin@campus.com");
        adminValues.put("password", "admin123");
        adminValues.put("role", "Admin");

        db.insert("Users", null, adminValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        db.execSQL("DROP TABLE IF EXISTS Venues");
        db.execSQL("DROP TABLE IF EXISTS Bookings");
        onCreate(db);
    }

    public boolean insertUser(String name, String surname, String email, String password, String role) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("surname", surname);
        values.put("email", email);
        values.put("password", password);
        values.put("role", role);

        return db.insert("Users", null, values) != -1;
    }

    public int getUserId(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT userId FROM Users WHERE email=? AND password=?",
                new String[]{email, password}
        );

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            return id;
        }

        cursor.close();
        return -1;
    }

    public String getUserNameById(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT name FROM Users WHERE userId = ?",
                new String[]{String.valueOf(userId)}
        );

        String name = "";

        if (cursor.moveToFirst()) {
            name = cursor.getString(0);
        }

        cursor.close();

        return name;
    }

    public String getUserRole(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT role FROM Users WHERE email=? AND password=?",
                new String[]{email, password}
        );

        if (cursor.moveToFirst()) {
            String role = cursor.getString(0);
            cursor.close();
            return role;
        }

        cursor.close();
        return null;
    }

    public String getUserRoleById(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT role FROM Users WHERE userId=?",
                new String[]{String.valueOf(userId)}
        );

        if (cursor.moveToFirst()) {

            String role = cursor.getString(0);

            cursor.close();

            return role;
        }

        cursor.close();

        return null;
    }

    public boolean checkUser(String email, String password) {
        return getUserId(email, password) != -1;
    }

    public boolean insertVenue(String venueName, String location, int capacity, String description) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("venueName", venueName);
        values.put("location", location);
        values.put("capacity", capacity);
        values.put("description", description);

        return db.insert("Venues", null, values) != -1;
    }

    public ArrayList<Venue> getAllVenues() {
        ArrayList<Venue> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM Venues", null);

        if (cursor.moveToFirst()) {
            do {
                Venue v = new Venue();
                v.setVenueId(cursor.getInt(0));
                v.setVenueName(cursor.getString(1));
                v.setLocation(cursor.getString(2));
                v.setCapacity(cursor.getInt(3));
                v.setDescription(cursor.getString(4));
                list.add(v);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    public boolean insertBooking(int userId, int venueId, String date, String start, String end, String status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("userId", userId);
        values.put("venueId", venueId);
        values.put("bookingDate", date);
        values.put("startTime", start);
        values.put("endTime", end);
        values.put("status", status);

        return db.insert("Bookings", null, values) != -1;
    }

    public Cursor getBookingsByUserId(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT " +
                        "Bookings.bookingId, " +
                        "Venues.venueName, " +
                        "Bookings.bookingDate, " +
                        "Bookings.startTime, " +
                        "Bookings.endTime, " +
                        "Bookings.status " +
                        "FROM Bookings " +
                        "INNER JOIN Venues " +
                        "ON Bookings.venueId = Venues.venueId " +
                        "WHERE Bookings.userId=?",
                new String[]{String.valueOf(userId)}
        );
    }

    public Cursor getAllBookings() {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(

                "SELECT " +
                        "Bookings.bookingId, " +
                        "Users.name, " +
                        "Users.surname, " +
                        "Venues.venueName, " +
                        "Bookings.bookingDate, " +
                        "Bookings.startTime, " +
                        "Bookings.endTime, " +
                        "Bookings.status " +
                        "FROM Bookings " +
                        "INNER JOIN Users " +
                        "ON Bookings.userId = Users.userId " +
                        "INNER JOIN Venues " +
                        "ON Bookings.venueId = Venues.venueId",

                null
        );
    }

    public boolean updateBookingStatus(int bookingId, String status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("status", status);

        return db.update(
                "Bookings",
                values,
                "bookingId=?",
                new String[]{String.valueOf(bookingId)}
        ) > 0;
    }

    public boolean isVenueAlreadyBooked(int venueId, String date, String start, String end) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT startTime, endTime " +
                        "FROM Bookings " +
                        "WHERE venueId=? " +
                        "AND bookingDate=? " +
                        "AND (status='Pending' OR status='Approved')",
                new String[]{String.valueOf(venueId), date}
        );

        boolean conflict = false;

        if (cursor.moveToFirst()) {
            do {
                String existingStart = cursor.getString(0);
                String existingEnd = cursor.getString(1);

                if (isTimeOverlap(existingStart, existingEnd, start, end)) {
                    conflict = true;
                    break;
                }
            } while (cursor.moveToNext());
        }

        cursor.close();
        return conflict;
    }

    public boolean isVenueAvailable(int venueId, String date, String startTime, String endTime) {
        return !isVenueAlreadyBooked(venueId, date, startTime, endTime);
    }

    private boolean isTimeOverlap(String start1, String end1, String start2, String end2) {
        int s1 = convertTime(start1);
        int e1 = convertTime(end1);
        int s2 = convertTime(start2);
        int e2 = convertTime(end2);

        return s1 < e2 && s2 < e1;
    }

    private int convertTime(String time) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        return hours * 60 + minutes;
    }

    public boolean hasUserBookedVenue(
            int userId,
            int venueId,
            String date,
            String startTime,
            String endTime
    ) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT bookingId FROM Bookings " +
                        "WHERE userId=? AND venueId=? " +
                        "AND bookingDate=? " +
                        "AND startTime=? " +
                        "AND endTime=?",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(venueId),
                        date,
                        startTime,
                        endTime
                }
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    public int getRejectedBookingCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Bookings WHERE status='Rejected'",
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    public int getVenueCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Venues",
                null
        );

        cursor.moveToFirst();

        int count = cursor.getInt(0);

        cursor.close();

        return count;
    }

    public int getBookingCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Bookings",
                null
        );

        cursor.moveToFirst();

        int count = cursor.getInt(0);

        cursor.close();

        return count;
    }

    public int getPendingBookingCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Bookings WHERE status='Pending'",
                null
        );

        cursor.moveToFirst();

        int count = cursor.getInt(0);

        cursor.close();

        return count;
    }

    public int getApprovedBookingCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Bookings WHERE status='Approved'",
                null
        );

        cursor.moveToFirst();

        int count = cursor.getInt(0);

        cursor.close();

        return count;
    }

    public Venue getVenueById(int venueId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM Venues WHERE venueId=?",
                new String[]{String.valueOf(venueId)}
        );

        Venue venue = null;

        if (cursor.moveToFirst()) {

            venue = new Venue();

            venue.setVenueId(cursor.getInt(0));
            venue.setVenueName(cursor.getString(1));
            venue.setLocation(cursor.getString(2));
            venue.setCapacity(cursor.getInt(3));
            venue.setDescription(cursor.getString(4));
        }

        cursor.close();

        return venue;
    }

    public boolean updateVenue(
            int venueId,
            String venueName,
            String location,
            int capacity,
            String description
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("venueName", venueName);
        values.put("location", location);
        values.put("capacity", capacity);
        values.put("description", description);

        int result = db.update(
                "Venues",
                values,
                "venueId=?",
                new String[]{String.valueOf(venueId)}
        );

        return result > 0;
    }

    public boolean deleteVenue(int venueId) {

        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                "Venues",
                "venueId=?",
                new String[]{String.valueOf(venueId)}
        );

        return result > 0;
    }

    public boolean venueHasBookings(int venueId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM Bookings WHERE venueId=?",
                new String[]{
                        String.valueOf(venueId)
                }
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    public String getBookingStatus(int bookingId) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT status FROM Bookings WHERE bookingId = ?",
                new String[]{String.valueOf(bookingId)}
        );

        String status = null;

        if (cursor.moveToFirst()) {
            status = cursor.getString(0);
        }

        cursor.close();
        db.close();

        return status;
    }

    public boolean deleteBooking(int bookingId) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rows = db.delete(
                "Bookings",
                "bookingId=?",
                new String[]{
                        String.valueOf(bookingId)
                }
        );

        return rows > 0;
    }

    public int getStudentCount() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM Users WHERE role = ?",
                new String[]{"Student"}
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    public Cursor getAllUsers() {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(

                "SELECT * FROM Users ORDER BY name ASC",

                null
        );
    }

    public Cursor getUserById(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM Users WHERE userId=?",
                new String[]{String.valueOf(userId)}
        );
    }

    public boolean updateUser(
            int userId,
            String name,
            String surname,
            String email,
            String password,
            String role
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("surname", surname);
        values.put("email", email);
        values.put("password", password);
        values.put("role", role);

        int result = db.update(
                "Users",
                values,
                "userId=?",
                new String[]{String.valueOf(userId)}
        );

        return result > 0;
    }

    public boolean deleteUser(int userId) {

        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                "Users",
                "userId=?",
                new String[]{String.valueOf(userId)}
        );

        return result > 0;
    }

    public boolean emailExists(String email) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT userId FROM Users WHERE email=?",
                new String[]{email}
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    public Cursor searchUsers(String keyword) {

        SQLiteDatabase db = getReadableDatabase();

        String search = "%" + keyword + "%";

        return db.rawQuery(
                "SELECT * FROM Users " +
                        "WHERE name LIKE ? " +
                        "OR surname LIKE ? " +
                        "OR email LIKE ? " +
                        "ORDER BY name ASC",
                new String[]{
                        search,
                        search,
                        search
                }
        );
    }

}