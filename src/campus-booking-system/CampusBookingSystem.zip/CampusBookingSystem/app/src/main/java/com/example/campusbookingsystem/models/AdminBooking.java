package com.example.campusbookingsystem.models;

public class AdminBooking {
}
