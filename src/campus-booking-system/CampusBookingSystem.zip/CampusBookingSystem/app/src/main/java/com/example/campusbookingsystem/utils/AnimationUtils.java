package com.example.campusbookingsystem.utils;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;

public class AnimationUtils {

    public static void addPressAnimation(
            View view,
            Animation press,
            Animation release
    ) {

        view.setOnTouchListener((v, event) -> {

            switch (event.getAction()) {

                case MotionEvent.ACTION_DOWN:

                    v.startAnimation(press);
                    break;

                case MotionEvent.ACTION_UP:

                case MotionEvent.ACTION_CANCEL:

                    v.startAnimation(release);
                    break;
            }

            return false;
        });
    }

}