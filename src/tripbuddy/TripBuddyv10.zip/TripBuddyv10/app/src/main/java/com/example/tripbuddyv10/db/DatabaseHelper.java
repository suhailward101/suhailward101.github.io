package com.example.tripbuddyv10.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tripbuddy.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE trips (id INTEGER PRIMARY KEY AUTOINCREMENT, destination TEXT, start_date TEXT, end_date TEXT, notes TEXT)");
        db.execSQL("CREATE TABLE activities (id INTEGER PRIMARY KEY AUTOINCREMENT, trip_id INTEGER, activity TEXT, FOREIGN KEY(trip_id) REFERENCES trips(id))");
        db.execSQL("CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, trip_id INTEGER, name TEXT, amount REAL, FOREIGN KEY(trip_id) REFERENCES trips(id))");
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, location TEXT, date TEXT, mood TEXT, imageUri TEXT, musicUri TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS trips");
        db.execSQL("DROP TABLE IF EXISTS activities");
        db.execSQL("DROP TABLE IF EXISTS expenses");
        db.execSQL("DROP TABLE IF EXISTS memories");
        onCreate(db);
    }
}