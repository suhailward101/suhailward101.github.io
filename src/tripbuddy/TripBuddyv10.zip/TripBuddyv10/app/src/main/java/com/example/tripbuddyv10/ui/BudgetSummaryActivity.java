//THis will be used to provide a page for the user which summarizes the total costs and activity details of their planned trip

package com.example.tripbuddyv10.ui;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.db.DatabaseHelper;
import com.example.tripbuddyv10.utils.PrefsManager;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class BudgetSummaryActivity extends AppCompatActivity {

    TextView tvSummarySubtotal, tvSummaryDiscount, tvSummaryFinalTotal, tvBreakdown;
    Button btnFinishSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget_summary);

        tvSummarySubtotal = findViewById(R.id.tvSummarySubtotal);
        tvSummaryDiscount = findViewById(R.id.tvSummaryDiscount);
        tvSummaryFinalTotal = findViewById(R.id.tvSummaryFinalTotal);
        tvBreakdown = findViewById(R.id.tvBreakdown);
        btnFinishSummary = findViewById(R.id.btnFinishSummary);

        double subtotal = getIntent().getDoubleExtra("subtotal", 0);
        double discountRate = getIntent().getDoubleExtra("discountRate", 0);
        double finalTotal = getIntent().getDoubleExtra("finalTotal", 0);
        String breakdown = getIntent().getStringExtra("breakdown");

        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("en", "ZA"));
        tvSummarySubtotal.setText("Subtotal: " + nf.format(subtotal));
        tvSummaryDiscount.setText("Discount: " + (int) (discountRate * 100) + "%");
        tvSummaryFinalTotal.setText("Final Total: " + nf.format(finalTotal));
        tvBreakdown.setText("Breakdown:\n" + (breakdown == null ? "No items" : breakdown));

        btnFinishSummary.setOnClickListener(v -> {
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            String destination = getIntent().getStringExtra("destination");
            String startDate = getIntent().getStringExtra("startDate");
            String endDate = getIntent().getStringExtra("endDate");
            String notes = getIntent().getStringExtra("notes");

            long tripId = insertTrip(db, destination, startDate, endDate, notes);

            if (getIntent().getBooleanExtra("cbSightseeing", false))
                insertTripActivity(db, tripId, "Sightseeing");
            if (getIntent().getBooleanExtra("cbHiking", false))
                insertTripActivity(db, tripId, "Hiking");
            if (getIntent().getBooleanExtra("cbDining", false))
                insertTripActivity(db, tripId, "Dining");
            if (getIntent().getBooleanExtra("cbMuseum", false))
                insertTripActivity(db, tripId, "Museum");

            ArrayList<String> expenseNames = getIntent().getStringArrayListExtra("expenseNames");
            ArrayList<Double> expenseAmounts = (ArrayList<Double>) getIntent().getSerializableExtra("expenseAmounts");

            if (expenseNames != null && expenseAmounts != null) {
                for (int i = 0; i < expenseNames.size(); i++) {
                    insertTripExpense(db, tripId, expenseNames.get(i), expenseAmounts.get(i));
                }
            }

            PrefsManager.incrementTripCount(this);
            Toast.makeText(this, "Your trip has been saved successfully!", Toast.LENGTH_SHORT).show();

            db.close();
            finish();
        });
    }

    private long insertTrip(SQLiteDatabase db, String destination, String startDate, String endDate, String notes) {
        ContentValues values = new ContentValues();
        values.put("destination", destination);
        values.put("start_date", startDate);
        values.put("end_date", endDate);
        values.put("notes", notes);
        return db.insert("trips", null, values);
    }

    private void insertTripActivity(SQLiteDatabase db, long tripId, String activity) {
        ContentValues values = new ContentValues();
        values.put("trip_id", tripId);
        values.put("activity", activity);
        db.insert("activities", null, values);
    }

    private void insertTripExpense(SQLiteDatabase db, long tripId, String name, double amount) {
        ContentValues values = new ContentValues();
        values.put("trip_id", tripId);
        values.put("name", name);
        values.put("amount", amount);
        db.insert("expenses", null, values);
    }
}