//This will allow a user to insert a photo, music, and provide details for a memory in which they want to store on the app

package com.example.tripbuddyv10.ui;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.db.DatabaseHelper;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CreateMemoryActivity extends AppCompatActivity {

    private EditText etDescription, etLocation, etDate;
    private Spinner spMood;
    private Uri selectedImageUri, selectedMusicUri;
    private DatabaseHelper dbHelper;
    private ActivityResultLauncher<String> imagePickerLauncher;
    private ActivityResultLauncher<String> musicPickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_memory);

        etDescription = findViewById(R.id.etDescription);
        etLocation = findViewById(R.id.etLocation);
        etDate = findViewById(R.id.etDate);
        spMood = findViewById(R.id.spMood);
        Button btnSelectPhoto = findViewById(R.id.btnSelectPhoto);
        Button btnSelectMusic = findViewById(R.id.btnSelectMusic);
        Button btnSaveMemory = findViewById(R.id.btnSaveMemory);

        dbHelper = new DatabaseHelper(this);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        etDate.setText(today);

        String[] moods = {"Adventurous", "Exciting", "Relaxing", "Romantic"};
        spMood.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, moods));

        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri;
                        Toast.makeText(this, "Photo selected", Toast.LENGTH_SHORT).show();
                    }
                });

        musicPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedMusicUri = uri;
                        Toast.makeText(this, "Music selected", Toast.LENGTH_SHORT).show();
                    }
                });

        btnSelectPhoto.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));
        btnSelectMusic.setOnClickListener(v -> musicPickerLauncher.launch("audio/*"));
        btnSaveMemory.setOnClickListener(v -> saveMemory());
    }

    private void saveMemory() {
        String desc = etDescription.getText().toString().trim();
        String loc = etLocation.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String mood = spMood.getSelectedItem().toString();

        if (desc.isEmpty() || selectedImageUri == null || selectedMusicUri == null) {
            Toast.makeText(this, "Fill description and select photo & music", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO memories (description, imageUri, musicUri, date, location, mood) VALUES (?, ?, ?, ?, ?, ?)",
                new Object[]{desc, selectedImageUri.toString(), selectedMusicUri.toString(), date, loc, mood});
        db.close();

        Toast.makeText(this, "Memory saved", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(CreateMemoryActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }
}