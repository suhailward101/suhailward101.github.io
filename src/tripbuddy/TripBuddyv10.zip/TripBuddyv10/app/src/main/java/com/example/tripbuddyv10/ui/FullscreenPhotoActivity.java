package com.example.tripbuddyv10.ui;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tripbuddyv10.R;

public class FullscreenPhotoActivity extends AppCompatActivity {

    private ImageView fullscreenImage;
    private Button btnPlayMusic;
    private MediaPlayer mediaPlayer;
    private Uri musicUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen_photo);

        fullscreenImage = findViewById(R.id.fullscreenImage);
        btnPlayMusic = findViewById(R.id.btnPlayMusic);

        String photoUriStr = getIntent().getStringExtra("photoUri");
        String musicUriStr = getIntent().getStringExtra("musicUri");

        if (photoUriStr != null) {
            Uri photoUri = Uri.parse(photoUriStr);
            fullscreenImage.setImageURI(photoUri);
        }

        if (musicUriStr != null) {
            musicUri = Uri.parse(musicUriStr);
        }

        btnPlayMusic.setOnClickListener(v -> {
            if (musicUri != null) {
                if (mediaPlayer == null) {
                    mediaPlayer = MediaPlayer.create(this, musicUri);
                }
                mediaPlayer.start();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
