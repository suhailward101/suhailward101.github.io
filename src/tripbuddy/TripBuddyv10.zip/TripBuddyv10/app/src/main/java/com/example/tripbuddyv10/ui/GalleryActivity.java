package com.example.tripbuddyv10.ui;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.db.DatabaseHelper;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import androidx.annotation.NonNull;

public class GalleryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ArrayList<Memory> memoryList;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int PICK_PHOTO_REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        } else {
            loadMemories();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadMemories();
            } else {
                Toast.makeText(this, "Permission denied to read storage", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadMemories() {
        dbHelper = new DatabaseHelper(this);
        memoryList = loadMemoriesFromDatabase();

        GridView gridView = findViewById(R.id.photoGrid);
        MemoryAdapter adapter = new MemoryAdapter(this, memoryList);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            Memory clickedMemory = memoryList.get(position);
            Intent intent = new Intent(this, MemoryActivity.class);
            intent.putExtra("memoryId", clickedMemory.getId());
            intent.putExtra("photoUri", clickedMemory.getPhotoUri());
            intent.putExtra("musicUri", clickedMemory.getMusicUri());
            startActivity(intent);
        });
    }

    private ArrayList<Memory> loadMemoriesFromDatabase() {
        ArrayList<Memory> memories = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id, description, location, date, mood, imageUri, musicUri FROM memories", null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String description = cursor.getString(1);
            String location = cursor.getString(2);
            String date = cursor.getString(3);
            String mood = cursor.getString(4);
            String imageUri = cursor.getString(5);
            String musicUri = cursor.getString(6);

            memories.add(new Memory(id, description, location, date, mood, imageUri, musicUri));
        }

        cursor.close();
        db.close();
        return memories;
    }

    private void pickImageFromGallery() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_PHOTO_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PHOTO_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                Toast.makeText(this, "Image selected: " + selectedImageUri.toString(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}