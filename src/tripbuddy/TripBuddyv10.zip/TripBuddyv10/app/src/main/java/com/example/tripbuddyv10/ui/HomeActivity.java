package com.example.tripbuddyv10.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.utils.PrefsManager;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnLogout = findViewById(R.id.btnLogout);
        Button btnMemory = findViewById(R.id.btnCreateMemory);
        Button btnGallery = findViewById(R.id.btnOpenGallery);
        Button btnBudget = findViewById(R.id.btnPlanTrip);
        Button btnSettings = findViewById(R.id.btnSettings);
        TextView tvWelcome = findViewById(R.id.tvWelcome);

        String name = PrefsManager.getUsername(this);
        tvWelcome.setText("Welcome To Trip Buddy!, " + name + "!");

        btnLogout.setOnClickListener(v -> {
            PrefsManager.logout(this);
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        Button btnCreateMemory = findViewById(R.id.btnCreateMemory);
        btnCreateMemory.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateMemoryActivity.class);
            startActivity(intent);
        });

        btnGallery.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, GalleryActivity.class))
        );

        btnBudget.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, TripPlanningActivity.class))
        );

        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, SettingsActivity.class))
        );
    }
}