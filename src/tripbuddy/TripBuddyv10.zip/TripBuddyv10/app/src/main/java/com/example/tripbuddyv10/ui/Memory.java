package com.example.tripbuddyv10.ui;

public class Memory {
    private int id;
    private String description;
    private String location;
    private String date;
    private String mood;
    private String photoUri;
    private String musicUri;

    public Memory(int id, String description, String location, String date, String mood, String photoUri, String musicUri) {
        this.id = id;
        this.description = description;
        this.location = location;
        this.date = date;
        this.mood = mood;
        this.photoUri = photoUri;
        this.musicUri = musicUri;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public String getDate() {
        return date;
    }

    public String getMood() {
        return mood;
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public String getMusicUri() {
        return musicUri;
    }
}