package com.example.tripbuddyv10.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.db.DatabaseHelper;

public class MemoryActivity extends AppCompatActivity {

    TextView tvDescription, tvLocation, tvDate, tvMood;
    ImageView memoryImage;
    Button btnPlay, btnPause, btnStop, btnBack;
    MediaPlayer mediaPlayer;
    Uri musicUri;
    DatabaseHelper dbHelper;
    Animation fadeIn, buttonScale;
    private static final int REQUEST_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memory);

        tvDescription = findViewById(R.id.tvDescription);
        tvLocation = findViewById(R.id.tvLocation);
        tvDate = findViewById(R.id.tvDate);
        tvMood = findViewById(R.id.tvMood);
        memoryImage = findViewById(R.id.memoryImage);
        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
        btnBack = findViewById(R.id.btnBack);

        fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        buttonScale = AnimationUtils.loadAnimation(this, R.anim.button_scale);

        memoryImage.startAnimation(fadeIn);

        dbHelper = new DatabaseHelper(this);
        loadMemory();

        btnPlay.setOnClickListener(v -> {
            v.startAnimation(buttonScale);
            playMusic();
        });

        btnPause.setOnClickListener(v -> {
            v.startAnimation(buttonScale);
            pauseMusic();
        });

        btnStop.setOnClickListener(v -> {
            v.startAnimation(buttonScale);
            stopMusic();
        });

        btnBack.setOnClickListener(v -> {
            finish();
            startActivity(new Intent(MemoryActivity.this, GalleryActivity.class));
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_CODE);
            }
        }
    }

    private void loadMemory() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT description, location, date, mood, imageUri, musicUri FROM memories ORDER BY id DESC LIMIT 1", null);

        if (cursor.moveToFirst()) {
            String description = cursor.getString(0);
            String location = cursor.getString(1);
            String date = cursor.getString(2);
            String mood = cursor.getString(3);
            String imageUri = cursor.getString(4);
            String musicUriString = cursor.getString(5);

            tvDescription.setText(description);
            tvLocation.setText(location);
            tvDate.setText(date);
            tvMood.setText(mood);

            if (imageUri != null && !imageUri.isEmpty()) {
                memoryImage.setImageURI(Uri.parse(imageUri));
            }

            if (musicUriString != null && !musicUriString.isEmpty()) {
                musicUri = Uri.parse(musicUriString);
            }
        }

        cursor.close();
        db.close();
    }

    private void playMusic() {
        if (musicUri != null) {
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(this, musicUri);
            }
            mediaPlayer.start();
        }
    }

    private void pauseMusic() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    private void stopMusic() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        pauseMusic();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopMusic();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadMemory();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}