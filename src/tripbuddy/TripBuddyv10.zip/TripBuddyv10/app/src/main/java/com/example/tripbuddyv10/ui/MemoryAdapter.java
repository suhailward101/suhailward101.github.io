//This class will be used to format the pictures added in the GridView in the Gallery class to have a specific size, and allow a user to click on it

package com.example.tripbuddyv10.ui;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.example.tripbuddyv10.R;
import java.util.ArrayList;

public class MemoryAdapter extends BaseAdapter {
    Context context;
    ArrayList<Memory> memories;

    public MemoryAdapter(Context context, ArrayList<Memory> memories) {
        this.context = context;
        this.memories = memories;
    }

    @Override
    public int getCount() {
        return memories.size();
    }

    @Override
    public Object getItem(int position) {
        return memories.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(300, 300));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            imageView = (ImageView) convertView;
        }

        Memory memory = memories.get(position);
        if (memory.getPhotoUri() != null) {
            imageView.setImageURI(Uri.parse(memory.getPhotoUri()));
        } else {
            imageView.setImageResource(R.drawable.ic_placeholder);
        }
        return imageView;
    }
}