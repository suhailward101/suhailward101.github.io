//This will be used to format the pictures imported from the user's device to view in a Grid format

package com.example.tripbuddyv10.ui;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
public class PhotoAdapter extends BaseAdapter {
    private Context context;
    private List<Uri> photoUris;

    public PhotoAdapter(Context context, List<Uri> photoUris) {
        this.context = context;
        this.photoUris = photoUris;
    }

    @Override
    public int getCount() { return photoUris.size(); }

    @Override
    public Object getItem(int position) { return photoUris.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(300, 300));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            imageView = (ImageView) convertView;
        }
        imageView.setImageURI(photoUris.get(position));
        return imageView;
    }
}

