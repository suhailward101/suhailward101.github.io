//Provides the user with a graphical interface of adjusting the TripBuddy app to suit their preferances

package com.example.tripbuddyv10.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.utils.PrefsManager;

public class SettingsActivity extends AppCompatActivity {

    private Switch swTheme, swMusic;
    private Spinner spLanguage;
    private Button btnSaveSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        swTheme = findViewById(R.id.swTheme);
        swMusic = findViewById(R.id.swMusic);
        spLanguage = findViewById(R.id.spLanguage);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);

        String[] langs = {"English", "French", "Spanish"};
        spLanguage.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, langs));

        swTheme.setChecked(PrefsManager.getTheme(this).equals("dark"));
        swMusic.setChecked(PrefsManager.isMusicEnabled(this));

        String currentLang = PrefsManager.getLanguage(this);
        for (int i = 0; i < langs.length; i++) {
            if (langs[i].equals(currentLang)) {
                spLanguage.setSelection(i);
                break;
            }
        }

        btnSaveSettings.setOnClickListener(v -> {
            boolean dark = swTheme.isChecked();
            PrefsManager.setTheme(this, dark ? "dark" : "light");
            PrefsManager.setMusicEnabled(this, swMusic.isChecked());
            String selLang = (String) spLanguage.getSelectedItem();
            PrefsManager.setLanguage(this, selLang);

            AppCompatDelegate.setDefaultNightMode(dark ?
                    AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
            recreate();
        });
    }
}