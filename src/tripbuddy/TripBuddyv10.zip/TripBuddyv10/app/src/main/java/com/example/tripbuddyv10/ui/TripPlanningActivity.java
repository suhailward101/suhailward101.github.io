package com.example.tripbuddyv10.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tripbuddyv10.R;
import com.example.tripbuddyv10.utils.PrefsManager;
import java.util.ArrayList;
import android.app.DatePickerDialog;
import java.util.Calendar;

public class TripPlanningActivity extends AppCompatActivity {

    EditText editTextDestination, editTextStartDate, editTextEndDate, editTextNotes;
    EditText etExpenseName, etExpenseAmount;
    CheckBox cbSightseeing, cbHiking, cbDining, cbMuseum;
    Button btnAddExpense, btnSaveTrip;
    LinearLayout llExpensesList;
    TextView tvTotalActivities, tvTotalExpenses, tvTotalBudget;
    TextView tvSubtotal, tvDiscountPreview, tvFinalTotalPreview;

    ArrayList<Expense> customExpenses = new ArrayList<>();
    Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_planning);

        editTextDestination = findViewById(R.id.editTextDestination);
        editTextStartDate = findViewById(R.id.editTextStartDate);
        editTextEndDate = findViewById(R.id.editTextEndDate);
        editTextNotes = findViewById(R.id.editTextNotes);
        etExpenseName = findViewById(R.id.etExpenseName);
        etExpenseAmount = findViewById(R.id.etExpenseAmount);

        cbSightseeing = findViewById(R.id.cbSightseeing);
        cbHiking = findViewById(R.id.cbHiking);
        cbDining = findViewById(R.id.cbDining);
        cbMuseum = findViewById(R.id.cbMuseum);

        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnSaveTrip = findViewById(R.id.btnSaveTrip);

        llExpensesList = findViewById(R.id.llExpensesList);
        tvTotalActivities = findViewById(R.id.tvTotalActivities);
        tvTotalExpenses = findViewById(R.id.tvTotalExpenses);
        tvTotalBudget = findViewById(R.id.tvTotalBudget);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvDiscountPreview = findViewById(R.id.tvDiscountPreview);
        tvFinalTotalPreview = findViewById(R.id.tvFinalTotalPreview);

        cbSightseeing.setOnCheckedChangeListener((b, c) -> updateTotals());
        cbHiking.setOnCheckedChangeListener((b, c) -> updateTotals());
        cbDining.setOnCheckedChangeListener((b, c) -> updateTotals());
        cbMuseum.setOnCheckedChangeListener((b, c) -> updateTotals());

        btnAddExpense.setOnClickListener(v -> {
            String name = etExpenseName.getText().toString().trim();
            String amountStr = etExpenseAmount.getText().toString().trim();
            if (name.isEmpty() || amountStr.isEmpty()) {
                Toast.makeText(this, "Please enter name and amount", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                double amount = Double.parseDouble(amountStr);
                Expense newExpense = new Expense(name, amount);
                customExpenses.add(newExpense);
                TextView tv = new TextView(this);
                tv.setText(name + " - R" + String.format("%.2f", amount));
                llExpensesList.addView(tv);
                etExpenseName.setText("");
                etExpenseAmount.setText("");
                updateTotals();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
            }
        });

        btnSaveTrip.setOnClickListener(v -> {
            String destination = editTextDestination.getText().toString().trim();
            String startDate = editTextStartDate.getText().toString().trim();
            String endDate = editTextEndDate.getText().toString().trim();
            String notes = editTextNotes.getText().toString().trim();

            if (destination.isEmpty() || startDate.isEmpty() || endDate.isEmpty()) {
                Toast.makeText(this, "Please fill destination and dates", Toast.LENGTH_SHORT).show();
                return;
            }

            double subtotal = computeSubtotal();
            int tripCount = PrefsManager.getTripCount(this);
            double discount = tripCount >= 3 ? subtotal * 0.1 : 0;
            double finalTotal = subtotal - discount;

            StringBuilder breakdown = new StringBuilder();
            if (cbSightseeing.isChecked()) breakdown.append("Sightseeing - R800.00\n");
            if (cbHiking.isChecked()) breakdown.append("Hiking - R950.00\n");
            if (cbDining.isChecked()) breakdown.append("Dining - R700.00\n");
            if (cbMuseum.isChecked()) breakdown.append("Museum - R350.00\n");

            for (Expense e : customExpenses)
                breakdown.append(e.name).append(" - R").append(String.format("%.2f", e.amount)).append("\n");

            ArrayList<String> expenseNames = new ArrayList<>();
            ArrayList<Double> expenseAmounts = new ArrayList<>();
            for (Expense e : customExpenses) {
                expenseNames.add(e.name);
                expenseAmounts.add(e.amount);
            }

            Intent intent = new Intent(this, BudgetSummaryActivity.class);
            intent.putExtra("destination", destination);
            intent.putExtra("startDate", startDate);
            intent.putExtra("endDate", endDate);
            intent.putExtra("notes", notes);
            intent.putExtra("subtotal", subtotal);
            intent.putExtra("discountRate", discount / subtotal);
            intent.putExtra("finalTotal", finalTotal);
            intent.putExtra("breakdown", breakdown.toString());
            intent.putExtra("cbSightseeing", cbSightseeing.isChecked());
            intent.putExtra("cbHiking", cbHiking.isChecked());
            intent.putExtra("cbDining", cbDining.isChecked());
            intent.putExtra("cbMuseum", cbMuseum.isChecked());
            intent.putStringArrayListExtra("expenseNames", expenseNames);
            intent.putExtra("expenseAmounts", expenseAmounts);

            PrefsManager.incrementTripCount(this);
            startActivity(intent);
        });

        llExpensesList.post(this::updateTotals);

        editTextStartDate.setOnClickListener(v -> {
            new DatePickerDialog(this, startDateSetListener,
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        editTextEndDate.setOnClickListener(v -> {
            new DatePickerDialog(this, endDateSetListener,
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void updateTotals() {
        double subtotal = computeSubtotal();
        int tripCount = PrefsManager.getTripCount(this);
        double discount = tripCount >= 3 ? subtotal * 0.1 : 0;
        double finalTotal = subtotal - discount;

        tvTotalActivities.setText("Activities: " + getSelectedActivitiesCount());
        tvTotalExpenses.setText("Expenses: R" + String.format("%.2f", subtotal));
        tvTotalBudget.setText("Budget: R" + String.format("%.2f", finalTotal));

        tvSubtotal.setText("Subtotal: R" + String.format("%.2f", subtotal));
        tvDiscountPreview.setText("Discount: " + (tripCount >= 3 ? "10%" : "0%"));
        tvFinalTotalPreview.setText("Final Total: R" + String.format("%.2f", finalTotal));
    }

    private double computeSubtotal() {
        double total = 0;
        if (cbSightseeing.isChecked()) total += 800;
        if (cbHiking.isChecked()) total += 950;
        if (cbDining.isChecked()) total += 700;
        if (cbMuseum.isChecked()) total += 350;
        for (Expense e : customExpenses) total += e.amount;
        return total;
    }

    private int getSelectedActivitiesCount() {
        int count = 0;
        if (cbSightseeing.isChecked()) count++;
        if (cbHiking.isChecked()) count++;
        if (cbDining.isChecked()) count++;
        if (cbMuseum.isChecked()) count++;
        return count;
    }

    private final DatePickerDialog.OnDateSetListener startDateSetListener =
            (view, year, monthOfYear, dayOfMonth) -> {
                String date = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                editTextStartDate.setText(date);
            };

    private final DatePickerDialog.OnDateSetListener endDateSetListener =
            (view, year, monthOfYear, dayOfMonth) -> {
                String date = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                editTextEndDate.setText(date);
            };

    static class Expense {
        String name;
        double amount;

        Expense(String name, double amount) {
            this.name = name;
            this.amount = amount;
        }
    }
}