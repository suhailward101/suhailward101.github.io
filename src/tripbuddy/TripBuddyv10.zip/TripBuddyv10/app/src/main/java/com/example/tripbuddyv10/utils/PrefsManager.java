//used to offer persistent storage to users - saves user settings such as login credentials each time they open the app

package com.example.tripbuddyv10.utils;
import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {
    private static final String PREFS = "TripBuddyPrefs";

    public static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_TRIP_COUNT = "tripCount";
    public static final String KEY_THEME = "theme";
    public static final String KEY_MUSIC_ENABLED = "musicEnabled";
    public static final String KEY_LANGUAGE = "language";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void setLoggedIn(Context c, boolean value) {
        prefs(c).edit().putBoolean(KEY_IS_LOGGED_IN, value).apply();
    }

    public static boolean isLoggedIn(Context c) {
        return prefs(c).getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public static void setUsername(Context c, String name) {
        prefs(c).edit().putString(KEY_USERNAME, name).apply();
    }

    public static String getUsername(Context c) {
        return prefs(c).getString(KEY_USERNAME, "Traveler");
    }

    public static int getTripCount(Context c) {
        return prefs(c).getInt(KEY_TRIP_COUNT, 0);
    }

    public static void incrementTripCount(Context c) {
        int updated = getTripCount(c) + 1;
        prefs(c).edit().putInt(KEY_TRIP_COUNT, updated).apply();
    }

    public static void setTheme(Context c, String theme) {
        prefs(c).edit().putString(KEY_THEME, theme).apply();
    }

    public static String getTheme(Context c) {
        return prefs(c).getString(KEY_THEME, "light");
    }

    public static void setMusicEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(KEY_MUSIC_ENABLED, enabled).apply();
    }

    public static boolean isMusicEnabled(Context c) {
        return prefs(c).getBoolean(KEY_MUSIC_ENABLED, true);
    }

    public static void setLanguage(Context c, String lang) {
        prefs(c).edit().putString(KEY_LANGUAGE, lang).apply();
    }

    public static String getLanguage(Context c) {
        return prefs(c).getString(KEY_LANGUAGE, "en");
    }

    public static void logout(Context c) {
        prefs(c).edit().clear().apply();
    }
}

